VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "virtex4"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL reset_n
        SIGNAL GMII_RX_DV_0_sig
        SIGNAL GMII_RX_ER_0_sig
        SIGNAL GTX_CLK_0_sig
        SIGNAL PHY_TXER_sig
        SIGNAL PHY_TXEN_sig
        SIGNAL gec_user_tx_data_in(7:0)
        SIGNAL gec_user_crc_err
        SIGNAL gec_user_rx_data_out(7:0)
        SIGNAL gec_user_rx_valid_out
        SIGNAL gec_user_rx_size_out(10:0)
        SIGNAL gec_user_busy
        SIGNAL gec_user_tx_enable_out
        SIGNAL gec_user_trigger
        SIGNAL gec_user_tx_size_in(10:0)
        SIGNAL reset
        SIGNAL clock_66mhz
        SIGNAL clock_5mhz
        SIGNAL reset_extension
        SIGNAL reset_phy
        SIGNAL reset_button
        SIGNAL MASTER_CLK
        SIGNAL software_reset
        SIGNAL PHY_TXD_sig(7:0)
        SIGNAL GMII_RXD_0_sig(7:0)
        SIGNAL reset_start
        SIGNAL initial_reset
        SIGNAL XLXN_460
        SIGNAL gec_user_addrs(7:0)
        SIGNAL XLXN_12498
        SIGNAL GLOBAL_RESET_MAP
        SIGNAL rx_wren
        SIGNAL rx_data(0)
        SIGNAL tx_data(63:0)
        SIGNAL rx_data(63:0)
        SIGNAL gec_user_addrs(0)
        SIGNAL gec_user_addrs(1)
        SIGNAL gec_user_addrs(2)
        SIGNAL b_data_we
        SIGNAL b_end_packet
        SIGNAL b_data(63:0)
        SIGNAL rx_addr(63:0)
        SIGNAL b_enable
        SIGNAL gec_user_addrs(3)
        SIGNAL gec_user_addrs(4)
        SIGNAL gec_user_addrs(5)
        SIGNAL gec_user_addrs(6)
        SIGNAL gec_user_addrs(7)
        SIGNAL tx_data(63:56)
        SIGNAL ADC_CLOCK_MAP
        SIGNAL DCM_PSI_RESET_MAP
        SIGNAL PSI_PULSES_MAP
        SIGNAL BURST_DATA_SEL_MAP
        SIGNAL ADC_DELAY_MAP
        SIGNAL ADC_TESTMODE_MAP
        SIGNAL PSI_LEVELS_MAP
        SIGNAL PSI_SAMPLE_SEL_MAP
        SIGNAL PSI_SAMPLE_DEBUG_MAP
        SIGNAL psi_token_in
        SIGNAL psi_trigger
        SIGNAL adc_delayed_clk
        SIGNAL adc_burst_we
        SIGNAL adc_delayed_frame
        SIGNAL XLXN_12503
        SIGNAL psi_data_out
        SIGNAL dcm_reset
        SIGNAL rx_data(4)
        SIGNAL rx_data(6:0)
        SIGNAL rx_data(23:8)
        SIGNAL ADC_CLK_IN
        SIGNAL dcm_reset_psi
        SIGNAL adc_testmode_sig
        SIGNAL psi_reset
        SIGNAL rx_data(1)
        SIGNAL ADC_65MSPS_CH0
        SIGNAL adc_data_del_ce
        SIGNAL XLXN_12220
        SIGNAL XLXN_12229
        SIGNAL ADC_FRAME_OUT
        SIGNAL ADC_CLK_OUT
        SIGNAL rx_data(24)
        SIGNAL XLXN_12257
        SIGNAL BUSC_16DP_32S
        SIGNAL BUSC_21DN_43S
        SIGNAL XLXN_12023
        SIGNAL PRIMARY_CLK
        SIGNAL SECONDARY_CLK
        SIGNAL PHY_TXD_sig(0)
        SIGNAL PHY_TXD_sig(1)
        SIGNAL PHY_TXD_sig(2)
        SIGNAL PHY_TXD_sig(3)
        SIGNAL BUSC_25DN_51S
        SIGNAL BUSC_25DP_50S
        SIGNAL BUSC_24DN_49S
        SIGNAL BUSC_24DP_48S
        SIGNAL BUSC_15DN_31S
        SIGNAL BUSC_15DP_30S
        SIGNAL BUSC_14DN_29S
        SIGNAL BUSC_14DP_28S
        SIGNAL PHY_TXD_sig(6)
        SIGNAL PHY_TXD_sig(7)
        SIGNAL PHY_TXD_sig(4)
        SIGNAL PHY_TXD_sig(5)
        SIGNAL BUSC_16DN_33S
        SIGNAL GMII_RXD_0_sig(6)
        SIGNAL GMII_RXD_0_sig(7)
        SIGNAL GMII_RXD_0_sig(4)
        SIGNAL GMII_RXD_0_sig(5)
        SIGNAL GMII_RXD_0_sig(2)
        SIGNAL GMII_RXD_0_sig(3)
        SIGNAL GMII_RXD_0_sig(0)
        SIGNAL GMII_RXD_0_sig(1)
        SIGNAL BUSC_20DN_41S
        SIGNAL BUSC_19DN_39S
        SIGNAL BUSC_20DP_40S
        SIGNAL BUSC_19DP_38S
        SIGNAL BUSC_18DP_36S
        SIGNAL BUSC_18DN_37S
        SIGNAL BUSC_17DN_35S
        SIGNAL BUSC_17DP_34S
        SIGNAL BUSC_27DN_55S
        SIGNAL BUSC_27DP_54S
        SIGNAL BUSC_26DP_52S
        SIGNAL BUSC_26DN_53S
        SIGNAL GENERAL_03DN_07S
        SIGNAL GENERAL_02DN_05S
        SIGNAL GENERAL_02DP_04S
        SIGNAL BUSAHS_00DP_00S
        SIGNAL BUSAHS_00DN_01S
        SIGNAL BUSAHS_01DP_02S
        SIGNAL BUSAHS_01DN_03S
        SIGNAL BUSAHS_02DN_05S
        SIGNAL BUSA_16DN_33S
        SIGNAL BUSA_16DP_32S
        SIGNAL BUSBB_05DN_11S
        SIGNAL BUSBB_05DP_10S
        SIGNAL XLXN_15064
        SIGNAL BUSBB_04DP_08S
        SIGNAL BUSBB_04DN_09S
        SIGNAL BUSBB_03DP_06S
        SIGNAL BUSBB_03DN_07S
        SIGNAL BUSBB_00DP_00S
        SIGNAL BUSBB_00DN_01S
        SIGNAL BUSBB_02DP_04S
        SIGNAL BUSBB_01DP_02S
        SIGNAL BUSBB_01DN_03S
        SIGNAL PSI_CMD_FIFO_MAP
        SIGNAL PSI_CLK90
        SIGNAL PSI_CLK0
        SIGNAL EN_TRIG_TOK_MAP
        SIGNAL DISPLAY_MAP
        SIGNAL display_ser_data
        SIGNAL display_load_bar
        SIGNAL INTERNAL_05DP_10S
        SIGNAL INTERNAL_05DN_11S
        SIGNAL INTERNAL_04DN_09S
        SIGNAL XLXN_15151
        SIGNAL trig_reset
        SIGNAL rx_data(15:0)
        SIGNAL sw_en_pulse
        SIGNAL PSI_CAL_TAG_MAP
        SIGNAL ADC_DCM_FB
        SIGNAL XLXN_11574
        SIGNAL XLXN_12188
        SIGNAL adc_sample_we
        SIGNAL b_data_sel
        SIGNAL cal_tag(15:0)
        SIGNAL b_data0(63:0)
        SIGNAL rx_addr(4:0)
        SIGNAL psi_debug_sample(1:0)
        SIGNAL adc_data_label(3:0)
        SIGNAL adc_delayed_data(0)
        SIGNAL XLXN_15146
        SIGNAL XLXN_15149
        SIGNAL rx_data(7:0)
        SIGNAL XLXN_12239
        SIGNAL XLXN_12242
        SIGNAL XLXN_12249
        SIGNAL XLXN_12252
        SIGNAL rx_data(25)
        SIGNAL rx_data(26)
        SIGNAL adc_delayed_data(1)
        SIGNAL ADC_65MSPS_CH1
        SIGNAL adc_delayed_data(1:0)
        SIGNAL b_data1(63:0)
        SIGNAL b_data_we1
        SIGNAL b_data_we0
        SIGNAL token(0)
        SIGNAL tx_data(0)
        SIGNAL we_out0
        SIGNAL plaq_id0(2:0)
        SIGNAL plaq_id1(2:0)
        SIGNAL token(1)
        SIGNAL tx_data(4)
        SIGNAL we_out1
        SIGNAL GENERAL_03DP_06S
        SIGNAL BUSA_17DN_35S
        SIGNAL BUSA_17DP_34S
        SIGNAL rx_addr(8)
        SIGNAL rx_addr(9)
        SIGNAL rx_addr(10)
        SIGNAL rx_addr(11)
        SIGNAL MEM_BLK_MAP
        SIGNAL XLXN_12617
        SIGNAL XLXN_15755
        SIGNAL rx_addr(12)
        SIGNAL sw_trig_reset
        SIGNAL psi_cmd_fifo_full
        SIGNAL psi_cmd_fifo_empty
        SIGNAL psi_cmd_fifo_re
        SIGNAL rx_data(31:0)
        SIGNAL XLXN_15543(31:0)
        SIGNAL tx_data(32)
        SIGNAL tx_data(36)
        SIGNAL rx_data(56)
        SIGNAL rx_data(48)
        SIGNAL rx_data(23:16)
        SIGNAL rx_data(39:24)
        SIGNAL rx_data(47:40)
        SIGNAL tx_data(40)
        SIGNAL psi_data_out_sel
        SIGNAL psi_data_out0
        SIGNAL psi_token_out0
        SIGNAL psi_token_out1
        SIGNAL PSI_SEROUT_SEL_MAP
        SIGNAL XLXN_15817
        SIGNAL XLXN_15818
        SIGNAL token(1:0)
        SIGNAL psi_tkn_rst
        SIGNAL adc_data_del_rst
        SIGNAL psi_data_out1
        SIGNAL BUSD_23DP_46S
        SIGNAL BUSD_23DN_47S
        SIGNAL BUSD_22DP_44S
        SIGNAL BUSD_22DN_45S
        SIGNAL BUSD_21DP_42S
        SIGNAL BUSD_21DN_43S
        SIGNAL BUSD_19DP_38S
        SIGNAL BUSD_19DN_39S
        SIGNAL GENERAL_05DN_11S
        SIGNAL BUSD_20DP_40S
        SIGNAL BUSD_20DN_41S
        SIGNAL b_data_pre_we0
        SIGNAL b_data_pre_we1
        SIGNAL PSI_LEVELS_MAP0
        SIGNAL PSI_LEVELS_MAP1
        SIGNAL psi_debug_sample(0)
        SIGNAL psi_debug_sample(1)
        SIGNAL psi_sample_sel1
        SIGNAL psi_sample_sel0
        SIGNAL EXT_TRIGG
        SIGNAL EXT_CLK
        SIGNAL psi_extdom_trig
        SIGNAL XLXN_15825
        SIGNAL adc_clk_sel
        SIGNAL ADC_CLK_SEL_MAP
        SIGNAL trigger_number(19:0)
        SIGNAL cal_tag_trig_num_sel
        SIGNAL adc_data_label(3)
        SIGNAL adc_data_label(2)
        SIGNAL adc_data_label(1)
        SIGNAL adc_data_label(0)
        SIGNAL rx_data(16)
        SIGNAL XLXN_12172
        SIGNAL XLXN_15111
        SIGNAL XLXN_15824
        SIGNAL INT_HALF_CLK
        SIGNAL XLXN_15844
        SIGNAL XLXN_15845
        SIGNAL BUSA_14DP_28S
        SIGNAL BUSA_12DP_24S
        SIGNAL BUSA_12DN_25S
        SIGNAL BUSA_14DN_29S
        SIGNAL CHAN1_SPEC_DEL_MAP
        SIGNAL XLXN_15849
        SIGNAL XLXN_15850
        SIGNAL adc_data_del_ce_ch1
        SIGNAL adc_data_del_rst_ch1
        SIGNAL reset_trig_counter
        SIGNAL RESET_TRIG_NUM_MAP
        PORT Input BUSC_16DP_32S
        PORT BiDirectional BUSC_21DN_43S
        PORT Input PRIMARY_CLK
        PORT Input SECONDARY_CLK
        PORT Output BUSC_25DN_51S
        PORT Output BUSC_25DP_50S
        PORT Output BUSC_24DN_49S
        PORT Output BUSC_24DP_48S
        PORT Output BUSC_15DN_31S
        PORT Output BUSC_15DP_30S
        PORT Output BUSC_14DN_29S
        PORT Output BUSC_14DP_28S
        PORT Output BUSC_16DN_33S
        PORT Input BUSC_20DN_41S
        PORT Input BUSC_19DN_39S
        PORT Input BUSC_20DP_40S
        PORT Input BUSC_19DP_38S
        PORT Input BUSC_18DP_36S
        PORT Input BUSC_18DN_37S
        PORT Input BUSC_17DN_35S
        PORT Input BUSC_17DP_34S
        PORT Output BUSC_27DN_55S
        PORT Input BUSC_27DP_54S
        PORT Input BUSC_26DP_52S
        PORT Output BUSC_26DN_53S
        PORT Input GENERAL_03DN_07S
        PORT Input GENERAL_02DN_05S
        PORT Input GENERAL_02DP_04S
        PORT Input BUSAHS_00DP_00S
        PORT Input BUSAHS_00DN_01S
        PORT Input BUSAHS_01DP_02S
        PORT Input BUSAHS_01DN_03S
        PORT Output BUSAHS_02DN_05S
        PORT Input BUSA_16DN_33S
        PORT Input BUSA_16DP_32S
        PORT Input BUSBB_05DN_11S
        PORT Input BUSBB_05DP_10S
        PORT Output BUSBB_04DP_08S
        PORT Output BUSBB_04DN_09S
        PORT Output BUSBB_03DP_06S
        PORT Output BUSBB_03DN_07S
        PORT Output BUSBB_00DP_00S
        PORT Output BUSBB_00DN_01S
        PORT Output BUSBB_02DP_04S
        PORT Output BUSBB_01DP_02S
        PORT Output BUSBB_01DN_03S
        PORT Output INTERNAL_05DP_10S
        PORT Output INTERNAL_05DN_11S
        PORT Output INTERNAL_04DN_09S
        PORT Output GENERAL_03DP_06S
        PORT Input BUSA_17DN_35S
        PORT Input BUSA_17DP_34S
        PORT Input BUSD_23DP_46S
        PORT Input BUSD_23DN_47S
        PORT Output BUSD_22DP_44S
        PORT Output BUSD_22DN_45S
        PORT Output BUSD_21DP_42S
        PORT Output BUSD_21DN_43S
        PORT Output BUSD_19DP_38S
        PORT Output BUSD_19DN_39S
        PORT Output GENERAL_05DN_11S
        PORT Output BUSD_20DP_40S
        PORT Output BUSD_20DN_41S
        PORT Input BUSA_14DP_28S
        PORT Input BUSA_12DP_24S
        PORT Input BUSA_12DN_25S
        PORT Input BUSA_14DN_29S
        BEGIN BLOCKDEF gigabit_ethernet_controller
            TIMESTAMP 2009 3 19 15 55 29
            LINE N 64 208 0 208 
            RECTANGLE N 0 260 64 284 
            LINE N 64 272 0 272 
            LINE N 656 208 720 208 
            BEGIN LINE N 116 -220 600 -220 
                LINESTYLE Dash
            END LINE
            BEGIN LINE N 112 -108 596 -108 
                LINESTYLE Dash
            END LINE
            LINE N 64 -544 0 -544 
            LINE N 64 -480 0 -480 
            LINE N 64 -416 0 -416 
            LINE N 656 -544 720 -544 
            LINE N 656 -480 720 -480 
            LINE N 656 -416 720 -416 
            RECTANGLE N 656 -620 720 -596 
            LINE N 656 -608 720 -608 
            RECTANGLE N 0 -620 64 -596 
            LINE N 64 -608 0 -608 
            LINE N 64 144 0 144 
            LINE N 656 144 720 144 
            RECTANGLE N 0 468 64 492 
            LINE N 64 480 0 480 
            RECTANGLE N 0 532 64 556 
            LINE N 64 544 0 544 
            RECTANGLE N 656 468 720 492 
            LINE N 656 480 720 480 
            RECTANGLE N 656 532 720 556 
            LINE N 656 544 720 544 
            LINE N 656 416 720 416 
            LINE N 656 352 720 352 
            RECTANGLE N 64 -704 656 712 
            LINE N 64 -160 0 -160 
        END BLOCKDEF
        BEGIN BLOCKDEF inv
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 224 -32 160 -32 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            CIRCLE N 128 -48 160 -16 
        END BLOCKDEF
        BEGIN BLOCKDEF RESET_INIT
            TIMESTAMP 2008 8 13 19 58 59
            RECTANGLE N 64 -64 384 0 
            LINE N 64 -32 0 -32 
            LINE N 384 -32 448 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF DELAY16
            TIMESTAMP 2008 8 19 17 17 7
            RECTANGLE N 64 -128 384 0 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            LINE N 384 -96 448 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF or2
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 28 -224 204 -48 112 -48 192 -96 
            ARC N -40 -152 72 -40 48 -48 48 -144 
            LINE N 112 -144 48 -144 
            ARC N 28 -144 204 32 192 -96 112 -144 
            LINE N 112 -48 48 -48 
        END BLOCKDEF
        BEGIN BLOCKDEF or3b1
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 28 -64 
            CIRCLE N 28 -72 48 -52 
            LINE N 0 -128 72 -128 
            LINE N 0 -192 48 -192 
            LINE N 256 -128 192 -128 
            LINE N 112 -176 48 -176 
            ARC N 28 -176 204 0 192 -128 112 -176 
            ARC N 28 -256 204 -80 112 -80 192 -128 
            LINE N 112 -80 48 -80 
            LINE N 48 -64 48 -80 
            LINE N 48 -192 48 -176 
            ARC N -40 -184 72 -72 48 -80 48 -176 
        END BLOCKDEF
        BEGIN BLOCKDEF ibufg
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF ibuf
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF obuf
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 0 -32 64 -32 
            LINE N 224 -32 128 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF iobuf
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 224 -128 128 -128 
            LINE N 160 -64 128 -64 
            LINE N 160 -128 160 -64 
            LINE N 0 -64 64 -64 
            LINE N 96 -140 96 -192 
            LINE N 0 -192 96 -192 
            LINE N 64 -96 64 -160 
            LINE N 128 -128 64 -96 
            LINE N 64 -160 128 -128 
            LINE N 128 -96 128 -32 
            LINE N 64 -64 128 -96 
            LINE N 128 -32 64 -64 
            LINE N 0 -128 64 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF and2
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 144 -48 64 -48 
            LINE N 64 -144 144 -144 
            LINE N 64 -48 64 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF fdre
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 0 -32 64 -32 
            RECTANGLE N 64 -320 320 -64 
            LINE N 192 -64 192 -32 
            LINE N 192 -32 64 -32 
            LINE N 64 -112 80 -128 
            LINE N 80 -128 64 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF DATA_MANAGER
            TIMESTAMP 2009 3 19 18 36 45
            LINE N 64 -480 0 -480 
            LINE N 64 -544 0 -544 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -300 64 -276 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -416 0 -416 
            LINE N 672 -544 736 -544 
            LINE N 672 -480 736 -480 
            RECTANGLE N 672 -492 736 -468 
            LINE N 64 -352 0 -352 
            LINE N 672 -416 736 -416 
            RECTANGLE N 672 -428 736 -404 
            LINE N 64 -736 0 -736 
            LINE N 672 -48 736 -48 
            RECTANGLE N 672 -60 736 -36 
            LINE N 672 -112 736 -112 
            LINE N 672 128 736 128 
            LINE N 64 128 0 128 
            LINE N 64 256 0 256 
            RECTANGLE N 0 180 64 204 
            LINE N 64 192 0 192 
            LINE N 64 -688 0 -688 
            LINE N 64 -640 0 -640 
            RECTANGLE N 64 -768 672 288 
            RECTANGLE N 0 4 64 28 
            LINE N 64 16 0 16 
            RECTANGLE N 672 4 736 28 
            LINE N 672 16 736 16 
        END BLOCKDEF
        BEGIN BLOCKDEF gnd
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -64 64 -96 
            LINE N 76 -48 52 -48 
            LINE N 68 -32 60 -32 
            LINE N 88 -64 40 -64 
            LINE N 64 -64 64 -80 
            LINE N 64 -128 64 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF d4_16e
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -1152 320 -64 
            LINE N 384 -1088 320 -1088 
            LINE N 384 -1024 320 -1024 
            LINE N 384 -960 320 -960 
            LINE N 384 -896 320 -896 
            LINE N 384 -832 320 -832 
            LINE N 384 -768 320 -768 
            LINE N 384 -704 320 -704 
            LINE N 384 -640 320 -640 
            LINE N 384 -576 320 -576 
            LINE N 384 -512 320 -512 
            LINE N 384 -448 320 -448 
            LINE N 384 -384 320 -384 
            LINE N 384 -320 320 -320 
            LINE N 384 -256 320 -256 
            LINE N 384 -192 320 -192 
            LINE N 384 -128 320 -128 
            LINE N 0 -896 64 -896 
            LINE N 0 -960 64 -960 
            LINE N 0 -1024 64 -1024 
            LINE N 0 -1088 64 -1088 
            LINE N 0 -128 64 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF VERSION_BLK
            TIMESTAMP 2009 3 20 20 51 16
            RECTANGLE N 64 -64 320 0 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF cb4re
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 384 -192 320 -192 
            LINE N 0 -32 64 -32 
            LINE N 0 -128 64 -128 
            LINE N 384 -256 320 -256 
            LINE N 384 -320 320 -320 
            LINE N 384 -384 320 -384 
            LINE N 384 -448 320 -448 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 384 -128 320 -128 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 0 -192 64 -192 
            RECTANGLE N 64 -512 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF fde
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            RECTANGLE N 64 -320 320 -64 
            LINE N 64 -112 80 -128 
            LINE N 80 -128 64 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF fd
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -320 320 -64 
            LINE N 0 -128 64 -128 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF ADC_frame_counter
            TIMESTAMP 2008 11 12 21 55 31
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            LINE N 320 -160 384 -160 
            RECTANGLE N 64 -192 320 128 
        END BLOCKDEF
        BEGIN BLOCKDEF ADC_single_frame_counter
            TIMESTAMP 2009 3 11 20 7 27
            RECTANGLE N 64 -192 320 0 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            LINE N 320 -160 384 -160 
        END BLOCKDEF
        BEGIN BLOCKDEF bufg
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -64 64 0 
            LINE N 128 -32 64 -64 
            LINE N 64 0 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF dcm_adv
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -448 320 0 
            LINE N 64 -416 0 -416 
            LINE N 64 -384 0 -384 
            LINE N 64 -352 0 -352 
            LINE N 64 -320 0 -320 
            LINE N 64 -288 0 -288 
            LINE N 64 -256 0 -256 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -192 0 -192 
            RECTANGLE N 0 -204 64 -180 
            LINE N 64 -160 0 -160 
            LINE N 64 -128 0 -128 
            LINE N 64 -96 0 -96 
            LINE N 320 -416 384 -416 
            LINE N 320 -384 384 -384 
            LINE N 320 -352 384 -352 
            LINE N 320 -320 384 -320 
            LINE N 320 -288 384 -288 
            LINE N 320 -256 384 -256 
            LINE N 320 -224 384 -224 
            LINE N 320 -192 384 -192 
            LINE N 320 -160 384 -160 
            LINE N 320 -128 384 -128 
            LINE N 320 -96 384 -96 
            LINE N 320 -64 384 -64 
            RECTANGLE N 320 -76 384 -52 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF idelay
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -192 320 0 
            LINE N 64 -160 0 -160 
            LINE N 64 -128 0 -128 
            LINE N 64 -96 0 -96 
            LINE N 64 -64 0 -64 
            LINE N 64 -32 0 -32 
            LINE N 320 -160 384 -160 
        END BLOCKDEF
        BEGIN BLOCKDEF dcm_base
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -352 320 0 
            LINE N 64 -320 0 -320 
            LINE N 64 -176 0 -176 
            LINE N 64 -32 0 -32 
            LINE N 320 -320 384 -320 
            LINE N 320 -288 384 -288 
            LINE N 320 -256 384 -256 
            LINE N 320 -224 384 -224 
            LINE N 320 -192 384 -192 
            LINE N 320 -160 384 -160 
            LINE N 320 -128 384 -128 
            LINE N 320 -96 384 -96 
            LINE N 320 -64 384 -64 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF idelayctrl
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -96 320 0 
            LINE N 64 -64 0 -64 
            LINE N 64 -32 0 -32 
            LINE N 320 -64 384 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF ibufds
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -48 64 -48 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            LINE N 224 -32 128 -32 
            CIRCLE N 48 -24 64 -8 
            LINE N 0 -16 48 -16 
        END BLOCKDEF
        BEGIN BLOCKDEF obufds
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 224 -16 116 -16 
            LINE N 224 -48 96 -48 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            CIRCLE N 100 -20 108 -12 
            LINE N 108 -16 116 -16 
        END BLOCKDEF
        BEGIN BLOCKDEF psi_command_sender
            TIMESTAMP 2009 3 30 16 19 43
            LINE N 64 96 0 96 
            LINE N 64 160 0 160 
            LINE N 320 96 384 96 
            LINE N 64 -224 0 -224 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            LINE N 320 -224 384 -224 
            LINE N 320 -128 384 -128 
            LINE N 320 -32 384 -32 
            RECTANGLE N 64 -256 320 192 
        END BLOCKDEF
        BEGIN BLOCKDEF psi_cmd_fifo32
            TIMESTAMP 2009 3 30 16 21 21
            RECTANGLE N 64 -384 320 0 
            LINE N 64 -352 0 -352 
            LINE N 64 -288 0 -288 
            LINE N 64 -224 0 -224 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            LINE N 320 -352 384 -352 
            LINE N 320 -192 384 -192 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF token_trigger_controller
            TIMESTAMP 2009 3 30 21 47 18
            RECTANGLE N 64 -768 416 0 
            LINE N 64 -736 0 -736 
            LINE N 64 -672 0 -672 
            LINE N 64 -608 0 -608 
            LINE N 64 -544 0 -544 
            LINE N 64 -480 0 -480 
            LINE N 64 -416 0 -416 
            LINE N 64 -352 0 -352 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            LINE N 416 -736 480 -736 
            LINE N 416 -384 480 -384 
            LINE N 416 -32 480 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF display_fifo
            TIMESTAMP 2009 3 30 22 0 48
            RECTANGLE N 64 -384 320 0 
            LINE N 64 -352 0 -352 
            LINE N 64 -288 0 -288 
            LINE N 64 -224 0 -224 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            LINE N 320 -352 384 -352 
            LINE N 320 -192 384 -192 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF fd16re
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 0 -32 64 -32 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            RECTANGLE N 64 -320 320 -64 
            RECTANGLE N 0 -268 64 -244 
            RECTANGLE N 320 -268 384 -244 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF vcc
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -32 64 -64 
            LINE N 64 0 64 -32 
            LINE N 96 -64 32 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF burst_traffic_controller
            TIMESTAMP 2009 3 13 21 12 13
            RECTANGLE N 64 -192 512 0 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            LINE N 512 -160 576 -160 
        END BLOCKDEF
        BEGIN BLOCKDEF PSI_Chip_Readout_Blk
            TIMESTAMP 2009 4 28 14 36 38
            LINE N 64 32 0 32 
            LINE N 64 96 0 96 
            LINE N 64 -800 0 -800 
            LINE N 64 -736 0 -736 
            LINE N 64 -672 0 -672 
            RECTANGLE N 0 -620 64 -596 
            LINE N 64 -608 0 -608 
            LINE N 64 -544 0 -544 
            LINE N 64 -480 0 -480 
            RECTANGLE N 0 -428 64 -404 
            LINE N 64 -416 0 -416 
            LINE N 64 -352 0 -352 
            LINE N 64 -288 0 -288 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            LINE N 480 -800 544 -800 
            RECTANGLE N 480 -44 544 -20 
            LINE N 480 -32 544 -32 
            RECTANGLE N 64 -832 480 128 
            LINE N 64 -160 0 -160 
        END BLOCKDEF
        BEGIN BLOCKDEF chip_token_manager
            TIMESTAMP 2009 5 21 19 49 33
            LINE N 64 160 0 160 
            RECTANGLE N 0 84 64 108 
            LINE N 64 96 0 96 
            RECTANGLE N 0 20 64 44 
            LINE N 64 32 0 32 
            LINE N 64 -480 0 -480 
            LINE N 64 -416 0 -416 
            LINE N 64 -352 0 -352 
            LINE N 64 -288 0 -288 
            LINE N 64 -224 0 -224 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            LINE N 464 -480 528 -480 
            LINE N 464 -336 528 -336 
            LINE N 464 -192 528 -192 
            RECTANGLE N 464 -60 528 -36 
            LINE N 464 -48 528 -48 
            RECTANGLE N 64 -512 464 192 
        END BLOCKDEF
        BEGIN BLOCKDEF PLAQ_ID_GEN
            TIMESTAMP 2009 4 28 15 58 56
            RECTANGLE N 64 -128 320 0 
            RECTANGLE N 320 -108 384 -84 
            LINE N 320 -96 384 -96 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF and2b1
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -48 64 -144 
            LINE N 64 -144 144 -144 
            LINE N 144 -48 64 -48 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 256 -96 192 -96 
            LINE N 0 -128 64 -128 
            LINE N 0 -64 40 -64 
            CIRCLE N 40 -76 64 -52 
        END BLOCKDEF
        BEGIN BLOCKDEF or2b1
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 32 -64 
            CIRCLE N 32 -76 56 -52 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            LINE N 112 -48 48 -48 
            ARC N 28 -144 204 32 192 -96 112 -144 
            LINE N 112 -144 48 -144 
            ARC N -40 -152 72 -40 48 -48 48 -144 
            ARC N 28 -224 204 -48 112 -48 192 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF plaq_enable_blk
            TIMESTAMP 2009 5 4 22 38 49
            RECTANGLE N 64 -320 320 0 
            LINE N 64 -288 0 -288 
            LINE N 64 -224 0 -224 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            LINE N 320 -288 384 -288 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF External_Trigger_Handler
            TIMESTAMP 2009 5 30 7 20 46
            LINE N 64 160 0 160 
            LINE N 64 96 0 96 
            LINE N 64 32 0 32 
            LINE N 384 32 448 32 
            LINE N 64 -224 0 -224 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            RECTANGLE N 384 -236 448 -212 
            LINE N 384 -224 448 -224 
            RECTANGLE N 64 -256 384 192 
        END BLOCKDEF
        BEGIN BLOCKDEF m2_1
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 96 -64 96 -192 
            LINE N 256 -96 96 -64 
            LINE N 256 -160 256 -96 
            LINE N 96 -192 256 -160 
            LINE N 176 -32 96 -32 
            LINE N 176 -80 176 -32 
            LINE N 0 -32 96 -32 
            LINE N 320 -128 256 -128 
            LINE N 0 -96 96 -96 
            LINE N 0 -160 96 -160 
        END BLOCKDEF
        BEGIN BLOCKDEF ftc
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -320 320 -64 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 384 -256 320 -256 
            LINE N 0 -256 64 -256 
            LINE N 0 -32 64 -32 
            LINE N 0 -128 64 -128 
        END BLOCKDEF
        BEGIN BLOCK XLXI_4006 RESET_INIT
            PIN CLOCK_INIT clock_5mhz
            PIN RESET_INIT initial_reset
        END BLOCK
        BEGIN BLOCK XLXI_3430 or3b1
            PIN I0 reset_button
            PIN I1 software_reset
            PIN I2 initial_reset
            PIN O reset_start
        END BLOCK
        BEGIN BLOCK XLXI_3469 or2
            PIN I0 software_reset
            PIN I1 initial_reset
            PIN O reset_phy
        END BLOCK
        BEGIN BLOCK XLXI_4007 inv
            PIN I reset
            PIN O reset_n
        END BLOCK
        BEGIN BLOCK XLXI_4004 DELAY16
            PIN CLOCK_INIT clock_5mhz
            PIN in_sig reset_start
            PIN RESET_INIT reset_extension
        END BLOCK
        BEGIN BLOCK XLXI_4005 or2
            PIN I0 reset_start
            PIN I1 reset_extension
            PIN O reset
        END BLOCK
        BEGIN BLOCK GEC gigabit_ethernet_controller
            PIN user_tx_data_in(7:0) gec_user_tx_data_in(7:0)
            PIN user_tx_size_in(10:0) gec_user_tx_size_in(10:0)
            PIN user_addrs(7:0) gec_user_addrs(7:0)
            PIN GMII_RXD(7:0) GMII_RXD_0_sig(7:0)
            PIN GMII_RX_CLK MASTER_CLK
            PIN user_test_mode XLXN_460
            PIN user_trigger gec_user_trigger
            PIN GMII_RX_DV GMII_RX_DV_0_sig
            PIN GMII_RX_ER GMII_RX_ER_0_sig
            PIN user_rx_size_out(10:0) gec_user_rx_size_out(10:0)
            PIN GMII_TX_EN PHY_TXEN_sig
            PIN GMII_TX_ER PHY_TXER_sig
            PIN GTX_CLK GTX_CLK_0_sig
            PIN user_busy gec_user_busy
            PIN user_rx_valid_out gec_user_rx_valid_out
            PIN user_tx_enable_out gec_user_tx_enable_out
            PIN user_rx_data_out(7:0) gec_user_rx_data_out(7:0)
            PIN GMII_TXD(7:0) PHY_TXD_sig(7:0)
            PIN crc_err gec_user_crc_err
            PIN reset reset
        END BLOCK
        BEGIN BLOCK XLXI_3523 fdre
            PIN C XLXN_12498
            PIN CE GLOBAL_RESET_MAP
            PIN D rx_data(0)
            PIN R reset_extension
            PIN Q software_reset
        END BLOCK
        BEGIN BLOCK XLXI_3535 DATA_MANAGER
            PIN reset reset
            PIN MASTER_CLK MASTER_CLK
            PIN reset_n reset_n
            PIN gec_user_rx_size_out(10:0) gec_user_rx_size_out(10:0)
            PIN gec_user_crc_err gec_user_crc_err
            PIN gec_user_rx_valid_out gec_user_rx_valid_out
            PIN gec_user_rx_data_out(7:0) gec_user_rx_data_out(7:0)
            PIN gec_user_busy gec_user_busy
            PIN gec_user_tx_enable_out gec_user_tx_enable_out
            PIN b_data_we b_data_we
            PIN b_data(63:0) b_data(63:0)
            PIN b_end_packet b_end_packet
            PIN ram_wren rx_wren
            PIN ram_addr(63:0) rx_addr(63:0)
            PIN gec_user_tx_data_in(7:0) gec_user_tx_data_in(7:0)
            PIN gec_user_tx_size_in(10:0) gec_user_tx_size_in(10:0)
            PIN gec_user_trigger gec_user_trigger
            PIN b_enable b_enable
            PIN tx_data(63:0) tx_data(63:0)
            PIN rx_data(63:0) rx_data(63:0)
        END BLOCK
        BEGIN BLOCK XLXI_4297 gnd
            PIN G XLXN_460
        END BLOCK
        BEGIN BLOCK XLXI_4263 gnd
            PIN G gec_user_addrs(4)
        END BLOCK
        BEGIN BLOCK XLXI_4264 gnd
            PIN G gec_user_addrs(5)
        END BLOCK
        BEGIN BLOCK XLXI_4265 gnd
            PIN G gec_user_addrs(6)
        END BLOCK
        BEGIN BLOCK XLXI_4266 gnd
            PIN G gec_user_addrs(7)
        END BLOCK
        BEGIN BLOCK XLXI_4359 VERSION_BLK
            PIN version(7:0) tx_data(63:56)
        END BLOCK
        BEGIN BLOCK XLXI_3521 and2
            PIN I0 reset_extension
            PIN I1 clock_5mhz
            PIN O XLXN_12503
        END BLOCK
        BEGIN BLOCK XLXI_3522 or2
            PIN I0 XLXN_12503
            PIN I1 MASTER_CLK
            PIN O XLXN_12498
        END BLOCK
        BEGIN BLOCK XLXI_3479 fde
            PIN C MASTER_CLK
            PIN CE ADC_TESTMODE_MAP
            PIN D rx_data(0)
            PIN Q adc_testmode_sig
        END BLOCK
        BEGIN BLOCK XLXI_3302 fde
            PIN C MASTER_CLK
            PIN CE DCM_PSI_RESET_MAP
            PIN D rx_data(0)
            PIN Q dcm_reset
        END BLOCK
        BEGIN BLOCK XLXI_3427 fde
            PIN C MASTER_CLK
            PIN CE DCM_PSI_RESET_MAP
            PIN D rx_data(1)
            PIN Q dcm_reset_psi
        END BLOCK
        BEGIN BLOCK XLXI_3405 idelay
            BEGIN ATTR IOBDELAY_TYPE "VARIABLE"
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE StringValList DEFAULT FIXED VARIABLE
            END ATTR
            PIN I ADC_65MSPS_CH0
            PIN CE adc_data_del_ce
            PIN C MASTER_CLK
            PIN INC rx_data(0)
            PIN RST adc_data_del_rst
            PIN O adc_delayed_data(0)
        END BLOCK
        BEGIN BLOCK XLXI_3409 and2
            PIN I0 rx_data(4)
            PIN I1 adc_data_del_ce
            PIN O adc_data_del_rst
        END BLOCK
        BEGIN BLOCK XLXI_3410 dcm_base
            BEGIN ATTR CLKIN_PERIOD 8
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Float
            END ATTR
            BEGIN ATTR CLKFX_MULTIPLY 8
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Integer 2 32
            END ATTR
            BEGIN ATTR CLKFX_DIVIDE 5
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Integer 1 32
            END ATTR
            PIN CLKIN MASTER_CLK
            PIN CLKFB XLXN_12229
            PIN RST reset
            PIN CLK0 XLXN_12220
            PIN CLK90
            PIN CLK180
            PIN CLK270
            PIN CLK2X
            PIN CLK2X180
            PIN CLKDV
            PIN CLKFX XLXN_12257
            PIN CLKFX180
            PIN LOCKED
        END BLOCK
        BEGIN BLOCK XLXI_3411 bufg
            PIN I XLXN_12220
            PIN O XLXN_12229
        END BLOCK
        BEGIN BLOCK XLXI_4466 and2
            PIN I0 rx_data(24)
            PIN I1 ADC_DELAY_MAP
            PIN O adc_data_del_ce
        END BLOCK
        BEGIN BLOCK XLXI_4171 iobuf
            PIN I XLXN_12023
            PIN IO BUSC_21DN_43S
            PIN O reset_button
            PIN T XLXN_12023
        END BLOCK
        BEGIN BLOCK XLXI_3360 inv
            PIN I reset_phy
            PIN O XLXN_12023
        END BLOCK
        BEGIN BLOCK XLXI_4248 ibuf
            PIN I BUSC_16DP_32S
            PIN O GMII_RX_ER_0_sig
        END BLOCK
        BEGIN BLOCK XLXI_4135 ibufg
            PIN I PRIMARY_CLK
            PIN O clock_66mhz
        END BLOCK
        BEGIN BLOCK XLXI_4136 ibufg
            PIN I SECONDARY_CLK
            PIN O clock_5mhz
        END BLOCK
        BEGIN BLOCK XLXI_4181 obuf
            PIN I PHY_TXD_sig(3)
            PIN O BUSC_24DP_48S
        END BLOCK
        BEGIN BLOCK XLXI_4182 obuf
            PIN I PHY_TXD_sig(2)
            PIN O BUSC_24DN_49S
        END BLOCK
        BEGIN BLOCK XLXI_4183 obuf
            PIN I PHY_TXD_sig(1)
            PIN O BUSC_25DP_50S
        END BLOCK
        BEGIN BLOCK XLXI_4184 obuf
            PIN I PHY_TXD_sig(0)
            PIN O BUSC_25DN_51S
        END BLOCK
        BEGIN BLOCK XLXI_4247 obuf
            PIN I PHY_TXD_sig(4)
            PIN O BUSC_15DN_31S
        END BLOCK
        BEGIN BLOCK XLXI_4249 obuf
            PIN I PHY_TXD_sig(5)
            PIN O BUSC_15DP_30S
        END BLOCK
        BEGIN BLOCK XLXI_4250 obuf
            PIN I PHY_TXD_sig(6)
            PIN O BUSC_14DN_29S
        END BLOCK
        BEGIN BLOCK XLXI_4251 obuf
            PIN I PHY_TXD_sig(7)
            PIN O BUSC_14DP_28S
        END BLOCK
        BEGIN BLOCK XLXI_4246 obuf
            PIN I PHY_TXER_sig
            PIN O BUSC_16DN_33S
        END BLOCK
        BEGIN BLOCK XLXI_4213 ibuf
            PIN I BUSC_20DP_40S
            PIN O GMII_RXD_0_sig(7)
        END BLOCK
        BEGIN BLOCK XLXI_4214 ibuf
            PIN I BUSC_20DN_41S
            PIN O GMII_RXD_0_sig(6)
        END BLOCK
        BEGIN BLOCK XLXI_4216 ibuf
            PIN I BUSC_19DP_38S
            PIN O GMII_RXD_0_sig(5)
        END BLOCK
        BEGIN BLOCK XLXI_4217 ibuf
            PIN I BUSC_19DN_39S
            PIN O GMII_RXD_0_sig(4)
        END BLOCK
        BEGIN BLOCK XLXI_4218 ibuf
            PIN I BUSC_18DP_36S
            PIN O GMII_RXD_0_sig(3)
        END BLOCK
        BEGIN BLOCK XLXI_4219 ibuf
            PIN I BUSC_18DN_37S
            PIN O GMII_RXD_0_sig(2)
        END BLOCK
        BEGIN BLOCK XLXI_4220 ibuf
            PIN I BUSC_17DP_34S
            PIN O GMII_RXD_0_sig(1)
        END BLOCK
        BEGIN BLOCK XLXI_4221 ibuf
            PIN I BUSC_17DN_35S
            PIN O GMII_RXD_0_sig(0)
        END BLOCK
        BEGIN BLOCK XLXI_4177 obuf
            PIN I PHY_TXEN_sig
            PIN O BUSC_27DN_55S
        END BLOCK
        BEGIN BLOCK XLXI_4178 ibuf
            PIN I BUSC_27DP_54S
            PIN O GMII_RX_DV_0_sig
        END BLOCK
        BEGIN BLOCK XLXI_4253 ibufg
            PIN I BUSC_26DP_52S
            PIN O MASTER_CLK
        END BLOCK
        BEGIN BLOCK XLXI_4179 obuf
            PIN I GTX_CLK_0_sig
            PIN O BUSC_26DN_53S
        END BLOCK
        BEGIN BLOCK XLXI_4294 ibuf
            PIN I GENERAL_02DP_04S
            PIN O gec_user_addrs(1)
        END BLOCK
        BEGIN BLOCK XLXI_4295 ibuf
            PIN I GENERAL_03DN_07S
            PIN O gec_user_addrs(2)
        END BLOCK
        BEGIN BLOCK XLXI_4296 ibuf
            PIN I GENERAL_02DN_05S
            PIN O gec_user_addrs(0)
        END BLOCK
        BEGIN BLOCK XLXI_4501 ibufds
            BEGIN ATTR DIFF_TERM TRUE
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Boolean
            END ATTR
            PIN I BUSAHS_00DP_00S
            PIN IB BUSAHS_00DN_01S
            PIN O ADC_CLK_OUT
        END BLOCK
        BEGIN BLOCK XLXI_4502 ibufds
            BEGIN ATTR DIFF_TERM TRUE
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Boolean
            END ATTR
            PIN I BUSAHS_01DP_02S
            PIN IB BUSAHS_01DN_03S
            PIN O ADC_FRAME_OUT
        END BLOCK
        BEGIN BLOCK XLXI_4503 obuf
            PIN I ADC_CLK_IN
            PIN O BUSAHS_02DN_05S
        END BLOCK
        BEGIN BLOCK XLXI_4504 ibufds
            BEGIN ATTR DIFF_TERM TRUE
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Boolean
            END ATTR
            PIN I BUSA_16DP_32S
            PIN IB BUSA_16DN_33S
            PIN O ADC_65MSPS_CH0
        END BLOCK
        BEGIN BLOCK XLXI_3406 idelayctrl
            PIN REFCLK XLXN_15064
            PIN RST reset
            PIN RDY
        END BLOCK
        BEGIN BLOCK XLXI_4529 bufg
            PIN I XLXN_12257
            PIN O XLXN_15064
        END BLOCK
        BEGIN BLOCK XLXI_4514 ibufds
            BEGIN ATTR DIFF_TERM TRUE
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Boolean
            END ATTR
            PIN I BUSBB_05DP_10S
            PIN IB BUSBB_05DN_11S
            PIN O psi_token_out0
        END BLOCK
        BEGIN BLOCK XLXI_4513 obufds
            PIN I PSI_CLK90
            PIN O BUSBB_04DP_08S
            PIN OB BUSBB_04DN_09S
        END BLOCK
        BEGIN BLOCK XLXI_4511 obufds
            PIN I psi_data_out0
            PIN O BUSBB_03DP_06S
            PIN OB BUSBB_03DN_07S
        END BLOCK
        BEGIN BLOCK XLXI_4510 obufds
            PIN I psi_token_in
            PIN O BUSBB_00DP_00S
            PIN OB BUSBB_00DN_01S
        END BLOCK
        BEGIN BLOCK XLXI_4509 obuf
            PIN I psi_reset
            PIN O BUSBB_02DP_04S
        END BLOCK
        BEGIN BLOCK XLXI_4506 obufds
            PIN I psi_trigger
            PIN O BUSBB_01DP_02S
            PIN OB BUSBB_01DN_03S
        END BLOCK
        BEGIN BLOCK XLXI_4568 obuf
            PIN I display_ser_data
            PIN O INTERNAL_05DP_10S
        END BLOCK
        BEGIN BLOCK XLXI_4570 obuf
            PIN I XLXN_15151
            PIN O INTERNAL_05DN_11S
        END BLOCK
        BEGIN BLOCK XLXI_4569 obuf
            PIN I display_load_bar
            PIN O INTERNAL_04DN_09S
        END BLOCK
        BEGIN BLOCK XLXI_3265 bufg
            PIN I XLXN_11574
            PIN O ADC_DCM_FB
        END BLOCK
        BEGIN BLOCK XLXI_3254 dcm_adv
            BEGIN ATTR CLKFX_MULTIPLY 16
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Integer 2 32
            END ATTR
            BEGIN ATTR CLKFX_DIVIDE 27
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Integer 1 32
            END ATTR
            BEGIN ATTR DLL_FREQUENCY_MODE "LOW"
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE StringValList LOW HIGH
            END ATTR
            BEGIN ATTR DFS_FREQUENCY_MODE "LOW"
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE StringValList LOW HIGH
            END ATTR
            BEGIN ATTR CLKIN_PERIOD 8
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Float
            END ATTR
            BEGIN ATTR CLKOUT_PHASE_SHIFT "NONE"
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE StringValList NONE FIXED VARIABLE_POSITIVE VARIABLE_CENTER DIRECT
            END ATTR
            PIN CLKIN MASTER_CLK
            PIN CLKFB ADC_DCM_FB
            PIN RST dcm_reset
            PIN PSINCDEC XLXN_12188
            PIN PSEN XLXN_12188
            PIN PSCLK XLXN_12188
            PIN DADDR(6:0) rx_data(6:0)
            PIN DI(15:0) rx_data(23:8)
            PIN DWE ADC_CLOCK_MAP
            PIN DEN ADC_CLOCK_MAP
            PIN DCLK MASTER_CLK
            PIN CLK0 XLXN_11574
            PIN CLK90
            PIN CLK180
            PIN CLK270
            PIN CLK2X
            PIN CLK2X180
            PIN CLKDV
            PIN CLKFX XLXN_15825
            PIN CLKFX180
            PIN LOCKED
            PIN PSDONE
            PIN DO(15:0)
            PIN DRDY
        END BLOCK
        BEGIN BLOCK XLXI_3402 gnd
            PIN G XLXN_12188
        END BLOCK
        BEGIN BLOCK XLXI_4571 inv
            PIN I clock_5mhz
            PIN O XLXN_15151
        END BLOCK
        BEGIN BLOCK XLXI_4618 gnd
            PIN G
        END BLOCK
        BEGIN BLOCK XLXI_4619 gnd
            PIN G
        END BLOCK
        BEGIN BLOCK XLXI_4620 gnd
            PIN G gec_user_addrs(3)
        END BLOCK
        BEGIN BLOCK XLXI_4621 vcc
            PIN P
        END BLOCK
        BEGIN BLOCK XLXI_4559 display_fifo
            PIN rd_clk clock_5mhz
            PIN rd_en XLXN_15149
            PIN rst reset
            PIN wr_clk MASTER_CLK
            PIN wr_en DISPLAY_MAP
            PIN din(7:0) rx_data(7:0)
            PIN empty XLXN_15146
            PIN full
            PIN dout(0:0) display_ser_data
        END BLOCK
        BEGIN BLOCK XLXI_4560 inv
            PIN I XLXN_15146
            PIN O XLXN_15149
        END BLOCK
        BEGIN BLOCK XLXI_4561 fd
            PIN C clock_5mhz
            PIN D XLXN_15146
            PIN Q display_load_bar
        END BLOCK
        BEGIN BLOCK XLXI_3420 idelay
            BEGIN ATTR IOBDELAY_TYPE "VARIABLE"
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE StringValList DEFAULT FIXED VARIABLE
            END ATTR
            PIN I ADC_FRAME_OUT
            PIN CE XLXN_12239
            PIN C MASTER_CLK
            PIN INC rx_data(0)
            PIN RST XLXN_12242
            PIN O adc_delayed_frame
        END BLOCK
        BEGIN BLOCK XLXI_3421 and2
            PIN I0 rx_data(4)
            PIN I1 XLXN_12239
            PIN O XLXN_12242
        END BLOCK
        BEGIN BLOCK XLXI_3423 idelay
            BEGIN ATTR IOBDELAY_TYPE "VARIABLE"
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE StringValList DEFAULT FIXED VARIABLE
            END ATTR
            PIN I ADC_CLK_OUT
            PIN CE XLXN_12249
            PIN C MASTER_CLK
            PIN INC rx_data(0)
            PIN RST XLXN_12252
            PIN O adc_delayed_clk
        END BLOCK
        BEGIN BLOCK XLXI_3424 and2
            PIN I0 rx_data(4)
            PIN I1 XLXN_12249
            PIN O XLXN_12252
        END BLOCK
        BEGIN BLOCK XLXI_4465 and2
            PIN I0 rx_data(25)
            PIN I1 ADC_DELAY_MAP
            PIN O XLXN_12239
        END BLOCK
        BEGIN BLOCK XLXI_4464 and2
            PIN I0 rx_data(26)
            PIN I1 ADC_DELAY_MAP
            PIN O XLXN_12249
        END BLOCK
        BEGIN BLOCK XLXI_4648 idelay
            BEGIN ATTR IOBDELAY_TYPE "VARIABLE"
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE StringValList DEFAULT FIXED VARIABLE
            END ATTR
            PIN I ADC_65MSPS_CH1
            PIN CE XLXN_15849
            PIN C MASTER_CLK
            PIN INC rx_data(0)
            PIN RST XLXN_15850
            PIN O adc_delayed_data(1)
        END BLOCK
        BEGIN BLOCK XLXI_4127 fde
            PIN C MASTER_CLK
            PIN CE PSI_SAMPLE_SEL_MAP
            PIN D rx_data(0)
            PIN Q psi_sample_sel0
        END BLOCK
        BEGIN BLOCK XLXI_4115 ADC_single_frame_counter
            PIN ADC_clk adc_delayed_clk
            PIN ADC_frame adc_delayed_frame
            PIN rst_n reset_n
            PIN ADC_en adc_sample_we
        END BLOCK
        BEGIN BLOCK XLXI_3484 ADC_frame_counter
            PIN ADC_clk adc_delayed_clk
            PIN ADC_frame adc_delayed_frame
            PIN rst_n reset_n
            PIN ADC_en adc_burst_we
        END BLOCK
        BEGIN BLOCK CHIP0_TMGR chip_token_manager
            PIN reset psi_tkn_rst
            PIN clk MASTER_CLK
            PIN token_in token(0)
            PIN first_in_token_chain XLXN_15817
            PIN data_sel b_data_sel
            PIN cal_trig_sel cal_tag_trig_num_sel
            PIN pdin_we b_data_we0
            PIN plaq_id(2:0) plaq_id0(2:0)
            PIN cal_tag(15:0) cal_tag(15:0)
            PIN trig_num(19:0) trigger_number(19:0)
            PIN pdin(63:0) b_data0(63:0)
            PIN bus_dout(63:0) b_data(63:0)
            PIN ovf_err tx_data(0)
            PIN token_out token(1)
            PIN we_out we_out0
        END BLOCK
        BEGIN BLOCK CHIP1_READOUT PSI_Chip_Readout_Blk
            PIN adc_delayed_clk adc_delayed_clk
            PIN adc_delayed_data adc_delayed_data(1)
            PIN reset reset
            PIN rx_addr(4:0) rx_addr(4:0)
            PIN MASTER_CLK MASTER_CLK
            PIN psi_sample_sel psi_sample_sel1
            PIN psi_debug_sample(1:0) psi_debug_sample(1:0)
            PIN PSI_LEVELS_MAP PSI_LEVELS_MAP1
            PIN PSI_CLK90 PSI_CLK90
            PIN psi_token_out psi_token_out1
            PIN adc_data_label(3:0) adc_data_label(3:0)
            PIN rx_data(63:0) rx_data(63:0)
            PIN adc_sample_we adc_sample_we
            PIN adc_burst_we adc_burst_we
            PIN b_data_we b_data_pre_we1
            PIN b_data(63:0) b_data1(63:0)
            PIN b_data_sel b_data_sel
        END BLOCK
        BEGIN BLOCK CHIP0_READOUT PSI_Chip_Readout_Blk
            PIN adc_delayed_clk adc_delayed_clk
            PIN adc_delayed_data adc_delayed_data(0)
            PIN reset reset
            PIN rx_addr(4:0) rx_addr(4:0)
            PIN MASTER_CLK MASTER_CLK
            PIN psi_sample_sel psi_sample_sel0
            PIN psi_debug_sample(1:0) psi_debug_sample(1:0)
            PIN PSI_LEVELS_MAP PSI_LEVELS_MAP0
            PIN PSI_CLK90 PSI_CLK90
            PIN psi_token_out psi_token_out0
            PIN adc_data_label(3:0) adc_data_label(3:0)
            PIN rx_data(63:0) rx_data(63:0)
            PIN adc_sample_we adc_sample_we
            PIN adc_burst_we adc_burst_we
            PIN b_data_we b_data_pre_we0
            PIN b_data(63:0) b_data0(63:0)
            PIN b_data_sel b_data_sel
        END BLOCK
        BEGIN BLOCK CHIP1_TMGR chip_token_manager
            PIN reset psi_tkn_rst
            PIN clk MASTER_CLK
            PIN token_in token(1)
            PIN first_in_token_chain XLXN_15818
            PIN data_sel b_data_sel
            PIN cal_trig_sel cal_tag_trig_num_sel
            PIN pdin_we b_data_we1
            PIN plaq_id(2:0) plaq_id1(2:0)
            PIN cal_tag(15:0) cal_tag(15:0)
            PIN trig_num(19:0) trigger_number(19:0)
            PIN pdin(63:0) b_data1(63:0)
            PIN bus_dout(63:0) b_data(63:0)
            PIN ovf_err tx_data(4)
            PIN token_out token(0)
            PIN we_out we_out1
        END BLOCK
        BEGIN BLOCK XLXI_4090 fde
            PIN C MASTER_CLK
            PIN CE BURST_DATA_SEL_MAP
            PIN D rx_data(0)
            PIN Q b_data_sel
        END BLOCK
        BEGIN BLOCK XLXI_4666 or2
            PIN I0 we_out1
            PIN I1 we_out0
            PIN O b_data_we
        END BLOCK
        BEGIN BLOCK XLXI_4521 obuf
            PIN I adc_testmode_sig
            PIN O GENERAL_03DP_06S
        END BLOCK
        BEGIN BLOCK XLXI_4670 ibufds
            BEGIN ATTR DIFF_TERM TRUE
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Boolean
            END ATTR
            PIN I BUSA_17DP_34S
            PIN IB BUSA_17DN_35S
            PIN O ADC_65MSPS_CH1
        END BLOCK
        BEGIN BLOCK XLXI_3432 d4_16e
            PIN A0 rx_addr(8)
            PIN A1 rx_addr(9)
            PIN A2 rx_addr(10)
            PIN A3 rx_addr(11)
            PIN E XLXN_12617
            PIN D0 MEM_BLK_MAP
            PIN D1 ADC_CLOCK_MAP
            PIN D10 PSI_SAMPLE_SEL_MAP
            PIN D11 PSI_SAMPLE_DEBUG_MAP
            PIN D12 PSI_CMD_FIFO_MAP
            PIN D13 EN_TRIG_TOK_MAP
            PIN D14 DISPLAY_MAP
            PIN D15 PSI_CAL_TAG_MAP
            PIN D2 DCM_PSI_RESET_MAP
            PIN D3 PSI_PULSES_MAP
            PIN D4 PSI_SEROUT_SEL_MAP
            PIN D5 BURST_DATA_SEL_MAP
            PIN D6 ADC_DELAY_MAP
            PIN D7 GLOBAL_RESET_MAP
            PIN D8 ADC_TESTMODE_MAP
            PIN D9 PSI_LEVELS_MAP
        END BLOCK
        BEGIN BLOCK XLXI_4677 d4_16e
            PIN A0 rx_addr(8)
            PIN A1 rx_addr(9)
            PIN A2 rx_addr(10)
            PIN A3 rx_addr(11)
            PIN E XLXN_15755
            PIN D0 ADC_CLK_SEL_MAP
            PIN D1 CHAN1_SPEC_DEL_MAP
            PIN D10
            PIN D11
            PIN D12
            PIN D13
            PIN D14
            PIN D15
            PIN D2 RESET_TRIG_NUM_MAP
            PIN D3
            PIN D4
            PIN D5
            PIN D6
            PIN D7
            PIN D8
            PIN D9
        END BLOCK
        BEGIN BLOCK XLXI_4696 and2
            PIN I0 rx_addr(12)
            PIN I1 rx_wren
            PIN O XLXN_15755
        END BLOCK
        BEGIN BLOCK XLXI_4697 and2b1
            PIN I0 rx_addr(12)
            PIN I1 rx_wren
            PIN O XLXN_12617
        END BLOCK
        BEGIN BLOCK XLXI_4572 and2
            PIN I0 rx_data(0)
            PIN I1 EN_TRIG_TOK_MAP
            PIN O sw_en_pulse
        END BLOCK
        BEGIN BLOCK XLXI_4576 or2
            PIN I0 reset
            PIN I1 sw_trig_reset
            PIN O trig_reset
        END BLOCK
        BEGIN BLOCK XLXI_4592 fdre
            PIN C MASTER_CLK
            PIN CE EN_TRIG_TOK_MAP
            PIN D rx_data(4)
            PIN R reset
            PIN Q sw_trig_reset
        END BLOCK
        BEGIN BLOCK XLXI_4556 psi_cmd_fifo32
            PIN rd_clk PSI_CLK0
            PIN rd_en psi_cmd_fifo_re
            PIN rst reset
            PIN wr_clk MASTER_CLK
            PIN wr_en PSI_CMD_FIFO_MAP
            PIN din(31:0) rx_data(31:0)
            PIN empty psi_cmd_fifo_empty
            PIN full psi_cmd_fifo_full
            PIN dout(31:0) XLXN_15543(31:0)
        END BLOCK
        BEGIN BLOCK XLXI_4536 psi_command_sender
            PIN psi_clk PSI_CLK0
            PIN reset reset
            PIN fifo_empty psi_cmd_fifo_empty
            PIN fifo_full psi_cmd_fifo_full
            PIN data(31:0) XLXN_15543(31:0)
            PIN fifo_re psi_cmd_fifo_re
            PIN data_error tx_data(32)
            PIN we_error tx_data(36)
            PIN data_out psi_data_out
        END BLOCK
        BEGIN BLOCK XLXI_4557 token_trigger_controller
            PIN is_ext_mode rx_data(48)
            PIN use_cal_inject rx_data(56)
            PIN sw_en_pulse sw_en_pulse
            PIN param_we PSI_PULSES_MAP
            PIN ext_trigger psi_extdom_trig
            PIN master_clk MASTER_CLK
            PIN psi_clk PSI_CLK90
            PIN rst trig_reset
            PIN trig_repetition_per(15:0) rx_data(15:0)
            PIN inject_trig_gap(7:0) rx_data(23:16)
            PIN trig_token_gap(15:0) rx_data(39:24)
            PIN num_of_triggers(7:0) rx_data(47:40)
            PIN token psi_token_in
            PIN trigger psi_trigger
            PIN error tx_data(40)
        END BLOCK
        BEGIN BLOCK XLXI_4704 fde
            PIN C MASTER_CLK
            PIN CE PSI_SEROUT_SEL_MAP
            PIN D rx_data(0)
            PIN Q psi_data_out_sel
        END BLOCK
        BEGIN BLOCK XLXI_4037 vcc
            PIN P XLXN_15817
        END BLOCK
        BEGIN BLOCK XLXI_4710 gnd
            PIN G XLXN_15818
        END BLOCK
        BEGIN BLOCK XLXI_4713 and2
            PIN I0 psi_data_out_sel
            PIN I1 psi_data_out
            PIN O psi_data_out1
        END BLOCK
        BEGIN BLOCK XLXI_4714 and2b1
            PIN I0 psi_data_out_sel
            PIN I1 psi_data_out
            PIN O psi_data_out0
        END BLOCK
        BEGIN BLOCK XLXI_4715 ibufds
            BEGIN ATTR DIFF_TERM TRUE
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Boolean
            END ATTR
            PIN I BUSD_23DP_46S
            PIN IB BUSD_23DN_47S
            PIN O psi_token_out1
        END BLOCK
        BEGIN BLOCK XLXI_4716 obufds
            PIN I PSI_CLK90
            PIN O BUSD_22DP_44S
            PIN OB BUSD_22DN_45S
        END BLOCK
        BEGIN BLOCK XLXI_4717 obufds
            PIN I psi_data_out1
            PIN O BUSD_21DP_42S
            PIN OB BUSD_21DN_43S
        END BLOCK
        BEGIN BLOCK XLXI_4718 obufds
            PIN I psi_token_in
            PIN O BUSD_19DP_38S
            PIN OB BUSD_19DN_39S
        END BLOCK
        BEGIN BLOCK XLXI_4719 obuf
            PIN I psi_reset
            PIN O GENERAL_05DN_11S
        END BLOCK
        BEGIN BLOCK XLXI_4720 obufds
            PIN I psi_trigger
            PIN O BUSD_20DP_40S
            PIN OB BUSD_20DN_41S
        END BLOCK
        BEGIN BLOCK XLXI_4738 or2b1
            PIN I0 psi_reset
            PIN I1 reset
            PIN O psi_tkn_rst
        END BLOCK
        BEGIN BLOCK XLXI_4744 and2
            PIN I0 psi_data_out_sel
            PIN I1 PSI_LEVELS_MAP
            PIN O PSI_LEVELS_MAP1
        END BLOCK
        BEGIN BLOCK XLXI_4745 and2b1
            PIN I0 psi_data_out_sel
            PIN I1 PSI_LEVELS_MAP
            PIN O PSI_LEVELS_MAP0
        END BLOCK
        BEGIN BLOCK XLXI_4660 PLAQ_ID_GEN
            PIN plaq_id0(2:0) plaq_id0(2:0)
            PIN plaq_id1(2:0) plaq_id1(2:0)
        END BLOCK
        BEGIN BLOCK XLXI_4746 plaq_enable_blk
            PIN b_data_sel b_data_sel
            PIN psi_data_out_sel psi_data_out_sel
            PIN pre_we0 b_data_pre_we0
            PIN pre_we1 b_data_pre_we1
            PIN debug_sel(1:0) psi_debug_sample(1:0)
            PIN we0 b_data_we0
            PIN we1 b_data_we1
        END BLOCK
        BEGIN BLOCK XLXI_4117 fde
            PIN C MASTER_CLK
            PIN CE PSI_SAMPLE_DEBUG_MAP
            PIN D rx_data(0)
            PIN Q psi_debug_sample(0)
        END BLOCK
        BEGIN BLOCK XLXI_4530 fde
            PIN C MASTER_CLK
            PIN CE PSI_SAMPLE_DEBUG_MAP
            PIN D rx_data(4)
            PIN Q psi_debug_sample(1)
        END BLOCK
        BEGIN BLOCK XLXI_4595 fd16re
            PIN C MASTER_CLK
            PIN CE PSI_CAL_TAG_MAP
            PIN D(15:0) rx_data(15:0)
            PIN R reset
            PIN Q(15:0) cal_tag(15:0)
        END BLOCK
        BEGIN BLOCK XLXI_4753 fde
            PIN C MASTER_CLK
            PIN CE PSI_SAMPLE_SEL_MAP
            PIN D rx_data(4)
            PIN Q psi_sample_sel1
        END BLOCK
        BEGIN BLOCK XLXI_4771 External_Trigger_Handler
            PIN ext_clk EXT_CLK
            PIN ext_trigger EXT_TRIGG
            PIN master_clk MASTER_CLK
            PIN reset reset
            PIN reset_trig_counter reset_trig_counter
            PIN psi_clk PSI_CLK90
            PIN psi_trigger psi_trigger
            PIN psi_trig psi_extdom_trig
            PIN trig_num(19:0) trigger_number(19:0)
        END BLOCK
        BEGIN BLOCK XLXI_3301 fde
            PIN C MASTER_CLK
            PIN CE DCM_PSI_RESET_MAP
            PIN D rx_data(4)
            PIN Q psi_reset
        END BLOCK
        BEGIN BLOCK XLXI_4776 fde
            PIN C MASTER_CLK
            PIN CE ADC_CLK_SEL_MAP
            PIN D rx_data(0)
            PIN Q adc_clk_sel
        END BLOCK
        BEGIN BLOCK XLXI_4124 burst_traffic_controller
            PIN MASTER_CLK MASTER_CLK
            PIN RESET reset
            PIN BURST_WE b_data_we
            PIN BURST_END_PACKET b_end_packet
        END BLOCK
        BEGIN BLOCK XLXI_3497 cb4re
            PIN C adc_delayed_clk
            PIN CE adc_burst_we
            PIN R reset
            PIN CEO
            PIN Q0 adc_data_label(0)
            PIN Q1 adc_data_label(1)
            PIN Q2 adc_data_label(2)
            PIN Q3 adc_data_label(3)
            PIN TC
        END BLOCK
        BEGIN BLOCK XLXI_4781 fde
            PIN C MASTER_CLK
            PIN CE PSI_CAL_TAG_MAP
            PIN D rx_data(16)
            PIN Q cal_tag_trig_num_sel
        END BLOCK
        BEGIN BLOCK XLXI_4615 dcm_base
            BEGIN ATTR CLKIN_PERIOD 74
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Float
            END ATTR
            BEGIN ATTR CLKFX_MULTIPLY 4
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Integer 2 32
            END ATTR
            BEGIN ATTR CLKFX_DIVIDE 4
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Integer 1 32
            END ATTR
            BEGIN ATTR DCM_PERFORMANCE_MODE "MAX_RANGE"
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE StringValList MAX_SPEED MAX_RANGE
            END ATTR
            BEGIN ATTR CLKIN_DIVIDE_BY_2 FALSE
                EDITNAME all:1 sch:0
                EDITTRAIT all:1 sch:0
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Boolean
            END ATTR
            PIN CLKIN XLXN_15824
            PIN CLKFB PSI_CLK0
            PIN RST dcm_reset_psi
            PIN CLK0 XLXN_12172
            PIN CLK90 XLXN_15111
            PIN CLK180
            PIN CLK270
            PIN CLK2X ADC_CLK_IN
            PIN CLK2X180
            PIN CLKDV
            PIN CLKFX
            PIN CLKFX180
            PIN LOCKED
        END BLOCK
        BEGIN BLOCK XLXI_3399 bufg
            PIN I XLXN_12172
            PIN O PSI_CLK0
        END BLOCK
        BEGIN BLOCK XLXI_4544 bufg
            PIN I XLXN_15111
            PIN O PSI_CLK90
        END BLOCK
        BEGIN BLOCK XLXI_4773 m2_1
            PIN D0 INT_HALF_CLK
            PIN D1 EXT_CLK
            PIN S0 adc_clk_sel
            PIN O XLXN_15824
        END BLOCK
        BEGIN BLOCK XLXI_4791 ftc
            PIN C XLXN_15825
            PIN CLR XLXN_15845
            PIN T XLXN_15844
            PIN Q INT_HALF_CLK
        END BLOCK
        BEGIN BLOCK XLXI_4793 gnd
            PIN G XLXN_15845
        END BLOCK
        BEGIN BLOCK XLXI_4792 vcc
            PIN P XLXN_15844
        END BLOCK
        BEGIN BLOCK XLXI_4794 ibufds
            BEGIN ATTR DIFF_TERM TRUE
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Boolean
            END ATTR
            PIN I BUSA_12DP_24S
            PIN IB BUSA_12DN_25S
            PIN O EXT_TRIGG
        END BLOCK
        BEGIN BLOCK XLXI_4795 ibufds
            BEGIN ATTR DIFF_TERM TRUE
                VERILOG all:0 dp:1nosynth wsynop:1 wsynth:1
                VHDL all:0 gm:1nosynth wa:1 wd:1
                VALUETYPE Boolean
            END ATTR
            PIN I BUSA_14DP_28S
            PIN IB BUSA_14DN_29S
            PIN O EXT_CLK
        END BLOCK
        BEGIN BLOCK XLXI_4796 or2
            PIN I0 adc_data_del_ce_ch1
            PIN I1 adc_data_del_ce
            PIN O XLXN_15849
        END BLOCK
        BEGIN BLOCK XLXI_4797 or2
            PIN I0 adc_data_del_rst_ch1
            PIN I1 adc_data_del_rst
            PIN O XLXN_15850
        END BLOCK
        BEGIN BLOCK XLXI_4801 and2
            PIN I0 rx_data(4)
            PIN I1 adc_data_del_ce_ch1
            PIN O adc_data_del_rst_ch1
        END BLOCK
        BEGIN BLOCK XLXI_4802 and2
            PIN I0 rx_data(24)
            PIN I1 CHAN1_SPEC_DEL_MAP
            PIN O adc_data_del_ce_ch1
        END BLOCK
        BEGIN BLOCK XLXI_4834 fde
            PIN C MASTER_CLK
            PIN CE RESET_TRIG_NUM_MAP
            PIN D rx_data(0)
            PIN Q reset_trig_counter
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 7040 5440
        RECTANGLE N 424 276 2684 1532 
        BEGIN BRANCH clock_66mhz
            WIRE 1184 1312 1488 1312
            BEGIN DISPLAY 1488 1312 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH clock_5mhz
            WIRE 1184 1376 1488 1376
            BEGIN DISPLAY 1488 1376 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXD_sig(7:0)
            WIRE 2256 1376 2560 1376
            BEGIN DISPLAY 2256 1376 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RX_DV_0_sig
            WIRE 1184 928 1488 928
            BEGIN DISPLAY 1488 928 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RX_ER_0_sig
            WIRE 1184 992 1488 992
            BEGIN DISPLAY 1488 992 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RXD_0_sig(7:0)
            WIRE 1184 1072 1488 1072
            BEGIN DISPLAY 1488 1072 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GTX_CLK_0_sig
            WIRE 2256 928 2560 928
            BEGIN DISPLAY 2256 928 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXER_sig
            WIRE 2256 992 2560 992
            BEGIN DISPLAY 2256 992 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXEN_sig
            WIRE 2256 1056 2560 1056
            BEGIN DISPLAY 2256 1056 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN DISPLAY 456 364 TEXT GEC_IO
            FONT 64 "Arial"
        END DISPLAY
        RECTANGLE N 3324 240 6396 2964 
        BEGIN DISPLAY 3384 344 TEXT "RESET MANAGER"
            FONT 64 "Arial"
        END DISPLAY
        BEGIN INSTANCE XLXI_4006 3872 864 R0
        END INSTANCE
        BEGIN BRANCH clock_5mhz
            WIRE 3712 832 3872 832
            BEGIN DISPLAY 3712 832 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3430 4560 1216 R0
        BEGIN BRANCH reset_start
            WIRE 4816 1088 5024 1088
            BEGIN DISPLAY 5024 1088 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset_button
            WIRE 4240 1152 4560 1152
            BEGIN DISPLAY 4240 1152 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH initial_reset
            WIRE 4320 832 4416 832
            WIRE 4416 832 4560 832
            WIRE 4560 832 4560 1024
            BEGIN DISPLAY 4416 832 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH software_reset
            WIRE 4304 1088 4560 1088
            BEGIN DISPLAY 4304 1088 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3469 4576 1376 R0
        BEGIN BRANCH software_reset
            WIRE 4384 1312 4576 1312
            BEGIN DISPLAY 4384 1312 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset_phy
            WIRE 4832 1280 5040 1280
            WIRE 5040 1280 5056 1280
            BEGIN DISPLAY 5056 1280 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH initial_reset
            WIRE 4384 1248 4576 1248
            BEGIN DISPLAY 4384 1248 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4007 4608 1472 R0
        BEGIN BRANCH reset_n
            WIRE 4832 1440 4896 1440
            WIRE 4896 1440 4960 1440
            BEGIN DISPLAY 4960 1440 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 4416 1440 4608 1440
            BEGIN DISPLAY 4416 1440 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4004 4080 640 R0
        END INSTANCE
        BEGIN BRANCH clock_5mhz
            WIRE 3920 544 4080 544
            BEGIN DISPLAY 3920 544 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset_start
            WIRE 3856 608 4048 608
            WIRE 4048 608 4080 608
            WIRE 4048 608 4048 672
            WIRE 4048 672 4736 672
            BEGIN DISPLAY 3856 608 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 4992 640 5072 640
            WIRE 5072 640 5088 640
            BEGIN DISPLAY 5088 640 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4005 4736 736 R0
        BEGIN BRANCH reset_extension
            WIRE 4528 544 4544 544
            WIRE 4544 544 4544 608
            WIRE 4544 608 4640 608
            WIRE 4640 608 4736 608
            BEGIN DISPLAY 4640 608 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GTX_CLK_0_sig
            WIRE 1808 2176 2176 2176
            WIRE 2176 2176 2192 2176
            BEGIN DISPLAY 2192 2176 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXEN_sig
            WIRE 1808 2048 2176 2048
            WIRE 2176 2048 2192 2048
            BEGIN DISPLAY 2192 2048 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXD_sig(7:0)
            WIRE 1808 1984 2176 1984
            WIRE 2176 1984 2192 1984
            BEGIN DISPLAY 2192 1984 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXER_sig
            WIRE 1808 2112 2176 2112
            WIRE 2176 2112 2192 2112
            BEGIN DISPLAY 2192 2112 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RX_DV_0_sig
            WIRE 656 2048 672 2048
            WIRE 672 2048 1088 2048
            BEGIN DISPLAY 656 2048 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RX_ER_0_sig
            WIRE 656 2112 672 2112
            WIRE 672 2112 1088 2112
            BEGIN DISPLAY 656 2112 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 656 2176 672 2176
            WIRE 672 2176 1088 2176
            BEGIN DISPLAY 656 2176 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RXD_0_sig(7:0)
            WIRE 656 1984 672 1984
            WIRE 672 1984 1088 1984
            BEGIN DISPLAY 656 1984 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE GEC 1088 2592 R0
            BEGIN DISPLAY 96 -792 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH reset
            WIRE 656 2432 672 2432
            WIRE 672 2432 1088 2432
            BEGIN DISPLAY 656 2432 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_trigger
            WIRE 1024 2800 1040 2800
            WIRE 1040 2800 1088 2800
            BEGIN DISPLAY 1024 2800 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_tx_data_in(7:0)
            WIRE 672 3136 688 3136
            WIRE 688 3136 1088 3136
            BEGIN DISPLAY 672 3136 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_tx_size_in(10:0)
            WIRE 672 3072 688 3072
            WIRE 688 3072 1088 3072
            BEGIN DISPLAY 672 3072 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_crc_err
            WIRE 1808 2944 2032 2944
            WIRE 2032 2944 2048 2944
            BEGIN DISPLAY 2048 2944 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_tx_enable_out
            WIRE 1808 2800 2032 2800
            WIRE 2032 2800 2048 2800
            BEGIN DISPLAY 2048 2800 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_busy
            WIRE 1808 2736 2032 2736
            WIRE 2032 2736 2048 2736
            BEGIN DISPLAY 2048 2736 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_rx_size_out(10:0)
            WIRE 1808 3072 2032 3072
            WIRE 2032 3072 2048 3072
            BEGIN DISPLAY 2048 3072 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_rx_data_out(7:0)
            WIRE 1808 3136 2032 3136
            WIRE 2032 3136 2048 3136
            BEGIN DISPLAY 2048 3136 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_460
            WIRE 832 2736 1088 2736
        END BRANCH
        BEGIN BRANCH gec_user_rx_valid_out
            WIRE 1808 3008 2032 3008
            WIRE 2032 3008 2048 3008
            BEGIN DISPLAY 2048 3008 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_addrs(7:0)
            WIRE 960 2864 976 2864
            WIRE 976 2864 1088 2864
            BEGIN DISPLAY 960 2864 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN DISPLAY 168 120 TEXT GEC_CONTROLLER
            FONT 64 "Arial"
        END DISPLAY
        BEGIN BRANCH MASTER_CLK
            WIRE 1184 752 1488 752
            BEGIN DISPLAY 1488 752 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN DISPLAY 1136 696 TEXT "MASTER_CLK is GMII_RX_CLK"
            FONT 36 "Arial"
        END DISPLAY
        INSTANCE XLXI_3523 5264 2224 R0
        BEGIN BRANCH XLXN_12498
            WIRE 4752 2096 5248 2096
            WIRE 5248 2096 5264 2096
        END BRANCH
        BEGIN BRANCH reset_extension
            WIRE 4960 2192 5264 2192
            BEGIN DISPLAY 4960 2192 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH software_reset
            WIRE 5648 1968 5888 1968
            BEGIN DISPLAY 5888 1968 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(0)
            WIRE 5024 1968 5264 1968
            BEGIN DISPLAY 5024 1968 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_3535 1088 4512 R0
        END INSTANCE
        INSTANCE XLXI_4297 704 2672 R90
        BEGIN BRANCH b_data_we
            WIRE 864 4640 880 4640
            WIRE 880 4640 1088 4640
            BEGIN DISPLAY 864 4640 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_end_packet
            WIRE 864 4768 880 4768
            WIRE 880 4768 1088 4768
            BEGIN DISPLAY 864 4768 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data(63:0)
            WIRE 864 4704 880 4704
            WIRE 880 4704 1088 4704
            BEGIN DISPLAY 864 4704 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 864 3872 880 3872
            WIRE 880 3872 1088 3872
            BEGIN DISPLAY 864 3872 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset_n
            WIRE 864 3824 880 3824
            WIRE 880 3824 1088 3824
            BEGIN DISPLAY 864 3824 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 864 3776 880 3776
            WIRE 880 3776 1088 3776
            BEGIN DISPLAY 864 3776 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_crc_err
            WIRE 864 3968 880 3968
            WIRE 880 3968 1088 3968
            BEGIN DISPLAY 864 3968 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_busy
            WIRE 864 4032 880 4032
            WIRE 880 4032 1088 4032
            BEGIN DISPLAY 864 4032 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_rx_valid_out
            WIRE 864 4096 880 4096
            WIRE 880 4096 1088 4096
            BEGIN DISPLAY 864 4096 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_tx_enable_out
            WIRE 864 4160 880 4160
            WIRE 880 4160 1088 4160
            BEGIN DISPLAY 864 4160 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_rx_data_out(7:0)
            WIRE 864 4224 880 4224
            WIRE 880 4224 1088 4224
            BEGIN DISPLAY 864 4224 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_rx_size_out(10:0)
            WIRE 864 4288 880 4288
            WIRE 880 4288 1088 4288
            BEGIN DISPLAY 864 4288 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH tx_data(63:0)
            WIRE 864 4528 880 4528
            WIRE 880 4528 1088 4528
            BEGIN DISPLAY 864 4528 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(63:0)
            WIRE 1824 4528 2032 4528
            WIRE 2032 4528 2048 4528
            BEGIN DISPLAY 2048 4528 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_addr(63:0)
            WIRE 1824 4464 2032 4464
            WIRE 2032 4464 2048 4464
            BEGIN DISPLAY 2048 4464 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_enable
            WIRE 1824 4640 2048 4640
            BEGIN DISPLAY 2048 4640 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_wren
            WIRE 1824 4400 2032 4400
            WIRE 2032 4400 2048 4400
            BEGIN DISPLAY 2048 4400 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_trigger
            WIRE 1824 3968 2032 3968
            WIRE 2032 3968 2048 3968
            BEGIN DISPLAY 2048 3968 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_tx_data_in(7:0)
            WIRE 1824 4032 2032 4032
            WIRE 2032 4032 2048 4032
            BEGIN DISPLAY 2048 4032 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_tx_size_in(10:0)
            WIRE 1824 4096 2032 4096
            WIRE 2032 4096 2048 4096
            BEGIN DISPLAY 2048 4096 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_addrs(0)
            WIRE 2800 2272 2816 2272
            WIRE 2816 2272 2896 2272
            BEGIN DISPLAY 2800 2272 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_addrs(1)
            WIRE 2800 2368 2816 2368
            WIRE 2816 2368 2896 2368
            BEGIN DISPLAY 2800 2368 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_addrs(2)
            WIRE 2800 2464 2816 2464
            WIRE 2816 2464 2896 2464
            BEGIN DISPLAY 2800 2464 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_addrs(3)
            WIRE 2800 2560 2816 2560
            WIRE 2816 2560 2896 2560
            BEGIN DISPLAY 2800 2560 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_addrs(4)
            WIRE 2800 2656 2816 2656
            WIRE 2816 2656 2896 2656
            BEGIN DISPLAY 2800 2656 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_addrs(5)
            WIRE 2800 2752 2816 2752
            WIRE 2816 2752 2896 2752
            BEGIN DISPLAY 2800 2752 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_addrs(6)
            WIRE 2800 2848 2816 2848
            WIRE 2816 2848 2896 2848
            BEGIN DISPLAY 2800 2848 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_addrs(7)
            WIRE 2800 2944 2816 2944
            WIRE 2816 2944 2896 2944
            BEGIN DISPLAY 2800 2944 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_addrs(7:0)
            WIRE 2800 2176 2928 2176
            BEGIN DISPLAY 2800 2176 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4263 3024 2720 R270
        INSTANCE XLXI_4264 3024 2816 R270
        INSTANCE XLXI_4265 3024 2912 R270
        INSTANCE XLXI_4266 3024 3008 R270
        BEGIN BRANCH tx_data(63:56)
            WIRE 2000 3488 2112 3488
            BEGIN DISPLAY 2112 3488 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4359 1616 3520 R0
        END INSTANCE
        BEGIN BRANCH tx_data(63:0)
            WIRE 2176 3344 2320 3344
            BEGIN DISPLAY 2320 3344 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GLOBAL_RESET_MAP
            WIRE 5088 2032 5264 2032
            BEGIN DISPLAY 5088 2032 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3521 3936 2224 R0
        INSTANCE XLXI_3522 4496 2192 R0
        BEGIN BRANCH reset_extension
            WIRE 3744 2160 3936 2160
            BEGIN DISPLAY 3744 2160 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH clock_5mhz
            WIRE 3760 2096 3936 2096
            BEGIN DISPLAY 3760 2096 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_12503
            WIRE 4192 2128 4496 2128
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 4400 2064 4496 2064
            BEGIN DISPLAY 4400 2064 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4618 3280 2336 R270
        INSTANCE XLXI_4619 3280 2432 R270
        INSTANCE XLXI_4621 3152 2496 R90
        INSTANCE XLXI_4620 3024 2624 R270
        BEGIN BRANCH ADC_CLOCK_MAP
            WIRE 5120 3200 5264 3200
            WIRE 5264 3200 5280 3200
            BEGIN DISPLAY 5280 3200 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH DCM_PSI_RESET_MAP
            WIRE 5120 3264 5264 3264
            WIRE 5264 3264 5280 3264
            BEGIN DISPLAY 5280 3264 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_PULSES_MAP
            WIRE 5120 3328 5264 3328
            WIRE 5264 3328 5280 3328
            BEGIN DISPLAY 5280 3328 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_addr(8)
            WIRE 4544 3136 4560 3136
            WIRE 4560 3136 4736 3136
            BEGIN DISPLAY 4544 3136 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_addr(9)
            WIRE 4544 3200 4560 3200
            WIRE 4560 3200 4736 3200
            BEGIN DISPLAY 4544 3200 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_addr(10)
            WIRE 4544 3264 4560 3264
            WIRE 4560 3264 4736 3264
            BEGIN DISPLAY 4544 3264 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BURST_DATA_SEL_MAP
            WIRE 5120 3456 5264 3456
            WIRE 5264 3456 5280 3456
            BEGIN DISPLAY 5280 3456 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ADC_DELAY_MAP
            WIRE 5120 3520 5264 3520
            WIRE 5264 3520 5280 3520
            BEGIN DISPLAY 5280 3520 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GLOBAL_RESET_MAP
            WIRE 5120 3584 5264 3584
            WIRE 5264 3584 5280 3584
            BEGIN DISPLAY 5280 3584 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3432 4736 4224 R0
        BEGIN BRANCH rx_addr(11)
            WIRE 4544 3328 4560 3328
            WIRE 4560 3328 4736 3328
            BEGIN DISPLAY 4544 3328 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ADC_TESTMODE_MAP
            WIRE 5120 3648 5264 3648
            WIRE 5264 3648 5280 3648
            BEGIN DISPLAY 5280 3648 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_LEVELS_MAP
            WIRE 5120 3712 5264 3712
            WIRE 5264 3712 5280 3712
            BEGIN DISPLAY 5280 3712 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_SAMPLE_SEL_MAP
            WIRE 5120 3776 5264 3776
            WIRE 5264 3776 5280 3776
            BEGIN DISPLAY 5280 3776 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_SAMPLE_DEBUG_MAP
            WIRE 5120 3840 5264 3840
            WIRE 5264 3840 5280 3840
            BEGIN DISPLAY 5280 3840 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MEM_BLK_MAP
            WIRE 5120 3136 5264 3136
            WIRE 5264 3136 5280 3136
            BEGIN DISPLAY 5280 3136 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_12617
            WIRE 4656 4096 4736 4096
        END BRANCH
        BEGIN BRANCH PSI_CMD_FIFO_MAP
            WIRE 5120 3904 5280 3904
            BEGIN DISPLAY 5280 3904 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH EN_TRIG_TOK_MAP
            WIRE 5120 3968 5280 3968
            BEGIN DISPLAY 5280 3968 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH DISPLAY_MAP
            WIRE 5120 4032 5280 4032
            BEGIN DISPLAY 5280 4032 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_CAL_TAG_MAP
            WIRE 5120 4096 5280 4096
            BEGIN DISPLAY 5280 4096 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4696 4416 5376 R0
        BEGIN BRANCH rx_addr(12)
            WIRE 4272 4128 4400 4128
            BEGIN DISPLAY 4272 4128 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_wren
            WIRE 4288 4064 4400 4064
            BEGIN DISPLAY 4288 4064 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4697 4400 4192 R0
        BEGIN BRANCH rx_wren
            WIRE 4272 5248 4416 5248
            BEGIN DISPLAY 4272 5248 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_addr(12)
            WIRE 4272 5312 4416 5312
            BEGIN DISPLAY 4272 5312 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_SEROUT_SEL_MAP
            WIRE 5120 3392 5264 3392
            WIRE 5264 3392 5280 3392
            BEGIN DISPLAY 5280 3392 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ADC_CLK_SEL_MAP
            WIRE 5136 4320 5280 4320
            WIRE 5280 4320 5296 4320
            BEGIN DISPLAY 5296 4320 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_15755
            WIRE 4672 5280 4688 5280
            WIRE 4688 5280 4752 5280
        END BRANCH
        BEGIN BRANCH rx_addr(11)
            WIRE 4560 4512 4576 4512
            WIRE 4576 4512 4752 4512
            BEGIN DISPLAY 4560 4512 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_addr(10)
            WIRE 4560 4448 4576 4448
            WIRE 4576 4448 4752 4448
            BEGIN DISPLAY 4560 4448 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_addr(9)
            WIRE 4560 4384 4576 4384
            WIRE 4576 4384 4752 4384
            BEGIN DISPLAY 4560 4384 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_addr(8)
            WIRE 4560 4320 4576 4320
            WIRE 4576 4320 4752 4320
            BEGIN DISPLAY 4560 4320 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4677 4752 5408 R0
        BEGIN BRANCH CHAN1_SPEC_DEL_MAP
            WIRE 5136 4384 5296 4384
            BEGIN DISPLAY 5296 4384 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH RESET_TRIG_NUM_MAP
            WIRE 5136 4448 5264 4448
            WIRE 5264 4448 5312 4448
            BEGIN DISPLAY 5312 4448 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
    END SHEET
    BEGIN SHEET 2 7040 5440
        RECTANGLE N 80 48 3792 2324 
        BEGIN DISPLAY 180 148 TEXT "PSI CONTROLLER"
            FONT 40 "Arial"
        END DISPLAY
        BEGIN BRANCH rx_data(0)
            WIRE 5264 192 5344 192
            BEGIN DISPLAY 5264 192 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_sample_sel0
            WIRE 5728 192 5968 192
            BEGIN DISPLAY 5968 192 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4127 5344 448 R0
        BEGIN BRANCH MASTER_CLK
            WIRE 5248 320 5344 320
            BEGIN DISPLAY 5248 320 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_SAMPLE_SEL_MAP
            WIRE 5168 256 5344 256
            BEGIN DISPLAY 5168 256 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_delayed_clk
            WIRE 528 2576 592 2576
            BEGIN DISPLAY 528 2576 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_delayed_frame
            WIRE 528 2640 592 2640
            BEGIN DISPLAY 528 2640 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset_n
            WIRE 528 2704 592 2704
            BEGIN DISPLAY 528 2704 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4115 592 2736 R0
        END INSTANCE
        BEGIN BRANCH adc_burst_we
            WIRE 976 2848 1104 2848
            BEGIN DISPLAY 1104 2848 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_delayed_clk
            WIRE 496 2848 592 2848
            BEGIN DISPLAY 496 2848 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_delayed_frame
            WIRE 512 2912 592 2912
            BEGIN DISPLAY 512 2912 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset_n
            WIRE 512 2976 592 2976
            BEGIN DISPLAY 512 2976 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_3484 592 3008 R0
        END INSTANCE
        BEGIN BRANCH adc_sample_we
            WIRE 976 2576 1104 2576
            BEGIN DISPLAY 1104 2576 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_sel
            WIRE 3600 4848 3616 4848
            WIRE 3616 4848 3680 4848
            BEGIN DISPLAY 3600 4848 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE CHIP1_READOUT 3680 5008 R0
            BEGIN DISPLAY 48 -920 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH adc_burst_we
            WIRE 3600 5104 3680 5104
            BEGIN DISPLAY 3600 5104 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_sample_we
            WIRE 3600 5040 3680 5040
            BEGIN DISPLAY 3600 5040 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(63:0)
            WIRE 3600 4976 3680 4976
            BEGIN DISPLAY 3600 4976 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_data_label(3:0)
            WIRE 3600 4912 3680 4912
            BEGIN DISPLAY 3600 4912 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_token_out1
            WIRE 3600 4784 3680 4784
            BEGIN DISPLAY 3600 4784 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_CLK90
            WIRE 3600 4720 3680 4720
            BEGIN DISPLAY 3600 4720 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_debug_sample(1:0)
            WIRE 3600 4592 3680 4592
            BEGIN DISPLAY 3600 4592 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_sample_sel1
            WIRE 3600 4528 3680 4528
            BEGIN DISPLAY 3600 4528 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 3600 4464 3680 4464
            BEGIN DISPLAY 3600 4464 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_addr(4:0)
            WIRE 3600 4400 3680 4400
            BEGIN DISPLAY 3600 4400 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 3600 4336 3680 4336
            BEGIN DISPLAY 3600 4336 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_delayed_data(1)
            WIRE 3600 4272 3680 4272
            BEGIN DISPLAY 3600 4272 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_delayed_clk
            WIRE 3600 4208 3680 4208
            BEGIN DISPLAY 3600 4208 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE CHIP0_READOUT 1424 5024 R0
            BEGIN DISPLAY 48 -920 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH adc_delayed_clk
            WIRE 1344 4224 1424 4224
            BEGIN DISPLAY 1344 4224 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_delayed_data(0)
            WIRE 1344 4288 1424 4288
            BEGIN DISPLAY 1344 4288 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 1344 4352 1424 4352
            BEGIN DISPLAY 1344 4352 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_addr(4:0)
            WIRE 1344 4416 1424 4416
            BEGIN DISPLAY 1344 4416 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 1344 4480 1424 4480
            BEGIN DISPLAY 1344 4480 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_sample_sel0
            WIRE 1344 4544 1424 4544
            BEGIN DISPLAY 1344 4544 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_debug_sample(1:0)
            WIRE 1344 4608 1424 4608
            BEGIN DISPLAY 1344 4608 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_CLK90
            WIRE 1344 4736 1424 4736
            BEGIN DISPLAY 1344 4736 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_token_out0
            WIRE 1344 4800 1424 4800
            BEGIN DISPLAY 1344 4800 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_data_label(3:0)
            WIRE 1344 4928 1424 4928
            BEGIN DISPLAY 1344 4928 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(63:0)
            WIRE 1344 4992 1424 4992
            BEGIN DISPLAY 1344 4992 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_sample_we
            WIRE 1344 5056 1424 5056
            BEGIN DISPLAY 1344 5056 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_burst_we
            WIRE 1344 5120 1424 5120
            BEGIN DISPLAY 1344 5120 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE CHIP0_TMGR 2512 3888 R0
            BEGIN DISPLAY 144 -600 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN INSTANCE CHIP1_TMGR 4656 3872 R0
            BEGIN DISPLAY 128 -600 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH MASTER_CLK
            WIRE 2432 3472 2512 3472
            BEGIN DISPLAY 2432 3472 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH token(0)
            WIRE 2432 3536 2512 3536
            BEGIN DISPLAY 2432 3536 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_sel
            WIRE 2432 3664 2512 3664
            BEGIN DISPLAY 2432 3664 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_we0
            WIRE 2432 3728 2512 3728
            BEGIN DISPLAY 2432 3728 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH plaq_id0(2:0)
            WIRE 2432 3792 2512 3792
            BEGIN DISPLAY 2432 3792 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data0(63:0)
            WIRE 2432 3856 2512 3856
            BEGIN DISPLAY 2432 3856 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH tx_data(0)
            WIRE 3040 3408 3120 3408
            BEGIN DISPLAY 3120 3408 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH token(1)
            WIRE 3040 3552 3120 3552
            BEGIN DISPLAY 3120 3552 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH we_out0
            WIRE 3040 3696 3120 3696
            BEGIN DISPLAY 3120 3696 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(0)
            WIRE 512 3280 592 3280
            BEGIN DISPLAY 512 3280 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_sel
            WIRE 976 3280 1120 3280
            BEGIN DISPLAY 1120 3280 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4090 592 3536 R0
        BEGIN BRANCH MASTER_CLK
            WIRE 496 3408 592 3408
            BEGIN DISPLAY 496 3408 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BURST_DATA_SEL_MAP
            WIRE 416 3344 592 3344
            BEGIN DISPLAY 416 3344 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_sel
            WIRE 1344 4864 1424 4864
            BEGIN DISPLAY 1344 4864 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 4576 3456 4656 3456
            BEGIN DISPLAY 4576 3456 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH token(1)
            WIRE 4576 3520 4656 3520
            BEGIN DISPLAY 4576 3520 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_sel
            WIRE 4576 3648 4656 3648
            BEGIN DISPLAY 4576 3648 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_we1
            WIRE 4576 3712 4656 3712
            BEGIN DISPLAY 4576 3712 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH plaq_id1(2:0)
            WIRE 4576 3776 4656 3776
            BEGIN DISPLAY 4576 3776 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data1(63:0)
            WIRE 4576 3840 4656 3840
            BEGIN DISPLAY 4576 3840 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH tx_data(4)
            WIRE 5184 3392 5264 3392
            BEGIN DISPLAY 5264 3392 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH token(0)
            WIRE 5184 3536 5264 3536
            BEGIN DISPLAY 5264 3536 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH we_out1
            WIRE 5184 3680 5264 3680
            BEGIN DISPLAY 5264 3680 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4666 4304 2736 R0
        BEGIN BRANCH we_out0
            WIRE 4224 2608 4304 2608
            BEGIN DISPLAY 4224 2608 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH we_out1
            WIRE 4224 2672 4304 2672
            BEGIN DISPLAY 4224 2672 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH cal_tag(15:0)
            WIRE 2432 3920 2448 3920
            WIRE 2448 3920 2512 3920
            BEGIN DISPLAY 2432 3920 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH cal_tag(15:0)
            WIRE 4576 3904 4592 3904
            WIRE 4592 3904 4656 3904
            BEGIN DISPLAY 4576 3904 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4572 1248 1568 R0
        BEGIN BRANCH EN_TRIG_TOK_MAP
            WIRE 1120 1440 1248 1440
            BEGIN DISPLAY 1120 1440 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(0)
            WIRE 1120 1504 1248 1504
            BEGIN DISPLAY 1120 1504 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH sw_en_pulse
            WIRE 1504 1472 1584 1472
            BEGIN DISPLAY 1584 1472 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4576 1632 2176 R0
        BEGIN BRANCH sw_trig_reset
            WIRE 1504 2048 1632 2048
            BEGIN DISPLAY 1504 2048 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 1504 2112 1632 2112
            BEGIN DISPLAY 1504 2112 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH trig_reset
            WIRE 1888 2080 1968 2080
            BEGIN DISPLAY 1968 2080 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4592 768 2048 R0
        BEGIN BRANCH MASTER_CLK
            WIRE 640 1920 768 1920
            BEGIN DISPLAY 640 1920 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 656 2016 768 2016
            BEGIN DISPLAY 656 2016 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH sw_trig_reset
            WIRE 1152 1792 1328 1792
            BEGIN DISPLAY 1328 1792 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(4)
            WIRE 640 1792 768 1792
            BEGIN DISPLAY 640 1792 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH EN_TRIG_TOK_MAP
            WIRE 640 1856 768 1856
            BEGIN DISPLAY 640 1856 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_CMD_FIFO_MAP
            WIRE 1504 512 1520 512
            WIRE 1520 512 1728 512
            BEGIN DISPLAY 1504 512 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4556 1728 608 R0
        END INSTANCE
        BEGIN BRANCH psi_cmd_fifo_full
            WIRE 2112 416 2192 416
            BEGIN DISPLAY 2192 416 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_cmd_fifo_empty
            WIRE 2112 256 2192 256
            BEGIN DISPLAY 2192 256 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_CLK0
            WIRE 1504 256 1728 256
            BEGIN DISPLAY 1504 256 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_cmd_fifo_re
            WIRE 1504 320 1728 320
            BEGIN DISPLAY 1504 320 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 1504 384 1728 384
            BEGIN DISPLAY 1504 384 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 1504 448 1728 448
            BEGIN DISPLAY 1504 448 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(31:0)
            WIRE 1504 576 1728 576
            BEGIN DISPLAY 1504 576 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_15543(31:0)
            WIRE 2112 576 2128 576
            WIRE 2128 576 2736 576
        END BRANCH
        BEGIN INSTANCE XLXI_4536 2736 608 R0
        END INSTANCE
        BEGIN BRANCH PSI_CLK0
            WIRE 2640 384 2736 384
            BEGIN DISPLAY 2640 384 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 2640 448 2736 448
            BEGIN DISPLAY 2640 448 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH tx_data(32)
            WIRE 3120 384 3408 384
            BEGIN DISPLAY 3408 384 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH tx_data(36)
            WIRE 3120 480 3408 480
            BEGIN DISPLAY 3408 480 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_cmd_fifo_re
            WIRE 3120 704 3408 704
            BEGIN DISPLAY 3408 704 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_cmd_fifo_empty
            WIRE 2656 704 2736 704
            BEGIN DISPLAY 2656 704 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_cmd_fifo_full
            WIRE 2656 768 2736 768
            BEGIN DISPLAY 2656 768 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4557 2720 2176 R0
        END INSTANCE
        BEGIN BRANCH PSI_CLK90
            WIRE 2592 1824 2720 1824
            BEGIN DISPLAY 2592 1824 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 2592 1760 2720 1760
            BEGIN DISPLAY 2592 1760 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH trig_reset
            WIRE 2592 1888 2720 1888
            BEGIN DISPLAY 2592 1888 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_PULSES_MAP
            WIRE 2592 1632 2720 1632
            BEGIN DISPLAY 2592 1632 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(56)
            WIRE 2592 1504 2720 1504
            BEGIN DISPLAY 2592 1504 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(48)
            WIRE 2592 1440 2720 1440
            BEGIN DISPLAY 2592 1440 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(15:0)
            WIRE 2592 1952 2720 1952
            BEGIN DISPLAY 2592 1952 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(23:16)
            WIRE 2592 2016 2720 2016
            BEGIN DISPLAY 2592 2016 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(39:24)
            WIRE 2592 2080 2720 2080
            BEGIN DISPLAY 2592 2080 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(47:40)
            WIRE 2592 2144 2720 2144
            BEGIN DISPLAY 2592 2144 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_token_in
            WIRE 3200 1440 3504 1440
            BEGIN DISPLAY 3504 1440 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_trigger
            WIRE 3200 1792 3504 1792
            BEGIN DISPLAY 3504 1792 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH tx_data(40)
            WIRE 3200 2144 3504 2144
            BEGIN DISPLAY 3504 2144 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH sw_en_pulse
            WIRE 2592 1568 2720 1568
            BEGIN DISPLAY 2592 1568 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(0)
            WIRE 768 944 848 944
            BEGIN DISPLAY 768 944 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_data_out_sel
            WIRE 1232 944 1296 944
            BEGIN DISPLAY 1296 944 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4704 848 1200 R0
        BEGIN BRANCH MASTER_CLK
            WIRE 752 1072 848 1072
            BEGIN DISPLAY 752 1072 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_SEROUT_SEL_MAP
            WIRE 672 1008 848 1008
            BEGIN DISPLAY 672 1008 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_15817
            WIRE 2448 3600 2512 3600
        END BRANCH
        INSTANCE XLXI_4037 2448 3664 R270
        BEGIN BRANCH XLXN_15818
            WIRE 4608 3584 4656 3584
        END BRANCH
        INSTANCE XLXI_4710 4480 3520 R90
        BEGIN BRANCH token(1:0)
            WIRE 3648 3296 3760 3296
            WIRE 3760 3296 3856 3296
            BEGIN DISPLAY 3760 3296 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_tkn_rst
            WIRE 2400 3408 2432 3408
            WIRE 2432 3408 2496 3408
            WIRE 2496 3408 2512 3408
            BEGIN DISPLAY 2432 3408 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_tkn_rst
            WIRE 4576 3392 4656 3392
            BEGIN DISPLAY 4576 3392 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_data_out0
            WIRE 3440 944 3536 944
            BEGIN DISPLAY 3536 944 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_data_out1
            WIRE 3440 1104 3536 1104
            BEGIN DISPLAY 3536 1104 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_data_out
            WIRE 3120 576 3408 576
            BEGIN DISPLAY 3408 576 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_data_out
            WIRE 3072 912 3184 912
            BEGIN DISPLAY 3072 912 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_data_out
            WIRE 3072 1072 3168 1072
            WIRE 3168 1072 3184 1072
            BEGIN DISPLAY 3072 1072 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4713 3184 1200 R0
        INSTANCE XLXI_4714 3184 1040 R0
        BEGIN BRANCH psi_data_out_sel
            WIRE 3104 976 3184 976
            BEGIN DISPLAY 3104 976 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_data_out_sel
            WIRE 3104 1136 3184 1136
            BEGIN DISPLAY 3104 1136 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data0(63:0)
            WIRE 1968 4992 2048 4992
            BEGIN DISPLAY 2048 4992 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data(63:0)
            WIRE 3040 3840 3120 3840
            BEGIN DISPLAY 3120 3840 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data1(63:0)
            WIRE 4224 4976 4304 4976
            BEGIN DISPLAY 4304 4976 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data(63:0)
            WIRE 5184 3824 5264 3824
            BEGIN DISPLAY 5264 3824 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_pre_we0
            WIRE 1968 4224 2048 4224
            BEGIN DISPLAY 2048 4224 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_pre_we1
            WIRE 4224 4208 4304 4208
            BEGIN DISPLAY 4304 4208 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_we
            WIRE 4560 2640 4640 2640
            BEGIN DISPLAY 4640 2640 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4738 2144 3504 R0
        BEGIN BRANCH psi_reset
            WIRE 2064 3440 2144 3440
            BEGIN DISPLAY 2064 3440 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 2032 3376 2144 3376
            BEGIN DISPLAY 2032 3376 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_LEVELS_MAP0
            WIRE 960 3792 1056 3792
            BEGIN DISPLAY 1056 3792 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_LEVELS_MAP1
            WIRE 960 3952 1056 3952
            BEGIN DISPLAY 1056 3952 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4744 704 4048 R0
        INSTANCE XLXI_4745 704 3888 R0
        BEGIN BRANCH psi_data_out_sel
            WIRE 624 3824 704 3824
            BEGIN DISPLAY 624 3824 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_data_out_sel
            WIRE 624 3984 704 3984
            BEGIN DISPLAY 624 3984 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_LEVELS_MAP
            WIRE 624 3760 704 3760
            BEGIN DISPLAY 624 3760 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_LEVELS_MAP
            WIRE 624 3920 704 3920
            BEGIN DISPLAY 624 3920 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_LEVELS_MAP0
            WIRE 1344 4672 1424 4672
            BEGIN DISPLAY 1344 4672 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_LEVELS_MAP1
            WIRE 3600 4656 3680 4656
            BEGIN DISPLAY 3600 4656 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4660 3072 2656 R0
        END INSTANCE
        BEGIN BRANCH plaq_id0(2:0)
            WIRE 3456 2560 3536 2560
            BEGIN DISPLAY 3536 2560 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH plaq_id1(2:0)
            WIRE 3456 2624 3536 2624
            BEGIN DISPLAY 3536 2624 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4746 2048 2864 R0
        END INSTANCE
        BEGIN BRANCH b_data_we0
            WIRE 2432 2576 2512 2576
            BEGIN DISPLAY 2512 2576 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_we1
            WIRE 2432 2832 2512 2832
            BEGIN DISPLAY 2512 2832 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_pre_we0
            WIRE 1936 2704 2048 2704
            BEGIN DISPLAY 1936 2704 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_pre_we1
            WIRE 1936 2768 2032 2768
            WIRE 2032 2768 2048 2768
            BEGIN DISPLAY 1936 2768 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_debug_sample(1:0)
            WIRE 1968 2832 2048 2832
            BEGIN DISPLAY 1968 2832 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_sel
            WIRE 1968 2576 1984 2576
            WIRE 1984 2576 2048 2576
            BEGIN DISPLAY 1968 2576 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_data_out_sel
            WIRE 1968 2640 2048 2640
            BEGIN DISPLAY 1968 2640 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(0)
            WIRE 5264 864 5344 864
            BEGIN DISPLAY 5264 864 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_debug_sample(0)
            WIRE 5728 864 5968 864
            BEGIN DISPLAY 5968 864 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4117 5344 1120 R0
        BEGIN BRANCH MASTER_CLK
            WIRE 5248 992 5344 992
            BEGIN DISPLAY 5248 992 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_SAMPLE_DEBUG_MAP
            WIRE 5168 928 5344 928
            BEGIN DISPLAY 5168 928 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(4)
            WIRE 5264 1200 5344 1200
            BEGIN DISPLAY 5264 1200 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_debug_sample(1)
            WIRE 5728 1200 5968 1200
            BEGIN DISPLAY 5968 1200 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4530 5344 1456 R0
        BEGIN BRANCH MASTER_CLK
            WIRE 5248 1328 5344 1328
            BEGIN DISPLAY 5248 1328 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_SAMPLE_DEBUG_MAP
            WIRE 5168 1264 5344 1264
            BEGIN DISPLAY 5168 1264 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4595 5344 1792 R0
        BEGIN BRANCH cal_tag(15:0)
            WIRE 5728 1536 5856 1536
            BEGIN DISPLAY 5856 1536 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(15:0)
            WIRE 5184 1536 5344 1536
            BEGIN DISPLAY 5184 1536 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_CAL_TAG_MAP
            WIRE 5184 1600 5344 1600
            BEGIN DISPLAY 5184 1600 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 5184 1664 5344 1664
            BEGIN DISPLAY 5184 1664 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 5184 1760 5344 1760
            BEGIN DISPLAY 5184 1760 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(4)
            WIRE 5264 528 5344 528
            BEGIN DISPLAY 5264 528 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_sample_sel1
            WIRE 5728 528 5968 528
            BEGIN DISPLAY 5968 528 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4753 5344 784 R0
        BEGIN BRANCH MASTER_CLK
            WIRE 5248 656 5344 656
            BEGIN DISPLAY 5248 656 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_SAMPLE_SEL_MAP
            WIRE 5168 592 5344 592
            BEGIN DISPLAY 5168 592 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_extdom_trig
            WIRE 2576 1696 2720 1696
            BEGIN DISPLAY 2576 1696 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4771 3072 3024 R0
        END INSTANCE
        BEGIN BRANCH EXT_CLK
            WIRE 2992 2800 3072 2800
            BEGIN DISPLAY 2992 2800 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH EXT_TRIGG
            WIRE 2992 2864 3072 2864
            BEGIN DISPLAY 2992 2864 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 2992 2928 3072 2928
            BEGIN DISPLAY 2992 2928 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 2992 2992 3072 2992
            BEGIN DISPLAY 2992 2992 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH trigger_number(19:0)
            WIRE 3520 2800 3600 2800
            BEGIN DISPLAY 3600 2800 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH trigger_number(19:0)
            WIRE 2432 3984 2448 3984
            WIRE 2448 3984 2512 3984
            BEGIN DISPLAY 2432 3984 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH trigger_number(19:0)
            WIRE 4576 3968 4592 3968
            WIRE 4592 3968 4656 3968
            BEGIN DISPLAY 4576 3968 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_CLK90
            WIRE 2992 3056 3072 3056
            BEGIN DISPLAY 2992 3056 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_extdom_trig
            WIRE 3520 3056 3600 3056
            BEGIN DISPLAY 3600 3056 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_trigger
            WIRE 2992 3120 3072 3120
            BEGIN DISPLAY 2992 3120 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH cal_tag_trig_num_sel
            WIRE 2432 4048 2512 4048
            BEGIN DISPLAY 2432 4048 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH cal_tag_trig_num_sel
            WIRE 4576 4032 4656 4032
            BEGIN DISPLAY 4576 4032 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4124 5248 2992 R0
        END INSTANCE
        BEGIN BRANCH MASTER_CLK
            WIRE 5168 2832 5248 2832
            BEGIN DISPLAY 5168 2832 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 5168 2896 5248 2896
            BEGIN DISPLAY 5168 2896 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_we
            WIRE 5168 2960 5248 2960
            BEGIN DISPLAY 5168 2960 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_end_packet
            WIRE 5824 2832 5904 2832
            BEGIN DISPLAY 5904 2832 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 5072 2672 5344 2672
            BEGIN DISPLAY 5072 2672 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_burst_we
            WIRE 5216 2512 5344 2512
            BEGIN DISPLAY 5216 2512 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_delayed_clk
            WIRE 5072 2576 5344 2576
            BEGIN DISPLAY 5072 2576 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_data_label(3)
            WIRE 5728 2448 5952 2448
            BEGIN DISPLAY 5952 2448 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_data_label(2)
            WIRE 5728 2384 5952 2384
            BEGIN DISPLAY 5952 2384 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_data_label(1)
            WIRE 5728 2320 5952 2320
            BEGIN DISPLAY 5952 2320 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_data_label(0)
            WIRE 5728 2256 5952 2256
            BEGIN DISPLAY 5952 2256 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3497 5344 2704 R0
        BEGIN BRANCH rx_data(16)
            WIRE 5264 1904 5344 1904
            BEGIN DISPLAY 5264 1904 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH cal_tag_trig_num_sel
            WIRE 5728 1904 5968 1904
            BEGIN DISPLAY 5968 1904 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4781 5344 2160 R0
        BEGIN BRANCH MASTER_CLK
            WIRE 5248 2032 5344 2032
            BEGIN DISPLAY 5248 2032 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_CAL_TAG_MAP
            WIRE 5168 1968 5344 1968
            BEGIN DISPLAY 5168 1968 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(0)
            WIRE 4208 1840 4288 1840
            BEGIN DISPLAY 4208 1840 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset_trig_counter
            WIRE 4672 1840 4768 1840
            BEGIN DISPLAY 4768 1840 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 4192 1968 4288 1968
            BEGIN DISPLAY 4192 1968 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH RESET_TRIG_NUM_MAP
            WIRE 4176 1904 4288 1904
            BEGIN DISPLAY 4176 1904 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4834 4288 2096 R0
        BEGIN BRANCH reset_trig_counter
            WIRE 2992 3184 3072 3184
            BEGIN DISPLAY 2992 3184 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
    END SHEET
    BEGIN SHEET 3 7040 5440
        BEGIN BRANCH rx_data(0)
            WIRE 1504 368 1584 368
            BEGIN DISPLAY 1504 368 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_testmode_sig
            WIRE 1968 368 2208 368
            BEGIN DISPLAY 2208 368 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3479 1584 624 R0
        BEGIN BRANCH MASTER_CLK
            WIRE 1488 496 1584 496
            BEGIN DISPLAY 1488 496 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(0)
            WIRE 1360 1120 1600 1120
            BEGIN DISPLAY 1360 1120 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH dcm_reset
            WIRE 1984 1120 2224 1120
            BEGIN DISPLAY 2224 1120 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(4)
            WIRE 1376 1520 1392 1520
            WIRE 1392 1520 1600 1520
            BEGIN DISPLAY 1376 1520 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3302 1600 1376 R0
        BEGIN BRANCH MASTER_CLK
            WIRE 1504 1248 1600 1248
            BEGIN DISPLAY 1504 1248 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 1488 1648 1504 1648
            WIRE 1504 1648 1600 1648
            BEGIN DISPLAY 1488 1648 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(1)
            WIRE 1360 736 1600 736
            BEGIN DISPLAY 1360 736 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH dcm_reset_psi
            WIRE 1984 736 2224 736
            BEGIN DISPLAY 2224 736 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3427 1600 992 R0
        BEGIN BRANCH MASTER_CLK
            WIRE 1504 864 1600 864
            BEGIN DISPLAY 1504 864 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH DCM_PSI_RESET_MAP
            WIRE 976 1248 1024 1248
            WIRE 1024 1248 1024 1584
            WIRE 1024 1584 1600 1584
            WIRE 1024 800 1600 800
            WIRE 1024 800 1024 1184
            WIRE 1024 1184 1024 1248
            WIRE 1024 1184 1600 1184
            BEGIN DISPLAY 976 1248 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_3405 5584 1312 R0
            BEGIN DISPLAY 0 -248 ATTR IOBDELAY_TYPE
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH ADC_65MSPS_CH0
            WIRE 5392 1152 5584 1152
            BEGIN DISPLAY 5392 1152 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 5392 1216 5584 1216
            BEGIN DISPLAY 5392 1216 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_data_del_ce
            WIRE 4992 1184 5024 1184
            WIRE 5024 1184 5584 1184
            WIRE 5024 1184 5024 1344
            WIRE 5024 1344 5152 1344
            WIRE 5152 1344 5216 1344
            BEGIN DISPLAY 5152 1344 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(0)
            WIRE 5376 1248 5584 1248
            BEGIN DISPLAY 5376 1248 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3409 5216 1472 R0
        BEGIN BRANCH rx_data(4)
            WIRE 5024 1408 5216 1408
            BEGIN DISPLAY 5024 1408 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_data_del_rst
            WIRE 5472 1376 5520 1376
            WIRE 5520 1280 5520 1376
            WIRE 5520 1280 5584 1280
            BEGIN DISPLAY 5520 1376 ATTR Name
                ALIGNMENT SOFT-TCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_12220
            WIRE 5200 560 5280 560
        END BRANCH
        BEGIN INSTANCE XLXI_3410 4816 880 R0
            BEGIN DISPLAY 0 -504 ATTR CLKIN_PERIOD
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
            BEGIN DISPLAY 0 -440 ATTR CLKFX_MULTIPLY
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
            BEGIN DISPLAY 0 -472 ATTR CLKFX_DIVIDE
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH MASTER_CLK
            WIRE 4720 560 4816 560
            BEGIN DISPLAY 4720 560 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 4736 848 4816 848
            BEGIN DISPLAY 4736 848 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3411 5280 592 R0
        BEGIN BRANCH XLXN_12229
            WIRE 4752 464 4752 704
            WIRE 4752 704 4816 704
            WIRE 4752 464 5600 464
            WIRE 5600 464 5600 560
            WIRE 5504 560 5600 560
        END BRANCH
        RECTANGLE N 4012 220 6668 4224 
        BEGIN DISPLAY 4136 176 TEXT "INPUT DELAY LINES"
            FONT 40 "Arial"
        END DISPLAY
        BEGIN BRANCH ADC_TESTMODE_MAP
            WIRE 1408 432 1584 432
            BEGIN DISPLAY 1408 432 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ADC_DELAY_MAP
            WIRE 4608 1152 4736 1152
            BEGIN DISPLAY 4608 1152 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(24)
            WIRE 4608 1216 4736 1216
            BEGIN DISPLAY 4608 1216 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4466 4736 1280 R0
        BEGIN BRANCH XLXN_12257
            WIRE 5200 784 5280 784
        END BRANCH
        BEGIN BRANCH adc_delayed_data(0)
            WIRE 5968 1152 6112 1152
            BEGIN DISPLAY 6112 1152 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_3406 5712 848 R0
        END INSTANCE
        BEGIN BRANCH reset
            WIRE 5664 816 5712 816
            BEGIN DISPLAY 5664 816 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_15064
            WIRE 5504 784 5712 784
        END BRANCH
        INSTANCE XLXI_4529 5280 816 R0
        BEGIN BRANCH MASTER_CLK
            WIRE 1696 2928 1856 2928
            BEGIN DISPLAY 1696 2928 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ADC_DCM_FB
            WIRE 1696 2960 1856 2960
            BEGIN DISPLAY 1696 2960 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(6:0)
            WIRE 1664 3120 1856 3120
            BEGIN DISPLAY 1664 3120 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(23:8)
            WIRE 1664 3152 1856 3152
            BEGIN DISPLAY 1664 3152 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 1664 3248 1856 3248
            BEGIN DISPLAY 1664 3248 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3265 2384 2960 R0
        BEGIN BRANCH XLXN_11574
            WIRE 2240 2928 2384 2928
        END BRANCH
        BEGIN BRANCH dcm_reset
            WIRE 1696 2992 1856 2992
            BEGIN DISPLAY 1696 2992 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_3254 1856 3344 R0
            BEGIN DISPLAY 0 -504 ATTR CLKFX_MULTIPLY
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
            BEGIN DISPLAY 0 -552 ATTR CLKFX_DIVIDE
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
            BEGIN DISPLAY 0 -696 ATTR CLKIN_PERIOD
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
            BEGIN DISPLAY 0 -648 ATTR DLL_FREQUENCY_MODE
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
            BEGIN DISPLAY 0 -600 ATTR DFS_FREQUENCY_MODE
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
            BEGIN DISPLAY 0 -744 ATTR CLKOUT_PHASE_SHIFT
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH ADC_CLOCK_MAP
            WIRE 1248 3184 1680 3184
            WIRE 1680 3184 1680 3216
            WIRE 1680 3216 1856 3216
            WIRE 1680 3184 1856 3184
            BEGIN DISPLAY 1248 3184 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ADC_DCM_FB
            WIRE 2608 2928 2752 2928
            BEGIN DISPLAY 2752 2928 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3402 1568 2992 R90
        BEGIN BRANCH XLXN_12188
            WIRE 1696 3056 1776 3056
            WIRE 1776 3056 1776 3088
            WIRE 1776 3088 1856 3088
            WIRE 1776 3056 1856 3056
            WIRE 1776 3024 1856 3024
            WIRE 1776 3024 1776 3056
        END BRANCH
        BEGIN INSTANCE XLXI_4559 1168 4960 R0
        END INSTANCE
        INSTANCE XLXI_4560 1744 4640 R0
        BEGIN BRANCH XLXN_15146
            WIRE 1552 4608 1696 4608
            WIRE 1696 4608 1744 4608
            WIRE 1696 4608 1696 4720
            WIRE 1696 4720 2272 4720
        END BRANCH
        BEGIN BRANCH XLXN_15149
            WIRE 1104 4496 1104 4672
            WIRE 1104 4672 1168 4672
            WIRE 1104 4496 2032 4496
            WIRE 2032 4496 2032 4608
            WIRE 1968 4608 2032 4608
        END BRANCH
        BEGIN BRANCH clock_5mhz
            WIRE 1040 4608 1168 4608
            BEGIN DISPLAY 1040 4608 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 1040 4736 1168 4736
            BEGIN DISPLAY 1040 4736 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 1040 4800 1168 4800
            BEGIN DISPLAY 1040 4800 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH DISPLAY_MAP
            WIRE 1040 4864 1168 4864
            BEGIN DISPLAY 1040 4864 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(7:0)
            WIRE 1040 4928 1168 4928
            BEGIN DISPLAY 1040 4928 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH display_ser_data
            WIRE 1552 4928 1680 4928
            BEGIN DISPLAY 1680 4928 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH display_load_bar
            WIRE 2656 4720 2704 4720
            BEGIN DISPLAY 2704 4720 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4561 2272 4976 R0
        BEGIN BRANCH clock_5mhz
            WIRE 2144 4848 2272 4848
            BEGIN DISPLAY 2144 4848 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_3420 5616 3552 R0
            BEGIN DISPLAY 0 -248 ATTR IOBDELAY_TYPE
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH ADC_FRAME_OUT
            WIRE 5424 3392 5616 3392
            BEGIN DISPLAY 5424 3392 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 5424 3456 5616 3456
            BEGIN DISPLAY 5424 3456 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_12239
            WIRE 5024 3424 5056 3424
            WIRE 5056 3424 5616 3424
            WIRE 5056 3424 5056 3584
            WIRE 5056 3584 5248 3584
        END BRANCH
        BEGIN BRANCH rx_data(0)
            WIRE 5408 3488 5616 3488
            BEGIN DISPLAY 5408 3488 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3421 5248 3712 R0
        BEGIN BRANCH rx_data(4)
            WIRE 5056 3648 5248 3648
            BEGIN DISPLAY 5056 3648 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_12242
            WIRE 5504 3616 5552 3616
            WIRE 5552 3520 5552 3616
            WIRE 5552 3520 5616 3520
        END BRANCH
        BEGIN INSTANCE XLXI_3423 5616 3984 R0
            BEGIN DISPLAY 0 -248 ATTR IOBDELAY_TYPE
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH ADC_CLK_OUT
            WIRE 5424 3824 5616 3824
            BEGIN DISPLAY 5424 3824 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 5424 3888 5616 3888
            BEGIN DISPLAY 5424 3888 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_12249
            WIRE 5024 3856 5056 3856
            WIRE 5056 3856 5616 3856
            WIRE 5056 3856 5056 4016
            WIRE 5056 4016 5248 4016
        END BRANCH
        BEGIN BRANCH rx_data(0)
            WIRE 5408 3920 5616 3920
            BEGIN DISPLAY 5408 3920 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3424 5248 4144 R0
        BEGIN BRANCH rx_data(4)
            WIRE 5056 4080 5248 4080
            BEGIN DISPLAY 5056 4080 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_12252
            WIRE 5504 4048 5552 4048
            WIRE 5552 3952 5552 4048
            WIRE 5552 3952 5616 3952
        END BRANCH
        BEGIN BRANCH ADC_DELAY_MAP
            WIRE 4640 3392 4768 3392
            BEGIN DISPLAY 4640 3392 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(25)
            WIRE 4640 3456 4768 3456
            BEGIN DISPLAY 4640 3456 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4465 4768 3520 R0
        BEGIN BRANCH ADC_DELAY_MAP
            WIRE 4640 3824 4768 3824
            BEGIN DISPLAY 4640 3824 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(26)
            WIRE 4640 3888 4768 3888
            BEGIN DISPLAY 4640 3888 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4464 4768 3952 R0
        BEGIN BRANCH adc_delayed_frame
            WIRE 6000 3392 6112 3392
            BEGIN DISPLAY 6112 3392 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_delayed_clk
            WIRE 6000 3824 6112 3824
            BEGIN DISPLAY 6112 3824 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4648 5584 1712 R0
            BEGIN DISPLAY 0 -248 ATTR IOBDELAY_TYPE
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH ADC_65MSPS_CH1
            WIRE 5392 1552 5584 1552
            BEGIN DISPLAY 5392 1552 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 5392 1616 5584 1616
            BEGIN DISPLAY 5392 1616 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(0)
            WIRE 5376 1648 5584 1648
            BEGIN DISPLAY 5376 1648 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_delayed_data(1)
            WIRE 5968 1552 6112 1552
            BEGIN DISPLAY 6112 1552 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_delayed_data(1:0)
            WIRE 6288 1024 6304 1024
            WIRE 6304 1024 6384 1024
            BEGIN DISPLAY 6304 1024 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_reset
            WIRE 1984 1520 2224 1520
            BEGIN DISPLAY 2224 1520 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3301 1600 1776 R0
        BEGIN BRANCH rx_data(0)
            WIRE 1520 1920 1600 1920
            BEGIN DISPLAY 1520 1920 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_clk_sel
            WIRE 1984 1920 2224 1920
            BEGIN DISPLAY 2224 1920 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4776 1600 2176 R0
        BEGIN BRANCH MASTER_CLK
            WIRE 1504 2048 1600 2048
            BEGIN DISPLAY 1504 2048 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ADC_CLK_SEL_MAP
            WIRE 1424 1984 1600 1984
            BEGIN DISPLAY 1424 1984 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4615 1840 4016 R0
            BEGIN DISPLAY 0 -504 ATTR CLKIN_PERIOD
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
            BEGIN DISPLAY 0 -472 ATTR DCM_PERFORMANCE_MODE
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
            BEGIN DISPLAY 0 -440 ATTR CLKIN_DIVIDE_BY_2
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        INSTANCE XLXI_3399 2400 3728 R0
        BEGIN BRANCH XLXN_12172
            WIRE 2224 3696 2400 3696
        END BRANCH
        BEGIN BRANCH PSI_CLK0
            WIRE 2624 3696 2768 3696
            BEGIN DISPLAY 2768 3696 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4544 2784 3760 R0
        BEGIN BRANCH XLXN_15111
            WIRE 2224 3728 2784 3728
        END BRANCH
        BEGIN BRANCH PSI_CLK90
            WIRE 3008 3728 3152 3728
            BEGIN DISPLAY 3152 3728 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH dcm_reset_psi
            WIRE 1680 3984 1840 3984
            BEGIN DISPLAY 1680 3984 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_CLK0
            WIRE 1680 3840 1840 3840
            BEGIN DISPLAY 1680 3840 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4773 1184 3824 R0
        BEGIN BRANCH XLXN_15824
            WIRE 1504 3696 1536 3696
            WIRE 1536 3696 1840 3696
        END BRANCH
        BEGIN BRANCH EXT_CLK
            WIRE 1104 3728 1184 3728
            BEGIN DISPLAY 1104 3728 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_clk_sel
            WIRE 1104 3792 1184 3792
            BEGIN DISPLAY 1104 3792 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_15825
            WIRE 2240 3152 2256 3152
            WIRE 2256 3152 3184 3152
        END BRANCH
        BEGIN BRANCH INT_HALF_CLK
            WIRE 1104 3664 1184 3664
            BEGIN DISPLAY 1104 3664 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ADC_CLK_IN
            WIRE 2224 3824 2384 3824
            BEGIN DISPLAY 2384 3824 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4791 3184 3280 R0
        BEGIN BRANCH XLXN_15844
            WIRE 3152 2976 3152 3024
            WIRE 3152 3024 3184 3024
        END BRANCH
        BEGIN BRANCH XLXN_15845
            WIRE 3152 3248 3152 3280
            WIRE 3152 3248 3184 3248
        END BRANCH
        BEGIN BRANCH INT_HALF_CLK
            WIRE 3568 3024 3680 3024
            BEGIN DISPLAY 3680 3024 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4793 3088 3408 R0
        INSTANCE XLXI_4792 3088 2976 R0
        INSTANCE XLXI_4796 4928 1680 R0
        INSTANCE XLXI_4797 4928 1776 R0
        BEGIN BRANCH XLXN_15849
            WIRE 5184 1584 5584 1584
        END BRANCH
        BEGIN BRANCH XLXN_15850
            WIRE 5184 1680 5584 1680
        END BRANCH
        BEGIN BRANCH adc_data_del_ce
            WIRE 4816 1552 4928 1552
            BEGIN DISPLAY 4816 1552 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_data_del_rst
            WIRE 4816 1648 4928 1648
            BEGIN DISPLAY 4816 1648 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4801 5104 2160 R0
        BEGIN BRANCH rx_data(4)
            WIRE 4912 2096 5104 2096
            BEGIN DISPLAY 4912 2096 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH CHAN1_SPEC_DEL_MAP
            WIRE 4496 1840 4624 1840
            BEGIN DISPLAY 4496 1840 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(24)
            WIRE 4496 1904 4624 1904
            BEGIN DISPLAY 4496 1904 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4802 4624 1968 R0
        BEGIN BRANCH adc_data_del_ce_ch1
            WIRE 4880 1872 4992 1872
            WIRE 4992 1872 4992 1952
            WIRE 4992 1952 4992 2032
            WIRE 4992 2032 5104 2032
            BEGIN DISPLAY 4992 1952 ATTR Name
                ALIGNMENT SOFT-TVCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_data_del_rst_ch1
            WIRE 5360 2064 5504 2064
            BEGIN DISPLAY 5504 2064 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_data_del_ce_ch1
            WIRE 4816 1616 4928 1616
            BEGIN DISPLAY 4816 1616 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_data_del_rst_ch1
            WIRE 4816 1712 4928 1712
            BEGIN DISPLAY 4816 1712 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
    END SHEET
    BEGIN SHEET 4 7040 5440
        BEGIN BRANCH GMII_RX_ER_0_sig
            WIRE 1392 416 1920 416
            BEGIN DISPLAY 1920 416 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSC_16DP_32S
            WIRE 624 416 1168 416
        END BRANCH
        INSTANCE XLXI_4171 1424 2544 M0
        BEGIN BRANCH reset_button
            WIRE 1424 2480 1680 2480
            BEGIN DISPLAY 1680 2480 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSC_21DN_43S
            WIRE 768 2416 1200 2416
        END BRANCH
        BEGIN BRANCH XLXN_12023
            WIRE 1424 2352 1504 2352
            WIRE 1504 2352 1568 2352
            WIRE 1504 2352 1504 2416
            WIRE 1424 2416 1504 2416
        END BRANCH
        INSTANCE XLXI_3360 1792 2320 R180
        BEGIN BRANCH reset_phy
            WIRE 1792 2352 1968 2352
            BEGIN DISPLAY 1968 2352 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4248 1168 448 R0
        BEGIN BRANCH PRIMARY_CLK
            WIRE 816 2688 1184 2688
        END BRANCH
        BEGIN BRANCH SECONDARY_CLK
            WIRE 816 2752 1184 2752
        END BRANCH
        BEGIN BRANCH clock_66mhz
            WIRE 1408 2688 1872 2688
            BEGIN DISPLAY 1872 2688 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH clock_5mhz
            WIRE 1408 2752 1872 2752
            BEGIN DISPLAY 1872 2752 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4135 1184 2720 R0
        INSTANCE XLXI_4136 1184 2784 R0
        BEGIN BRANCH PHY_TXD_sig(0)
            WIRE 656 1680 1168 1680
            BEGIN DISPLAY 656 1680 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXD_sig(1)
            WIRE 656 1616 1168 1616
            BEGIN DISPLAY 656 1616 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXD_sig(2)
            WIRE 656 1552 1168 1552
            BEGIN DISPLAY 656 1552 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXD_sig(3)
            WIRE 656 1488 1168 1488
            BEGIN DISPLAY 656 1488 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSC_25DN_51S
            WIRE 1392 1680 1936 1680
        END BRANCH
        BEGIN BRANCH BUSC_25DP_50S
            WIRE 1392 1616 1936 1616
        END BRANCH
        BEGIN BRANCH BUSC_24DN_49S
            WIRE 1392 1552 1936 1552
        END BRANCH
        BEGIN BRANCH BUSC_24DP_48S
            WIRE 1392 1488 1936 1488
        END BRANCH
        INSTANCE XLXI_4181 1168 1520 R0
        INSTANCE XLXI_4182 1168 1584 R0
        INSTANCE XLXI_4183 1168 1648 R0
        INSTANCE XLXI_4184 1168 1712 R0
        BEGIN BRANCH BUSC_15DN_31S
            WIRE 1392 1424 1936 1424
        END BRANCH
        BEGIN BRANCH BUSC_15DP_30S
            WIRE 1392 1360 1936 1360
        END BRANCH
        BEGIN BRANCH BUSC_14DN_29S
            WIRE 1392 1296 1936 1296
        END BRANCH
        BEGIN BRANCH BUSC_14DP_28S
            WIRE 1392 1232 1936 1232
        END BRANCH
        BEGIN BRANCH PHY_TXD_sig(6)
            WIRE 656 1296 1168 1296
            BEGIN DISPLAY 656 1296 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXD_sig(7)
            WIRE 656 1232 1168 1232
            BEGIN DISPLAY 656 1232 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXD_sig(4)
            WIRE 656 1424 1168 1424
            BEGIN DISPLAY 656 1424 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXD_sig(5)
            WIRE 656 1360 1168 1360
            BEGIN DISPLAY 656 1360 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4247 1168 1456 R0
        INSTANCE XLXI_4249 1168 1392 R0
        INSTANCE XLXI_4250 1168 1328 R0
        INSTANCE XLXI_4251 1168 1264 R0
        BEGIN BRANCH BUSC_16DN_33S
            WIRE 1392 1168 1936 1168
        END BRANCH
        BEGIN BRANCH PHY_TXER_sig
            WIRE 656 1168 1168 1168
            BEGIN DISPLAY 656 1168 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4246 1168 1200 R0
        BEGIN BRANCH GMII_RXD_0_sig(6)
            WIRE 1392 928 1920 928
            BEGIN DISPLAY 1920 928 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RXD_0_sig(7)
            WIRE 1392 864 1920 864
            BEGIN DISPLAY 1920 864 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RXD_0_sig(4)
            WIRE 1392 800 1920 800
            BEGIN DISPLAY 1920 800 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RXD_0_sig(5)
            WIRE 1392 736 1920 736
            BEGIN DISPLAY 1920 736 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RXD_0_sig(2)
            WIRE 1392 672 1920 672
            BEGIN DISPLAY 1920 672 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RXD_0_sig(3)
            WIRE 1392 608 1920 608
            BEGIN DISPLAY 1920 608 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RXD_0_sig(0)
            WIRE 1392 544 1920 544
            BEGIN DISPLAY 1920 544 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RXD_0_sig(1)
            WIRE 1392 480 1920 480
            BEGIN DISPLAY 1920 480 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSC_20DN_41S
            WIRE 624 928 1168 928
        END BRANCH
        BEGIN BRANCH BUSC_19DN_39S
            WIRE 624 800 1168 800
        END BRANCH
        BEGIN BRANCH BUSC_20DP_40S
            WIRE 624 864 1168 864
        END BRANCH
        BEGIN BRANCH BUSC_19DP_38S
            WIRE 624 736 1168 736
        END BRANCH
        BEGIN BRANCH BUSC_18DP_36S
            WIRE 624 608 1168 608
        END BRANCH
        BEGIN BRANCH BUSC_18DN_37S
            WIRE 624 672 1168 672
        END BRANCH
        BEGIN BRANCH BUSC_17DN_35S
            WIRE 624 544 1168 544
        END BRANCH
        BEGIN BRANCH BUSC_17DP_34S
            WIRE 624 480 1168 480
        END BRANCH
        INSTANCE XLXI_4213 1168 896 R0
        INSTANCE XLXI_4214 1168 960 R0
        INSTANCE XLXI_4216 1168 768 R0
        INSTANCE XLXI_4217 1168 832 R0
        INSTANCE XLXI_4218 1168 640 R0
        INSTANCE XLXI_4219 1168 704 R0
        INSTANCE XLXI_4220 1168 512 R0
        INSTANCE XLXI_4221 1168 576 R0
        BEGIN BRANCH PHY_TXEN_sig
            WIRE 656 1104 1168 1104
            BEGIN DISPLAY 656 1104 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSC_27DN_55S
            WIRE 1392 1104 1936 1104
        END BRANCH
        INSTANCE XLXI_4177 1168 1136 R0
        BEGIN BRANCH GMII_RX_DV_0_sig
            WIRE 1392 352 1920 352
            BEGIN DISPLAY 1920 352 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSC_27DP_54S
            WIRE 624 352 1168 352
        END BRANCH
        INSTANCE XLXI_4178 1168 384 R0
        INSTANCE XLXI_4253 1168 288 R0
        BEGIN BRANCH MASTER_CLK
            WIRE 1392 256 1680 256
            BEGIN DISPLAY 1680 256 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSC_26DP_52S
            WIRE 624 256 1168 256
        END BRANCH
        BEGIN BRANCH GTX_CLK_0_sig
            WIRE 656 1808 1168 1808
            BEGIN DISPLAY 656 1808 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSC_26DN_53S
            WIRE 1392 1808 1936 1808
        END BRANCH
        INSTANCE XLXI_4179 1168 1840 R0
        BEGIN BRANCH GENERAL_03DN_07S
            WIRE 624 2080 1168 2080
        END BRANCH
        BEGIN BRANCH GENERAL_02DN_05S
            WIRE 624 1952 1168 1952
        END BRANCH
        BEGIN BRANCH GENERAL_02DP_04S
            WIRE 624 2016 1168 2016
        END BRANCH
        INSTANCE XLXI_4294 1168 2048 R0
        INSTANCE XLXI_4295 1168 2112 R0
        INSTANCE XLXI_4296 1168 1984 R0
        IOMARKER 624 416 BUSC_16DP_32S R180 28
        IOMARKER 768 2416 BUSC_21DN_43S R180 28
        IOMARKER 816 2688 PRIMARY_CLK R180 28
        IOMARKER 816 2752 SECONDARY_CLK R180 28
        IOMARKER 1936 1488 BUSC_24DP_48S R0 28
        IOMARKER 1936 1680 BUSC_25DN_51S R0 28
        IOMARKER 1936 1616 BUSC_25DP_50S R0 28
        IOMARKER 1936 1552 BUSC_24DN_49S R0 28
        IOMARKER 624 928 BUSC_20DN_41S R180 28
        IOMARKER 624 800 BUSC_19DN_39S R180 28
        IOMARKER 624 864 BUSC_20DP_40S R180 28
        IOMARKER 624 736 BUSC_19DP_38S R180 28
        IOMARKER 624 608 BUSC_18DP_36S R180 28
        IOMARKER 624 672 BUSC_18DN_37S R180 28
        IOMARKER 624 544 BUSC_17DN_35S R180 28
        IOMARKER 624 480 BUSC_17DP_34S R180 28
        IOMARKER 1936 1104 BUSC_27DN_55S R0 28
        IOMARKER 624 352 BUSC_27DP_54S R180 28
        IOMARKER 624 256 BUSC_26DP_52S R180 28
        IOMARKER 1936 1808 BUSC_26DN_53S R0 28
        IOMARKER 1936 1424 BUSC_15DN_31S R0 28
        IOMARKER 1936 1360 BUSC_15DP_30S R0 28
        IOMARKER 1936 1296 BUSC_14DN_29S R0 28
        IOMARKER 1936 1232 BUSC_14DP_28S R0 28
        IOMARKER 1936 1168 BUSC_16DN_33S R0 28
        IOMARKER 624 2080 GENERAL_03DN_07S R180 28
        IOMARKER 624 1952 GENERAL_02DN_05S R180 28
        IOMARKER 624 2016 GENERAL_02DP_04S R180 28
        BEGIN BRANCH BUSAHS_00DP_00S
            WIRE 2896 336 3136 336
        END BRANCH
        IOMARKER 2896 336 BUSAHS_00DP_00S R180 28
        BEGIN INSTANCE XLXI_4501 3136 384 R0
            BEGIN DISPLAY 0 -64 ATTR DIFF_TERM
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH BUSAHS_00DN_01S
            WIRE 2896 368 3136 368
        END BRANCH
        IOMARKER 2896 368 BUSAHS_00DN_01S R180 28
        BEGIN BRANCH ADC_CLK_OUT
            WIRE 3360 352 3888 352
            BEGIN DISPLAY 3888 352 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSAHS_01DP_02S
            WIRE 2896 576 3152 576
        END BRANCH
        IOMARKER 2896 576 BUSAHS_01DP_02S R180 28
        BEGIN INSTANCE XLXI_4502 3152 624 R0
            BEGIN DISPLAY 0 -64 ATTR DIFF_TERM
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH BUSAHS_01DN_03S
            WIRE 2896 608 3152 608
        END BRANCH
        IOMARKER 2896 608 BUSAHS_01DN_03S R180 28
        BEGIN BRANCH ADC_FRAME_OUT
            WIRE 3376 592 3888 592
            BEGIN DISPLAY 3888 592 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ADC_CLK_IN
            WIRE 2912 752 3152 752
            BEGIN DISPLAY 2912 752 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSAHS_02DN_05S
            WIRE 3376 752 3808 752
        END BRANCH
        IOMARKER 3808 752 BUSAHS_02DN_05S R0 28
        INSTANCE XLXI_4503 3152 784 R0
        IOMARKER 2864 928 BUSA_16DN_33S R180 28
        IOMARKER 2864 896 BUSA_16DP_32S R180 28
        BEGIN BRANCH ADC_65MSPS_CH0
            WIRE 3376 912 3904 912
            BEGIN DISPLAY 3904 912 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSA_16DN_33S
            WIRE 2864 928 3152 928
        END BRANCH
        BEGIN BRANCH BUSA_16DP_32S
            WIRE 2864 896 3152 896
        END BRANCH
        BEGIN INSTANCE XLXI_4504 3152 944 R0
            BEGIN DISPLAY 0 -64 ATTR DIFF_TERM
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        RECTANGLE N 2492 232 4300 1256 
        BEGIN DISPLAY 2752 204 TEXT "ADC I/O"
            FONT 36 "Arial"
        END DISPLAY
        IOMARKER 2848 2160 BUSBB_05DN_11S R180 28
        IOMARKER 2848 2128 BUSBB_05DP_10S R180 28
        RECTANGLE N 2496 1388 4300 2352 
        BEGIN DISPLAY 2728 1352 TEXT "PSI46 I/O - Plaquette 0"
            FONT 36 "Arial"
        END DISPLAY
        BEGIN DISPLAY 356 144 TEXT "Foundation I/O"
            FONT 36 "Arial"
        END DISPLAY
        IOMARKER 3792 2000 BUSBB_04DP_08S R0 28
        IOMARKER 3792 2032 BUSBB_04DN_09S R0 28
        IOMARKER 3792 1872 BUSBB_03DP_06S R0 28
        IOMARKER 3792 1904 BUSBB_03DN_07S R0 28
        IOMARKER 3792 1536 BUSBB_00DP_00S R0 28
        IOMARKER 3792 1568 BUSBB_00DN_01S R0 28
        IOMARKER 3792 1776 BUSBB_02DP_04S R0 28
        IOMARKER 3792 1632 BUSBB_01DP_02S R0 28
        IOMARKER 3792 1664 BUSBB_01DN_03S R0 28
        BEGIN INSTANCE XLXI_4514 3136 2176 R0
            BEGIN DISPLAY 0 -64 ATTR DIFF_TERM
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        INSTANCE XLXI_4513 3136 2048 R0
        INSTANCE XLXI_4511 3136 1920 R0
        INSTANCE XLXI_4510 3136 1584 R0
        INSTANCE XLXI_4509 3136 1808 R0
        INSTANCE XLXI_4506 3136 1680 R0
        BEGIN BRANCH PSI_CLK90
            WIRE 2928 2016 3136 2016
            BEGIN DISPLAY 2928 2016 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSBB_05DP_10S
            WIRE 2848 2128 3136 2128
        END BRANCH
        BEGIN BRANCH BUSBB_05DN_11S
            WIRE 2848 2160 3136 2160
        END BRANCH
        BEGIN BRANCH psi_token_out0
            WIRE 3360 2144 3888 2144
            BEGIN DISPLAY 3888 2144 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSBB_04DP_08S
            WIRE 3360 2000 3376 2000
            WIRE 3376 2000 3792 2000
        END BRANCH
        BEGIN BRANCH BUSBB_04DN_09S
            WIRE 3360 2032 3376 2032
            WIRE 3376 2032 3792 2032
        END BRANCH
        BEGIN BRANCH psi_data_out0
            WIRE 2928 1888 3024 1888
            WIRE 3024 1888 3136 1888
            BEGIN DISPLAY 2928 1888 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSBB_03DP_06S
            WIRE 3360 1872 3376 1872
            WIRE 3376 1872 3792 1872
        END BRANCH
        BEGIN BRANCH BUSBB_03DN_07S
            WIRE 3360 1904 3376 1904
            WIRE 3376 1904 3792 1904
        END BRANCH
        BEGIN BRANCH psi_token_in
            WIRE 2928 1552 3024 1552
            WIRE 3024 1552 3136 1552
            BEGIN DISPLAY 2928 1552 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSBB_00DP_00S
            WIRE 3360 1536 3376 1536
            WIRE 3376 1536 3792 1536
        END BRANCH
        BEGIN BRANCH BUSBB_00DN_01S
            WIRE 3360 1568 3376 1568
            WIRE 3376 1568 3792 1568
        END BRANCH
        BEGIN BRANCH psi_reset
            WIRE 2928 1776 3136 1776
            BEGIN DISPLAY 2928 1776 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSBB_02DP_04S
            WIRE 3360 1776 3376 1776
            WIRE 3376 1776 3792 1776
        END BRANCH
        BEGIN BRANCH psi_trigger
            WIRE 2928 1648 3024 1648
            WIRE 3024 1648 3136 1648
            BEGIN DISPLAY 2928 1648 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSBB_01DP_02S
            WIRE 3360 1632 3376 1632
            WIRE 3376 1632 3792 1632
        END BRANCH
        BEGIN BRANCH BUSBB_01DN_03S
            WIRE 3360 1664 3376 1664
            WIRE 3376 1664 3792 1664
        END BRANCH
        BEGIN BRANCH display_ser_data
            WIRE 656 3056 1168 3056
            BEGIN DISPLAY 656 3056 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH INTERNAL_05DP_10S
            WIRE 1392 3056 1936 3056
        END BRANCH
        INSTANCE XLXI_4568 1168 3088 R0
        IOMARKER 1936 3056 INTERNAL_05DP_10S R0 28
        BEGIN BRANCH INTERNAL_05DN_11S
            WIRE 1392 3184 1936 3184
        END BRANCH
        INSTANCE XLXI_4570 1168 3216 R0
        IOMARKER 1936 3184 INTERNAL_05DN_11S R0 28
        IOMARKER 1936 3120 INTERNAL_04DN_09S R0 28
        INSTANCE XLXI_4569 1168 3152 R0
        BEGIN BRANCH INTERNAL_04DN_09S
            WIRE 1392 3120 1936 3120
        END BRANCH
        BEGIN BRANCH display_load_bar
            WIRE 656 3120 1168 3120
            BEGIN DISPLAY 656 3120 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_15151
            WIRE 1120 3184 1152 3184
            WIRE 1152 3184 1168 3184
        END BRANCH
        INSTANCE XLXI_4571 896 3216 R0
        BEGIN BRANCH clock_5mhz
            WIRE 656 3184 896 3184
            BEGIN DISPLAY 656 3184 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        RECTANGLE N 188 164 2288 2844 
        BEGIN BRANCH gec_user_addrs(0)
            WIRE 1392 1952 1920 1952
            BEGIN DISPLAY 1920 1952 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_addrs(1)
            WIRE 1392 2016 1920 2016
            BEGIN DISPLAY 1920 2016 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_addrs(2)
            WIRE 1392 2080 1920 2080
            BEGIN DISPLAY 1920 2080 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_testmode_sig
            WIRE 2912 1184 3152 1184
            BEGIN DISPLAY 2912 1184 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GENERAL_03DP_06S
            WIRE 3376 1184 3808 1184
        END BRANCH
        INSTANCE XLXI_4521 3152 1216 R0
        IOMARKER 3808 1184 GENERAL_03DP_06S R0 28
        BEGIN BRANCH ADC_65MSPS_CH1
            WIRE 3376 992 3904 992
            BEGIN DISPLAY 3904 992 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSA_17DN_35S
            WIRE 2864 1008 3152 1008
        END BRANCH
        BEGIN BRANCH BUSA_17DP_34S
            WIRE 2864 976 3152 976
        END BRANCH
        BEGIN INSTANCE XLXI_4670 3152 1024 R0
            BEGIN DISPLAY 0 -64 ATTR DIFF_TERM
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        IOMARKER 2864 1008 BUSA_17DN_35S R180 28
        IOMARKER 2864 976 BUSA_17DP_34S R180 28
        RECTANGLE N 2496 2460 4300 3424 
        BEGIN DISPLAY 2728 2424 TEXT "PSI46 I/O - Plaquette 1"
            FONT 36 "Arial"
        END DISPLAY
        BEGIN INSTANCE XLXI_4715 3136 3248 R0
            BEGIN DISPLAY 0 -64 ATTR DIFF_TERM
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        INSTANCE XLXI_4716 3136 3120 R0
        INSTANCE XLXI_4717 3136 2992 R0
        INSTANCE XLXI_4718 3136 2656 R0
        INSTANCE XLXI_4719 3136 2880 R0
        INSTANCE XLXI_4720 3136 2752 R0
        BEGIN BRANCH PSI_CLK90
            WIRE 2928 3088 3136 3088
            BEGIN DISPLAY 2928 3088 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSD_23DP_46S
            WIRE 2848 3200 3136 3200
        END BRANCH
        BEGIN BRANCH BUSD_23DN_47S
            WIRE 2848 3232 3136 3232
        END BRANCH
        BEGIN BRANCH psi_token_out1
            WIRE 3360 3216 3888 3216
            BEGIN DISPLAY 3888 3216 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSD_22DP_44S
            WIRE 3360 3072 3376 3072
            WIRE 3376 3072 3792 3072
        END BRANCH
        BEGIN BRANCH BUSD_22DN_45S
            WIRE 3360 3104 3376 3104
            WIRE 3376 3104 3792 3104
        END BRANCH
        BEGIN BRANCH psi_data_out1
            WIRE 2928 2960 3024 2960
            WIRE 3024 2960 3136 2960
            BEGIN DISPLAY 2928 2960 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSD_21DP_42S
            WIRE 3360 2944 3376 2944
            WIRE 3376 2944 3792 2944
        END BRANCH
        BEGIN BRANCH BUSD_21DN_43S
            WIRE 3360 2976 3376 2976
            WIRE 3376 2976 3792 2976
        END BRANCH
        BEGIN BRANCH psi_token_in
            WIRE 2928 2624 3024 2624
            WIRE 3024 2624 3136 2624
            BEGIN DISPLAY 2928 2624 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSD_19DP_38S
            WIRE 3360 2608 3376 2608
            WIRE 3376 2608 3792 2608
        END BRANCH
        BEGIN BRANCH BUSD_19DN_39S
            WIRE 3360 2640 3376 2640
            WIRE 3376 2640 3792 2640
        END BRANCH
        BEGIN BRANCH psi_reset
            WIRE 2928 2848 3136 2848
            BEGIN DISPLAY 2928 2848 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GENERAL_05DN_11S
            WIRE 3360 2848 3376 2848
            WIRE 3376 2848 3792 2848
        END BRANCH
        BEGIN BRANCH psi_trigger
            WIRE 2928 2720 3024 2720
            WIRE 3024 2720 3136 2720
            BEGIN DISPLAY 2928 2720 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSD_20DP_40S
            WIRE 3360 2704 3376 2704
            WIRE 3376 2704 3792 2704
        END BRANCH
        BEGIN BRANCH BUSD_20DN_41S
            WIRE 3360 2736 3376 2736
            WIRE 3376 2736 3792 2736
        END BRANCH
        IOMARKER 2848 3232 BUSD_23DN_47S R180 28
        IOMARKER 2848 3200 BUSD_23DP_46S R180 28
        IOMARKER 3792 3072 BUSD_22DP_44S R0 28
        IOMARKER 3792 3104 BUSD_22DN_45S R0 28
        IOMARKER 3792 2944 BUSD_21DP_42S R0 28
        IOMARKER 3792 2976 BUSD_21DN_43S R0 28
        IOMARKER 3792 2608 BUSD_19DP_38S R0 28
        IOMARKER 3792 2640 BUSD_19DN_39S R0 28
        IOMARKER 3792 2848 GENERAL_05DN_11S R0 28
        IOMARKER 3792 2704 BUSD_20DP_40S R0 28
        IOMARKER 3792 2736 BUSD_20DN_41S R0 28
        BEGIN DISPLAY 184 3384 TEXT "EXTERNAL TRIGGER AND CLOCK"
            FONT 36 "Arial"
        END DISPLAY
        RECTANGLE N 176 3400 1980 4340 
        BEGIN INSTANCE XLXI_4794 1024 3712 R0
            BEGIN DISPLAY 0 -64 ATTR DIFF_TERM
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        BEGIN INSTANCE XLXI_4795 1008 4048 R0
            BEGIN DISPLAY 0 -64 ATTR DIFF_TERM
                FONT 28 "Arial"
                DISPLAYFORMAT NAMEEQUALSVALUE
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH EXT_TRIGG
            WIRE 1248 3680 1376 3680
            BEGIN DISPLAY 1376 3680 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH EXT_CLK
            WIRE 1232 4016 1360 4016
            BEGIN DISPLAY 1360 4016 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH BUSA_14DP_28S
            WIRE 720 4000 880 4000
            WIRE 880 4000 1008 4000
        END BRANCH
        IOMARKER 720 4000 BUSA_14DP_28S R180 28
        BEGIN BRANCH BUSA_12DP_24S
            WIRE 736 3664 896 3664
            WIRE 896 3664 1024 3664
        END BRANCH
        IOMARKER 736 3664 BUSA_12DP_24S R180 28
        BEGIN BRANCH BUSA_12DN_25S
            WIRE 736 3696 896 3696
            WIRE 896 3696 1024 3696
        END BRANCH
        IOMARKER 736 3696 BUSA_12DN_25S R180 28
        BEGIN BRANCH BUSA_14DN_29S
            WIRE 720 4032 880 4032
            WIRE 880 4032 1008 4032
        END BRANCH
        IOMARKER 720 4032 BUSA_14DN_29S R180 28
    END SHEET
END SCHEMATIC
