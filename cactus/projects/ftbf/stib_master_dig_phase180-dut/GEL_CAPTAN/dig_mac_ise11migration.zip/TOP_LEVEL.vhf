--------------------------------------------------------------------------------
-- Copyright (c) 1995-2008 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 10.1
--  \   \         Application : sch2vhdl
--  /   /         Filename : TOP_LEVEL.vhf
-- /___/   /\     Timestamp : 08/24/2009 12:14:39
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: C:\Xilinx\10.1\ISE\bin\nt\unwrapped\sch2vhdl.exe -intstyle ise -family virtex4 -flat -suppress -w E:/CMS_TB/GEL_CAPTAN/TOP_LEVEL.sch TOP_LEVEL.vhf
--Design Name: TOP_LEVEL
--Device: virtex4
--Purpose:
--    This vhdl netlist is translated from an ECS schematic. It can be 
--    synthesis and simulted, but it should not be modified. 
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity FTC_MXILINX_TOP_LEVEL is
   port ( C   : in    std_logic; 
          CLR : in    std_logic; 
          T   : in    std_logic; 
          Q   : out   std_logic);
end FTC_MXILINX_TOP_LEVEL;

architecture BEHAVIORAL of FTC_MXILINX_TOP_LEVEL is
   attribute BOX_TYPE   : string ;
   attribute INIT       : string ;
   attribute RLOC       : string ;
   signal TQ      : std_logic;
   signal Q_DUMMY : std_logic;
   component XOR2
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of XOR2 : component is "BLACK_BOX";
   
   component FDC
      -- synopsys translate_off
      generic( INIT : bit :=  '0');
      -- synopsys translate_on
      port ( C   : in    std_logic; 
             CLR : in    std_logic; 
             D   : in    std_logic; 
             Q   : out   std_logic);
   end component;
   attribute INIT of FDC : component is "0";
   attribute BOX_TYPE of FDC : component is "BLACK_BOX";
   
   attribute RLOC of I_36_35 : label is "X0Y0";
begin
   Q <= Q_DUMMY;
   I_36_32 : XOR2
      port map (I0=>T,
                I1=>Q_DUMMY,
                O=>TQ);
   
   I_36_35 : FDC
      port map (C=>C,
                CLR=>CLR,
                D=>TQ,
                Q=>Q_DUMMY);
   
end BEHAVIORAL;



library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity M2_1_MXILINX_TOP_LEVEL is
   port ( D0 : in    std_logic; 
          D1 : in    std_logic; 
          S0 : in    std_logic; 
          O  : out   std_logic);
end M2_1_MXILINX_TOP_LEVEL;

architecture BEHAVIORAL of M2_1_MXILINX_TOP_LEVEL is
   attribute BOX_TYPE   : string ;
   signal M0 : std_logic;
   signal M1 : std_logic;
   component AND2B1
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND2B1 : component is "BLACK_BOX";
   
   component OR2
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of OR2 : component is "BLACK_BOX";
   
   component AND2
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND2 : component is "BLACK_BOX";
   
begin
   I_36_7 : AND2B1
      port map (I0=>S0,
                I1=>D0,
                O=>M0);
   
   I_36_8 : OR2
      port map (I0=>M1,
                I1=>M0,
                O=>O);
   
   I_36_9 : AND2
      port map (I0=>D1,
                I1=>S0,
                O=>M1);
   
end BEHAVIORAL;



library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity FTRSE_MXILINX_TOP_LEVEL is
   port ( C  : in    std_logic; 
          CE : in    std_logic; 
          R  : in    std_logic; 
          S  : in    std_logic; 
          T  : in    std_logic; 
          Q  : out   std_logic);
end FTRSE_MXILINX_TOP_LEVEL;

architecture BEHAVIORAL of FTRSE_MXILINX_TOP_LEVEL is
   attribute BOX_TYPE   : string ;
   attribute INIT       : string ;
   attribute RLOC       : string ;
   signal CE_S    : std_logic;
   signal D_S     : std_logic;
   signal TQ      : std_logic;
   signal Q_DUMMY : std_logic;
   component XOR2
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of XOR2 : component is "BLACK_BOX";
   
   component FDRE
      -- synopsys translate_off
      generic( INIT : bit :=  '0');
      -- synopsys translate_on
      port ( C  : in    std_logic; 
             CE : in    std_logic; 
             D  : in    std_logic; 
             R  : in    std_logic; 
             Q  : out   std_logic);
   end component;
   attribute INIT of FDRE : component is "0";
   attribute BOX_TYPE of FDRE : component is "BLACK_BOX";
   
   component OR2
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of OR2 : component is "BLACK_BOX";
   
   attribute RLOC of I_36_35 : label is "X0Y0";
begin
   Q <= Q_DUMMY;
   I_36_32 : XOR2
      port map (I0=>T,
                I1=>Q_DUMMY,
                O=>TQ);
   
   I_36_35 : FDRE
      port map (C=>C,
                CE=>CE_S,
                D=>D_S,
                R=>R,
                Q=>Q_DUMMY);
   
   I_36_73 : OR2
      port map (I0=>S,
                I1=>TQ,
                O=>D_S);
   
   I_36_77 : OR2
      port map (I0=>CE,
                I1=>S,
                O=>CE_S);
   
end BEHAVIORAL;



library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity CB4RE_MXILINX_TOP_LEVEL is
   port ( C   : in    std_logic; 
          CE  : in    std_logic; 
          R   : in    std_logic; 
          CEO : out   std_logic; 
          Q0  : out   std_logic; 
          Q1  : out   std_logic; 
          Q2  : out   std_logic; 
          Q3  : out   std_logic; 
          TC  : out   std_logic);
end CB4RE_MXILINX_TOP_LEVEL;

architecture BEHAVIORAL of CB4RE_MXILINX_TOP_LEVEL is
   attribute HU_SET     : string ;
   attribute BOX_TYPE   : string ;
   signal T2       : std_logic;
   signal T3       : std_logic;
   signal XLXN_1   : std_logic;
   signal XLXN_2   : std_logic;
   signal Q0_DUMMY : std_logic;
   signal Q1_DUMMY : std_logic;
   signal Q2_DUMMY : std_logic;
   signal Q3_DUMMY : std_logic;
   signal TC_DUMMY : std_logic;
   component FTRSE_MXILINX_TOP_LEVEL
      port ( C  : in    std_logic; 
             CE : in    std_logic; 
             R  : in    std_logic; 
             S  : in    std_logic; 
             T  : in    std_logic; 
             Q  : out   std_logic);
   end component;
   
   component AND4
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             I2 : in    std_logic; 
             I3 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND4 : component is "BLACK_BOX";
   
   component AND3
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             I2 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND3 : component is "BLACK_BOX";
   
   component AND2
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND2 : component is "BLACK_BOX";
   
   component VCC
      port ( P : out   std_logic);
   end component;
   attribute BOX_TYPE of VCC : component is "BLACK_BOX";
   
   component GND
      port ( G : out   std_logic);
   end component;
   attribute BOX_TYPE of GND : component is "BLACK_BOX";
   
   attribute HU_SET of I_Q0 : label is "I_Q0_0";
   attribute HU_SET of I_Q1 : label is "I_Q1_1";
   attribute HU_SET of I_Q2 : label is "I_Q2_2";
   attribute HU_SET of I_Q3 : label is "I_Q3_3";
begin
   Q0 <= Q0_DUMMY;
   Q1 <= Q1_DUMMY;
   Q2 <= Q2_DUMMY;
   Q3 <= Q3_DUMMY;
   TC <= TC_DUMMY;
   I_Q0 : FTRSE_MXILINX_TOP_LEVEL
      port map (C=>C,
                CE=>CE,
                R=>R,
                S=>XLXN_2,
                T=>XLXN_1,
                Q=>Q0_DUMMY);
   
   I_Q1 : FTRSE_MXILINX_TOP_LEVEL
      port map (C=>C,
                CE=>CE,
                R=>R,
                S=>XLXN_2,
                T=>Q0_DUMMY,
                Q=>Q1_DUMMY);
   
   I_Q2 : FTRSE_MXILINX_TOP_LEVEL
      port map (C=>C,
                CE=>CE,
                R=>R,
                S=>XLXN_2,
                T=>T2,
                Q=>Q2_DUMMY);
   
   I_Q3 : FTRSE_MXILINX_TOP_LEVEL
      port map (C=>C,
                CE=>CE,
                R=>R,
                S=>XLXN_2,
                T=>T3,
                Q=>Q3_DUMMY);
   
   I_36_31 : AND4
      port map (I0=>Q3_DUMMY,
                I1=>Q2_DUMMY,
                I2=>Q1_DUMMY,
                I3=>Q0_DUMMY,
                O=>TC_DUMMY);
   
   I_36_32 : AND3
      port map (I0=>Q2_DUMMY,
                I1=>Q1_DUMMY,
                I2=>Q0_DUMMY,
                O=>T3);
   
   I_36_33 : AND2
      port map (I0=>Q1_DUMMY,
                I1=>Q0_DUMMY,
                O=>T2);
   
   I_36_58 : VCC
      port map (P=>XLXN_1);
   
   I_36_64 : GND
      port map (G=>XLXN_2);
   
   I_36_69 : AND2
      port map (I0=>CE,
                I1=>TC_DUMMY,
                O=>CEO);
   
end BEHAVIORAL;



library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity FD16RE_MXILINX_TOP_LEVEL is
   port ( C  : in    std_logic; 
          CE : in    std_logic; 
          D  : in    std_logic_vector (15 downto 0); 
          R  : in    std_logic; 
          Q  : out   std_logic_vector (15 downto 0));
end FD16RE_MXILINX_TOP_LEVEL;

architecture BEHAVIORAL of FD16RE_MXILINX_TOP_LEVEL is
   attribute INIT       : string ;
   attribute BOX_TYPE   : string ;
   component FDRE
      -- synopsys translate_off
      generic( INIT : bit :=  '0');
      -- synopsys translate_on
      port ( C  : in    std_logic; 
             CE : in    std_logic; 
             D  : in    std_logic; 
             R  : in    std_logic; 
             Q  : out   std_logic);
   end component;
   attribute INIT of FDRE : component is "0";
   attribute BOX_TYPE of FDRE : component is "BLACK_BOX";
   
begin
   I_Q0 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(0),
                R=>R,
                Q=>Q(0));
   
   I_Q1 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(1),
                R=>R,
                Q=>Q(1));
   
   I_Q2 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(2),
                R=>R,
                Q=>Q(2));
   
   I_Q3 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(3),
                R=>R,
                Q=>Q(3));
   
   I_Q4 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(4),
                R=>R,
                Q=>Q(4));
   
   I_Q5 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(5),
                R=>R,
                Q=>Q(5));
   
   I_Q6 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(6),
                R=>R,
                Q=>Q(6));
   
   I_Q7 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(7),
                R=>R,
                Q=>Q(7));
   
   I_Q8 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(8),
                R=>R,
                Q=>Q(8));
   
   I_Q9 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(9),
                R=>R,
                Q=>Q(9));
   
   I_Q10 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(10),
                R=>R,
                Q=>Q(10));
   
   I_Q11 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(11),
                R=>R,
                Q=>Q(11));
   
   I_Q12 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(12),
                R=>R,
                Q=>Q(12));
   
   I_Q13 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(13),
                R=>R,
                Q=>Q(13));
   
   I_Q14 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(14),
                R=>R,
                Q=>Q(14));
   
   I_Q15 : FDRE
      port map (C=>C,
                CE=>CE,
                D=>D(15),
                R=>R,
                Q=>Q(15));
   
end BEHAVIORAL;



library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity D4_16E_MXILINX_TOP_LEVEL is
   port ( A0  : in    std_logic; 
          A1  : in    std_logic; 
          A2  : in    std_logic; 
          A3  : in    std_logic; 
          E   : in    std_logic; 
          D0  : out   std_logic; 
          D1  : out   std_logic; 
          D2  : out   std_logic; 
          D3  : out   std_logic; 
          D4  : out   std_logic; 
          D5  : out   std_logic; 
          D6  : out   std_logic; 
          D7  : out   std_logic; 
          D8  : out   std_logic; 
          D9  : out   std_logic; 
          D10 : out   std_logic; 
          D11 : out   std_logic; 
          D12 : out   std_logic; 
          D13 : out   std_logic; 
          D14 : out   std_logic; 
          D15 : out   std_logic);
end D4_16E_MXILINX_TOP_LEVEL;

architecture BEHAVIORAL of D4_16E_MXILINX_TOP_LEVEL is
   attribute BOX_TYPE   : string ;
   component AND5B3
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             I2 : in    std_logic; 
             I3 : in    std_logic; 
             I4 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND5B3 : component is "BLACK_BOX";
   
   component AND5B2
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             I2 : in    std_logic; 
             I3 : in    std_logic; 
             I4 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND5B2 : component is "BLACK_BOX";
   
   component AND5B1
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             I2 : in    std_logic; 
             I3 : in    std_logic; 
             I4 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND5B1 : component is "BLACK_BOX";
   
   component AND5
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             I2 : in    std_logic; 
             I3 : in    std_logic; 
             I4 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND5 : component is "BLACK_BOX";
   
   component AND5B4
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             I2 : in    std_logic; 
             I3 : in    std_logic; 
             I4 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND5B4 : component is "BLACK_BOX";
   
begin
   I_36_53 : AND5B3
      port map (I0=>A0,
                I1=>A1,
                I2=>A2,
                I3=>A3,
                I4=>E,
                O=>D8);
   
   I_36_54 : AND5B2
      port map (I0=>A1,
                I1=>A2,
                I2=>E,
                I3=>A3,
                I4=>A0,
                O=>D9);
   
   I_36_55 : AND5B2
      port map (I0=>A0,
                I1=>A2,
                I2=>E,
                I3=>A3,
                I4=>A1,
                O=>D10);
   
   I_36_56 : AND5B1
      port map (I0=>A2,
                I1=>A0,
                I2=>A1,
                I3=>A3,
                I4=>E,
                O=>D11);
   
   I_36_57 : AND5B2
      port map (I0=>A0,
                I1=>A1,
                I2=>E,
                I3=>A3,
                I4=>A2,
                O=>D12);
   
   I_36_58 : AND5B1
      port map (I0=>A1,
                I1=>A0,
                I2=>A2,
                I3=>A3,
                I4=>E,
                O=>D13);
   
   I_36_59 : AND5B1
      port map (I0=>A0,
                I1=>A1,
                I2=>A2,
                I3=>A3,
                I4=>E,
                O=>D14);
   
   I_36_60 : AND5
      port map (I0=>A3,
                I1=>A2,
                I2=>A1,
                I3=>A0,
                I4=>E,
                O=>D15);
   
   I_36_61 : AND5B2
      port map (I0=>A3,
                I1=>A0,
                I2=>E,
                I3=>A2,
                I4=>A1,
                O=>D6);
   
   I_36_62 : AND5B1
      port map (I0=>A3,
                I1=>A2,
                I2=>A1,
                I3=>A0,
                I4=>E,
                O=>D7);
   
   I_36_63 : AND5B2
      port map (I0=>A3,
                I1=>A1,
                I2=>E,
                I3=>A2,
                I4=>A0,
                O=>D5);
   
   I_36_64 : AND5B3
      port map (I0=>A0,
                I1=>A1,
                I2=>A3,
                I3=>A2,
                I4=>E,
                O=>D4);
   
   I_36_65 : AND5B2
      port map (I0=>A2,
                I1=>A3,
                I2=>E,
                I3=>A0,
                I4=>A1,
                O=>D3);
   
   I_36_66 : AND5B3
      port map (I0=>A0,
                I1=>A3,
                I2=>A2,
                I3=>A1,
                I4=>E,
                O=>D2);
   
   I_36_67 : AND5B3
      port map (I0=>A1,
                I1=>A2,
                I2=>A3,
                I3=>A0,
                I4=>E,
                O=>D1);
   
   I_36_68 : AND5B4
      port map (I0=>A3,
                I1=>A2,
                I2=>A1,
                I3=>A0,
                I4=>E,
                O=>D0);
   
end BEHAVIORAL;



library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity TOP_LEVEL is
   port ( BUSAHS_00DN_01S   : in    std_logic; 
          BUSAHS_00DP_00S   : in    std_logic; 
          BUSAHS_01DN_03S   : in    std_logic; 
          BUSAHS_01DP_02S   : in    std_logic; 
          BUSA_12DN_25S     : in    std_logic; 
          BUSA_12DP_24S     : in    std_logic; 
          BUSA_14DN_29S     : in    std_logic; 
          BUSA_14DP_28S     : in    std_logic; 
          BUSA_16DN_33S     : in    std_logic; 
          BUSA_16DP_32S     : in    std_logic; 
          BUSA_17DN_35S     : in    std_logic; 
          BUSA_17DP_34S     : in    std_logic; 
          BUSBB_05DN_11S    : in    std_logic; 
          BUSBB_05DP_10S    : in    std_logic; 
          BUSC_16DP_32S     : in    std_logic; 
          BUSC_17DN_35S     : in    std_logic; 
          BUSC_17DP_34S     : in    std_logic; 
          BUSC_18DN_37S     : in    std_logic; 
          BUSC_18DP_36S     : in    std_logic; 
          BUSC_19DN_39S     : in    std_logic; 
          BUSC_19DP_38S     : in    std_logic; 
          BUSC_20DN_41S     : in    std_logic; 
          BUSC_20DP_40S     : in    std_logic; 
          BUSC_26DP_52S     : in    std_logic; 
          BUSC_27DP_54S     : in    std_logic; 
          BUSD_23DN_47S     : in    std_logic; 
          BUSD_23DP_46S     : in    std_logic; 
          GENERAL_02DN_05S  : in    std_logic; 
          GENERAL_02DP_04S  : in    std_logic; 
          GENERAL_03DN_07S  : in    std_logic; 
          PRIMARY_CLK       : in    std_logic; 
          SECONDARY_CLK     : in    std_logic; 
          BUSAHS_02DN_05S   : out   std_logic; 
          BUSBB_00DN_01S    : out   std_logic; 
          BUSBB_00DP_00S    : out   std_logic; 
          BUSBB_01DN_03S    : out   std_logic; 
          BUSBB_01DP_02S    : out   std_logic; 
          BUSBB_02DP_04S    : out   std_logic; 
          BUSBB_03DN_07S    : out   std_logic; 
          BUSBB_03DP_06S    : out   std_logic; 
          BUSBB_04DN_09S    : out   std_logic; 
          BUSBB_04DP_08S    : out   std_logic; 
          BUSC_14DN_29S     : out   std_logic; 
          BUSC_14DP_28S     : out   std_logic; 
          BUSC_15DN_31S     : out   std_logic; 
          BUSC_15DP_30S     : out   std_logic; 
          BUSC_16DN_33S     : out   std_logic; 
          BUSC_24DN_49S     : out   std_logic; 
          BUSC_24DP_48S     : out   std_logic; 
          BUSC_25DN_51S     : out   std_logic; 
          BUSC_25DP_50S     : out   std_logic; 
          BUSC_26DN_53S     : out   std_logic; 
          BUSC_27DN_55S     : out   std_logic; 
          BUSD_19DN_39S     : out   std_logic; 
          BUSD_19DP_38S     : out   std_logic; 
          BUSD_20DN_41S     : out   std_logic; 
          BUSD_20DP_40S     : out   std_logic; 
          BUSD_21DN_43S     : out   std_logic; 
          BUSD_21DP_42S     : out   std_logic; 
          BUSD_22DN_45S     : out   std_logic; 
          BUSD_22DP_44S     : out   std_logic; 
          GENERAL_03DP_06S  : out   std_logic; 
          GENERAL_05DN_11S  : out   std_logic; 
          INTERNAL_04DN_09S : out   std_logic; 
          INTERNAL_05DN_11S : out   std_logic; 
          INTERNAL_05DP_10S : out   std_logic; 
          BUSC_21DN_43S     : inout std_logic);
end TOP_LEVEL;

architecture BEHAVIORAL of TOP_LEVEL is
   attribute CLK_FEEDBACK          : string ;
   attribute CLKDV_DIVIDE          : string ;
   attribute CLKFX_DIVIDE          : string ;
   attribute CLKFX_MULTIPLY        : string ;
   attribute CLKIN_DIVIDE_BY_2     : string ;
   attribute CLKIN_PERIOD          : string ;
   attribute CLKOUT_PHASE_SHIFT    : string ;
   attribute DCM_PERFORMANCE_MODE  : string ;
   attribute DESKEW_ADJUST         : string ;
   attribute DFS_FREQUENCY_MODE    : string ;
   attribute DLL_FREQUENCY_MODE    : string ;
   attribute DUTY_CYCLE_CORRECTION : string ;
   attribute FACTORY_JF            : string ;
   attribute PHASE_SHIFT           : string ;
   attribute STARTUP_WAIT          : string ;
   attribute DCM_AUTOCALIBRATION   : string ;
   attribute BOX_TYPE              : string ;
   attribute INIT                  : string ;
   attribute IOBDELAY_VALUE        : string ;
   attribute IOBDELAY_TYPE         : string ;
   attribute HU_SET                : string ;
   attribute IOSTANDARD            : string ;
   attribute CAPACITANCE           : string ;
   attribute SLEW                  : string ;
   attribute DRIVE                 : string ;
   attribute DIFF_TERM             : string ;
   signal adc_burst_we           : std_logic;
   signal ADC_CLK_IN             : std_logic;
   signal ADC_CLK_OUT            : std_logic;
   signal adc_clk_sel            : std_logic;
   signal ADC_CLK_SEL_MAP        : std_logic;
   signal ADC_CLOCK_MAP          : std_logic;
   signal adc_data_del_ce        : std_logic;
   signal adc_data_del_ce_ch1    : std_logic;
   signal adc_data_del_rst       : std_logic;
   signal adc_data_del_rst_ch1   : std_logic;
   signal adc_data_label         : std_logic_vector (3 downto 0);
   signal ADC_DCM_FB             : std_logic;
   signal adc_delayed_clk        : std_logic;
   signal adc_delayed_data       : std_logic_vector (1 downto 0);
   signal adc_delayed_frame      : std_logic;
   signal ADC_DELAY_MAP          : std_logic;
   signal ADC_FRAME_OUT          : std_logic;
   signal adc_sample_we          : std_logic;
   signal ADC_TESTMODE_MAP       : std_logic;
   signal adc_testmode_sig       : std_logic;
   signal ADC_65MSPS_CH0         : std_logic;
   signal ADC_65MSPS_CH1         : std_logic;
   signal BURST_DATA_SEL_MAP     : std_logic;
   signal b_data                 : std_logic_vector (63 downto 0);
   signal b_data_pre_we0         : std_logic;
   signal b_data_pre_we1         : std_logic;
   signal b_data_sel             : std_logic;
   signal b_data_we              : std_logic;
   signal b_data_we0             : std_logic;
   signal b_data_we1             : std_logic;
   signal b_data0                : std_logic_vector (63 downto 0);
   signal b_data1                : std_logic_vector (63 downto 0);
   signal b_enable               : std_logic;
   signal b_end_packet           : std_logic;
   signal cal_tag                : std_logic_vector (15 downto 0);
   signal cal_tag_trig_num_sel   : std_logic;
   signal CHAN1_SPEC_DEL_MAP     : std_logic;
   signal clock_5mhz             : std_logic;
   signal clock_66mhz            : std_logic;
   signal DCM_PSI_RESET_MAP      : std_logic;
   signal dcm_reset              : std_logic;
   signal dcm_reset_psi          : std_logic;
   signal display_load_bar       : std_logic;
   signal DISPLAY_MAP            : std_logic;
   signal display_ser_data       : std_logic;
   signal EN_TRIG_TOK_MAP        : std_logic;
   signal EXT_CLK                : std_logic;
   signal EXT_TRIGG              : std_logic;
   signal gec_user_addrs         : std_logic_vector (7 downto 0);
   signal gec_user_busy          : std_logic;
   signal gec_user_crc_err       : std_logic;
   signal gec_user_rx_data_out   : std_logic_vector (7 downto 0);
   signal gec_user_rx_size_out   : std_logic_vector (10 downto 0);
   signal gec_user_rx_valid_out  : std_logic;
   signal gec_user_trigger       : std_logic;
   signal gec_user_tx_data_in    : std_logic_vector (7 downto 0);
   signal gec_user_tx_enable_out : std_logic;
   signal gec_user_tx_size_in    : std_logic_vector (10 downto 0);
   signal GLOBAL_RESET_MAP       : std_logic;
   signal GMII_RXD_0_sig         : std_logic_vector (7 downto 0);
   signal GMII_RX_DV_0_sig       : std_logic;
   signal GMII_RX_ER_0_sig       : std_logic;
   signal GTX_CLK_0_sig          : std_logic;
   signal initial_reset          : std_logic;
   signal INT_HALF_CLK           : std_logic;
   signal MASTER_CLK             : std_logic;
   signal MEM_BLK_MAP            : std_logic;
   signal PHY_TXD_sig            : std_logic_vector (7 downto 0);
   signal PHY_TXEN_sig           : std_logic;
   signal PHY_TXER_sig           : std_logic;
   signal plaq_id0               : std_logic_vector (2 downto 0);
   signal plaq_id1               : std_logic_vector (2 downto 0);
   signal PSI_CAL_TAG_MAP        : std_logic;
   signal PSI_CLK0               : std_logic;
   signal PSI_CLK90              : std_logic;
   signal psi_cmd_fifo_empty     : std_logic;
   signal psi_cmd_fifo_full      : std_logic;
   signal PSI_CMD_FIFO_MAP       : std_logic;
   signal psi_cmd_fifo_re        : std_logic;
   signal psi_data_out           : std_logic;
   signal psi_data_out_sel       : std_logic;
   signal psi_data_out0          : std_logic;
   signal psi_data_out1          : std_logic;
   signal psi_debug_sample       : std_logic_vector (1 downto 0);
   signal psi_extdom_trig        : std_logic;
   signal PSI_LEVELS_MAP         : std_logic;
   signal PSI_LEVELS_MAP0        : std_logic;
   signal PSI_LEVELS_MAP1        : std_logic;
   signal PSI_PULSES_MAP         : std_logic;
   signal psi_reset              : std_logic;
   signal PSI_SAMPLE_DEBUG_MAP   : std_logic;
   signal PSI_SAMPLE_SEL_MAP     : std_logic;
   signal psi_sample_sel0        : std_logic;
   signal psi_sample_sel1        : std_logic;
   signal PSI_SEROUT_SEL_MAP     : std_logic;
   signal psi_tkn_rst            : std_logic;
   signal psi_token_in           : std_logic;
   signal psi_token_out0         : std_logic;
   signal psi_token_out1         : std_logic;
   signal psi_trigger            : std_logic;
   signal reset                  : std_logic;
   signal reset_button           : std_logic;
   signal reset_extension        : std_logic;
   signal reset_n                : std_logic;
   signal reset_phy              : std_logic;
   signal reset_start            : std_logic;
   signal reset_trig_counter     : std_logic;
   signal RESET_TRIG_NUM_MAP     : std_logic;
   signal rx_addr                : std_logic_vector (63 downto 0);
   signal rx_data                : std_logic_vector (63 downto 0);
   signal rx_wren                : std_logic;
   signal software_reset         : std_logic;
   signal sw_en_pulse            : std_logic;
   signal sw_trig_reset          : std_logic;
   signal token                  : std_logic_vector (1 downto 0);
   signal trigger_number         : std_logic_vector (19 downto 0);
   signal trig_reset             : std_logic;
   signal tx_data                : std_logic_vector (63 downto 0);
   signal we_out0                : std_logic;
   signal we_out1                : std_logic;
   signal XLXN_460               : std_logic;
   signal XLXN_11574             : std_logic;
   signal XLXN_12023             : std_logic;
   signal XLXN_12172             : std_logic;
   signal XLXN_12188             : std_logic;
   signal XLXN_12220             : std_logic;
   signal XLXN_12229             : std_logic;
   signal XLXN_12239             : std_logic;
   signal XLXN_12242             : std_logic;
   signal XLXN_12249             : std_logic;
   signal XLXN_12252             : std_logic;
   signal XLXN_12257             : std_logic;
   signal XLXN_12498             : std_logic;
   signal XLXN_12503             : std_logic;
   signal XLXN_12617             : std_logic;
   signal XLXN_15064             : std_logic;
   signal XLXN_15111             : std_logic;
   signal XLXN_15146             : std_logic;
   signal XLXN_15149             : std_logic;
   signal XLXN_15151             : std_logic;
   signal XLXN_15543             : std_logic_vector (31 downto 0);
   signal XLXN_15755             : std_logic;
   signal XLXN_15817             : std_logic;
   signal XLXN_15818             : std_logic;
   signal XLXN_15824             : std_logic;
   signal XLXN_15825             : std_logic;
   signal XLXN_15844             : std_logic;
   signal XLXN_15845             : std_logic;
   signal XLXN_15849             : std_logic;
   signal XLXN_15850             : std_logic;
   component PSI_Chip_Readout_Blk
      port ( adc_delayed_clk  : in    std_logic; 
             adc_delayed_data : in    std_logic; 
             reset            : in    std_logic; 
             rx_addr          : in    std_logic_vector (4 downto 0); 
             MASTER_CLK       : in    std_logic; 
             psi_sample_sel   : in    std_logic; 
             psi_debug_sample : in    std_logic_vector (1 downto 0); 
             PSI_LEVELS_MAP   : in    std_logic; 
             PSI_CLK90        : in    std_logic; 
             psi_token_out    : in    std_logic; 
             adc_data_label   : in    std_logic_vector (3 downto 0); 
             rx_data          : in    std_logic_vector (63 downto 0); 
             adc_sample_we    : in    std_logic; 
             adc_burst_we     : in    std_logic; 
             b_data_we        : out   std_logic; 
             b_data           : out   std_logic_vector (63 downto 0); 
             b_data_sel       : in    std_logic);
   end component;
   
   component chip_token_manager
      port ( reset                : in    std_logic; 
             clk                  : in    std_logic; 
             token_in             : in    std_logic; 
             first_in_token_chain : in    std_logic; 
             data_sel             : in    std_logic; 
             cal_trig_sel         : in    std_logic; 
             pdin_we              : in    std_logic; 
             plaq_id              : in    std_logic_vector (2 downto 0); 
             cal_tag              : in    std_logic_vector (15 downto 0); 
             trig_num             : in    std_logic_vector (19 downto 0); 
             pdin                 : in    std_logic_vector (63 downto 0); 
             bus_dout             : inout std_logic_vector (63 downto 0); 
             ovf_err              : out   std_logic; 
             token_out            : out   std_logic; 
             we_out               : out   std_logic);
   end component;
   
   component gigabit_ethernet_controller
      port ( user_tx_data_in    : in    std_logic_vector (7 downto 0); 
             user_tx_size_in    : in    std_logic_vector (10 downto 0); 
             user_addrs         : in    std_logic_vector (7 downto 0); 
             GMII_RXD           : in    std_logic_vector (7 downto 0); 
             GMII_RX_CLK        : in    std_logic; 
             user_test_mode     : in    std_logic; 
             user_trigger       : in    std_logic; 
             GMII_RX_DV         : in    std_logic; 
             GMII_RX_ER         : in    std_logic; 
             user_rx_size_out   : out   std_logic_vector (10 downto 0); 
             GMII_TX_EN         : out   std_logic; 
             GMII_TX_ER         : out   std_logic; 
             GTX_CLK            : out   std_logic; 
             user_busy          : out   std_logic; 
             user_rx_valid_out  : out   std_logic; 
             user_tx_enable_out : out   std_logic; 
             user_rx_data_out   : out   std_logic_vector (7 downto 0); 
             GMII_TXD           : out   std_logic_vector (7 downto 0); 
             crc_err            : out   std_logic; 
             reset              : in    std_logic);
   end component;
   
   component DCM_ADV
      -- synopsys translate_off
      generic( CLK_FEEDBACK : string :=  "1X";
               CLKDV_DIVIDE : real :=  2.0;
               CLKFX_DIVIDE : integer :=  1;
               CLKFX_MULTIPLY : integer :=  4;
               CLKIN_DIVIDE_BY_2 : boolean :=  FALSE;
               CLKIN_PERIOD : real :=  10.0;
               CLKOUT_PHASE_SHIFT : string :=  "NONE";
               DCM_PERFORMANCE_MODE : string :=  "MAX_SPEED";
               DESKEW_ADJUST : string :=  "SYSTEM_SYNCHRONOUS";
               DFS_FREQUENCY_MODE : string :=  "LOW";
               DLL_FREQUENCY_MODE : string :=  "LOW";
               DUTY_CYCLE_CORRECTION : boolean :=  TRUE;
               FACTORY_JF : bit_vector :=  x"F0F0";
               PHASE_SHIFT : integer :=  0;
               STARTUP_WAIT : boolean :=  FALSE;
               DCM_AUTOCALIBRATION : boolean :=  TRUE);
      -- synopsys translate_on
      port ( CLKIN    : in    std_logic; 
             CLKFB    : in    std_logic; 
             RST      : in    std_logic; 
             PSINCDEC : in    std_logic; 
             PSEN     : in    std_logic; 
             PSCLK    : in    std_logic; 
             DADDR    : in    std_logic_vector (6 downto 0); 
             DI       : in    std_logic_vector (15 downto 0); 
             DWE      : in    std_logic; 
             DEN      : in    std_logic; 
             DCLK     : in    std_logic; 
             CLK0     : out   std_logic; 
             CLK90    : out   std_logic; 
             CLK180   : out   std_logic; 
             CLK270   : out   std_logic; 
             CLK2X    : out   std_logic; 
             CLK2X180 : out   std_logic; 
             CLKDV    : out   std_logic; 
             CLKFX    : out   std_logic; 
             CLKFX180 : out   std_logic; 
             LOCKED   : out   std_logic; 
             PSDONE   : out   std_logic; 
             DO       : out   std_logic_vector (15 downto 0); 
             DRDY     : out   std_logic);
   end component;
   attribute CLK_FEEDBACK of DCM_ADV : component is "1X";
   attribute CLKDV_DIVIDE of DCM_ADV : component is "2.0";
   attribute CLKFX_DIVIDE of DCM_ADV : component is "1";
   attribute CLKFX_MULTIPLY of DCM_ADV : component is "4";
   attribute CLKIN_DIVIDE_BY_2 of DCM_ADV : component is "FALSE";
   attribute CLKIN_PERIOD of DCM_ADV : component is "10.0";
   attribute CLKOUT_PHASE_SHIFT of DCM_ADV : component is "NONE";
   attribute DCM_PERFORMANCE_MODE of DCM_ADV : component is "MAX_SPEED";
   attribute DESKEW_ADJUST of DCM_ADV : component is "SYSTEM_SYNCHRONOUS";
   attribute DFS_FREQUENCY_MODE of DCM_ADV : component is "LOW";
   attribute DLL_FREQUENCY_MODE of DCM_ADV : component is "LOW";
   attribute DUTY_CYCLE_CORRECTION of DCM_ADV : component is "TRUE";
   attribute FACTORY_JF of DCM_ADV : component is "F0F0";
   attribute PHASE_SHIFT of DCM_ADV : component is "0";
   attribute STARTUP_WAIT of DCM_ADV : component is "FALSE";
   attribute DCM_AUTOCALIBRATION of DCM_ADV : component is "TRUE";
   attribute BOX_TYPE of DCM_ADV : component is "BLACK_BOX";
   
   component BUFG
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute BOX_TYPE of BUFG : component is "BLACK_BOX";
   
   component FDE
      -- synopsys translate_off
      generic( INIT : bit :=  '0');
      -- synopsys translate_on
      port ( C  : in    std_logic; 
             CE : in    std_logic; 
             D  : in    std_logic; 
             Q  : out   std_logic);
   end component;
   attribute INIT of FDE : component is "0";
   attribute BOX_TYPE of FDE : component is "BLACK_BOX";
   
   component INV
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute BOX_TYPE of INV : component is "BLACK_BOX";
   
   component GND
      port ( G : out   std_logic);
   end component;
   attribute BOX_TYPE of GND : component is "BLACK_BOX";
   
   component IDELAY
      -- synopsys translate_off
      generic( IOBDELAY_VALUE : integer :=  0;
               IOBDELAY_TYPE : string :=  "DEFAULT");
      -- synopsys translate_on
      port ( I   : in    std_logic; 
             CE  : in    std_logic; 
             C   : in    std_logic; 
             INC : in    std_logic; 
             RST : in    std_logic; 
             O   : out   std_logic);
   end component;
   attribute IOBDELAY_VALUE of IDELAY : component is "0";
   attribute IOBDELAY_TYPE of IDELAY : component is "DEFAULT";
   attribute BOX_TYPE of IDELAY : component is "BLACK_BOX";
   
   component IDELAYCTRL
      port ( REFCLK : in    std_logic; 
             RST    : in    std_logic; 
             RDY    : out   std_logic);
   end component;
   attribute BOX_TYPE of IDELAYCTRL : component is "BLACK_BOX";
   
   component AND2
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND2 : component is "BLACK_BOX";
   
   component DCM_BASE
      -- synopsys translate_off
      generic( CLK_FEEDBACK : string :=  "1X";
               CLKDV_DIVIDE : real :=  2.0;
               CLKFX_DIVIDE : integer :=  1;
               CLKFX_MULTIPLY : integer :=  4;
               CLKIN_DIVIDE_BY_2 : boolean :=  FALSE;
               CLKIN_PERIOD : real :=  10.0;
               CLKOUT_PHASE_SHIFT : string :=  "NONE";
               DCM_PERFORMANCE_MODE : string :=  "MAX_SPEED";
               DESKEW_ADJUST : string :=  "SYSTEM_SYNCHRONOUS";
               DFS_FREQUENCY_MODE : string :=  "LOW";
               DLL_FREQUENCY_MODE : string :=  "LOW";
               DUTY_CYCLE_CORRECTION : boolean :=  TRUE;
               FACTORY_JF : bit_vector :=  x"F0F0";
               PHASE_SHIFT : integer :=  0;
               STARTUP_WAIT : boolean :=  FALSE;
               DCM_AUTOCALIBRATION : boolean :=  TRUE);
      -- synopsys translate_on
      port ( CLKIN    : in    std_logic; 
             CLKFB    : in    std_logic; 
             RST      : in    std_logic; 
             CLK0     : out   std_logic; 
             CLK90    : out   std_logic; 
             CLK180   : out   std_logic; 
             CLK270   : out   std_logic; 
             CLK2X    : out   std_logic; 
             CLK2X180 : out   std_logic; 
             CLKDV    : out   std_logic; 
             CLKFX    : out   std_logic; 
             CLKFX180 : out   std_logic; 
             LOCKED   : out   std_logic);
   end component;
   attribute CLK_FEEDBACK of DCM_BASE : component is "1X";
   attribute CLKDV_DIVIDE of DCM_BASE : component is "2.0";
   attribute CLKFX_DIVIDE of DCM_BASE : component is "1";
   attribute CLKFX_MULTIPLY of DCM_BASE : component is "4";
   attribute CLKIN_DIVIDE_BY_2 of DCM_BASE : component is "FALSE";
   attribute CLKIN_PERIOD of DCM_BASE : component is "10.0";
   attribute CLKOUT_PHASE_SHIFT of DCM_BASE : component is "NONE";
   attribute DCM_PERFORMANCE_MODE of DCM_BASE : component is "MAX_SPEED";
   attribute DESKEW_ADJUST of DCM_BASE : component is "SYSTEM_SYNCHRONOUS";
   attribute DFS_FREQUENCY_MODE of DCM_BASE : component is "LOW";
   attribute DLL_FREQUENCY_MODE of DCM_BASE : component is "LOW";
   attribute DUTY_CYCLE_CORRECTION of DCM_BASE : component is "TRUE";
   attribute FACTORY_JF of DCM_BASE : component is "F0F0";
   attribute PHASE_SHIFT of DCM_BASE : component is "0";
   attribute STARTUP_WAIT of DCM_BASE : component is "FALSE";
   attribute DCM_AUTOCALIBRATION of DCM_BASE : component is "TRUE";
   attribute BOX_TYPE of DCM_BASE : component is "BLACK_BOX";
   
   component OR3B1
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             I2 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of OR3B1 : component is "BLACK_BOX";
   
   component D4_16E_MXILINX_TOP_LEVEL
      port ( A0  : in    std_logic; 
             A1  : in    std_logic; 
             A2  : in    std_logic; 
             A3  : in    std_logic; 
             E   : in    std_logic; 
             D0  : out   std_logic; 
             D1  : out   std_logic; 
             D10 : out   std_logic; 
             D11 : out   std_logic; 
             D12 : out   std_logic; 
             D13 : out   std_logic; 
             D14 : out   std_logic; 
             D15 : out   std_logic; 
             D2  : out   std_logic; 
             D3  : out   std_logic; 
             D4  : out   std_logic; 
             D5  : out   std_logic; 
             D6  : out   std_logic; 
             D7  : out   std_logic; 
             D8  : out   std_logic; 
             D9  : out   std_logic);
   end component;
   
   component OR2
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of OR2 : component is "BLACK_BOX";
   
   component ADC_frame_counter
      port ( ADC_clk   : in    std_logic; 
             ADC_frame : in    std_logic; 
             rst_n     : in    std_logic; 
             ADC_en    : out   std_logic);
   end component;
   
   component CB4RE_MXILINX_TOP_LEVEL
      port ( C   : in    std_logic; 
             CE  : in    std_logic; 
             R   : in    std_logic; 
             CEO : out   std_logic; 
             Q0  : out   std_logic; 
             Q1  : out   std_logic; 
             Q2  : out   std_logic; 
             Q3  : out   std_logic; 
             TC  : out   std_logic);
   end component;
   
   component FDRE
      -- synopsys translate_off
      generic( INIT : bit :=  '0');
      -- synopsys translate_on
      port ( C  : in    std_logic; 
             CE : in    std_logic; 
             D  : in    std_logic; 
             R  : in    std_logic; 
             Q  : out   std_logic);
   end component;
   attribute INIT of FDRE : component is "0";
   attribute BOX_TYPE of FDRE : component is "BLACK_BOX";
   
   component DATA_MANAGER
      port ( reset                  : in    std_logic; 
             MASTER_CLK             : in    std_logic; 
             reset_n                : in    std_logic; 
             gec_user_rx_size_out   : in    std_logic_vector (10 downto 0); 
             gec_user_crc_err       : in    std_logic; 
             gec_user_rx_valid_out  : in    std_logic; 
             gec_user_rx_data_out   : in    std_logic_vector (7 downto 0); 
             gec_user_busy          : in    std_logic; 
             gec_user_tx_enable_out : in    std_logic; 
             b_data_we              : in    std_logic; 
             b_data                 : in    std_logic_vector (63 downto 0); 
             b_end_packet           : in    std_logic; 
             ram_wren               : out   std_logic; 
             ram_addr               : out   std_logic_vector (63 downto 0); 
             gec_user_tx_data_in    : out   std_logic_vector (7 downto 0); 
             gec_user_tx_size_in    : out   std_logic_vector (10 downto 0); 
             gec_user_trigger       : out   std_logic; 
             b_enable               : out   std_logic; 
             tx_data                : in    std_logic_vector (63 downto 0); 
             rx_data                : out   std_logic_vector (63 downto 0));
   end component;
   
   component DELAY16
      port ( CLOCK_INIT : in    std_logic; 
             in_sig     : in    std_logic; 
             RESET_INIT : out   std_logic);
   end component;
   
   component RESET_INIT
      port ( CLOCK_INIT : in    std_logic; 
             RESET_INIT : out   std_logic);
   end component;
   
   component VCC
      port ( P : out   std_logic);
   end component;
   attribute BOX_TYPE of VCC : component is "BLACK_BOX";
   
   component ADC_single_frame_counter
      port ( ADC_clk   : in    std_logic; 
             ADC_frame : in    std_logic; 
             rst_n     : in    std_logic; 
             ADC_en    : out   std_logic);
   end component;
   
   component burst_traffic_controller
      port ( MASTER_CLK       : in    std_logic; 
             RESET            : in    std_logic; 
             BURST_WE         : in    std_logic; 
             BURST_END_PACKET : out   std_logic);
   end component;
   
   component IBUFG
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute IOSTANDARD of IBUFG : component is "DEFAULT";
   attribute CAPACITANCE of IBUFG : component is "DONT_CARE";
   attribute BOX_TYPE of IBUFG : component is "BLACK_BOX";
   
   component IOBUF
      port ( I  : in    std_logic; 
             IO : inout std_logic; 
             O  : out   std_logic; 
             T  : in    std_logic);
   end component;
   attribute IOSTANDARD of IOBUF : component is "DEFAULT";
   attribute CAPACITANCE of IOBUF : component is "DONT_CARE";
   attribute SLEW of IOBUF : component is "SLOW";
   attribute DRIVE of IOBUF : component is "12";
   attribute BOX_TYPE of IOBUF : component is "BLACK_BOX";
   
   component OBUF
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute IOSTANDARD of OBUF : component is "DEFAULT";
   attribute CAPACITANCE of OBUF : component is "DONT_CARE";
   attribute SLEW of OBUF : component is "SLOW";
   attribute DRIVE of OBUF : component is "12";
   attribute BOX_TYPE of OBUF : component is "BLACK_BOX";
   
   component IBUF
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute IOSTANDARD of IBUF : component is "DEFAULT";
   attribute CAPACITANCE of IBUF : component is "DONT_CARE";
   attribute BOX_TYPE of IBUF : component is "BLACK_BOX";
   
   component VERSION_BLK
      port ( version : out   std_logic_vector (7 downto 0));
   end component;
   
   component IBUFDS
      -- synopsys translate_off
      generic( DIFF_TERM : boolean :=  FALSE);
      -- synopsys translate_on
      port ( I  : in    std_logic; 
             IB : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute IOSTANDARD of IBUFDS : component is "DEFAULT";
   attribute CAPACITANCE of IBUFDS : component is "DONT_CARE";
   attribute DIFF_TERM of IBUFDS : component is "FALSE";
   attribute BOX_TYPE of IBUFDS : component is "BLACK_BOX";
   
   component OBUFDS
      port ( I  : in    std_logic; 
             O  : out   std_logic; 
             OB : out   std_logic);
   end component;
   attribute IOSTANDARD of OBUFDS : component is "DEFAULT";
   attribute CAPACITANCE of OBUFDS : component is "DONT_CARE";
   attribute BOX_TYPE of OBUFDS : component is "BLACK_BOX";
   
   component psi_command_sender
      port ( psi_clk    : in    std_logic; 
             reset      : in    std_logic; 
             fifo_empty : in    std_logic; 
             fifo_full  : in    std_logic; 
             data       : in    std_logic_vector (31 downto 0); 
             fifo_re    : out   std_logic; 
             data_error : out   std_logic; 
             we_error   : out   std_logic; 
             data_out   : out   std_logic);
   end component;
   
   component psi_cmd_fifo32
      port ( rd_clk : in    std_logic; 
             rd_en  : in    std_logic; 
             rst    : in    std_logic; 
             wr_clk : in    std_logic; 
             wr_en  : in    std_logic; 
             din    : in    std_logic_vector (31 downto 0); 
             empty  : out   std_logic; 
             full   : out   std_logic; 
             dout   : out   std_logic_vector (31 downto 0));
   end component;
   
   component token_trigger_controller
      port ( is_ext_mode         : in    std_logic; 
             use_cal_inject      : in    std_logic; 
             sw_en_pulse         : in    std_logic; 
             param_we            : in    std_logic; 
             ext_trigger         : in    std_logic; 
             master_clk          : in    std_logic; 
             psi_clk             : in    std_logic; 
             rst                 : in    std_logic; 
             trig_repetition_per : in    std_logic_vector (15 downto 0); 
             inject_trig_gap     : in    std_logic_vector (7 downto 0); 
             trig_token_gap      : in    std_logic_vector (15 downto 0); 
             num_of_triggers     : in    std_logic_vector (7 downto 0); 
             token               : out   std_logic; 
             trigger             : out   std_logic; 
             error               : out   std_logic);
   end component;
   
   component display_fifo
      port ( rd_clk : in    std_logic; 
             rd_en  : in    std_logic; 
             rst    : in    std_logic; 
             wr_clk : in    std_logic; 
             wr_en  : in    std_logic; 
             din    : in    std_logic_vector (7 downto 0); 
             empty  : out   std_logic; 
             full   : out   std_logic; 
             dout   : out   std_logic_vector (0 downto 0));
   end component;
   
   component FD
      -- synopsys translate_off
      generic( INIT : bit :=  '0');
      -- synopsys translate_on
      port ( C : in    std_logic; 
             D : in    std_logic; 
             Q : out   std_logic);
   end component;
   attribute INIT of FD : component is "0";
   attribute BOX_TYPE of FD : component is "BLACK_BOX";
   
   component FD16RE_MXILINX_TOP_LEVEL
      port ( C  : in    std_logic; 
             CE : in    std_logic; 
             D  : in    std_logic_vector (15 downto 0); 
             R  : in    std_logic; 
             Q  : out   std_logic_vector (15 downto 0));
   end component;
   
   component PLAQ_ID_GEN
      port ( plaq_id0 : out   std_logic_vector (2 downto 0); 
             plaq_id1 : out   std_logic_vector (2 downto 0));
   end component;
   
   component AND2B1
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND2B1 : component is "BLACK_BOX";
   
   component OR2B1
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of OR2B1 : component is "BLACK_BOX";
   
   component plaq_enable_blk
      port ( b_data_sel       : in    std_logic; 
             psi_data_out_sel : in    std_logic; 
             pre_we0          : in    std_logic; 
             pre_we1          : in    std_logic; 
             debug_sel        : in    std_logic_vector (1 downto 0); 
             we0              : out   std_logic; 
             we1              : out   std_logic);
   end component;
   
   component External_Trigger_Handler
      port ( ext_clk            : in    std_logic; 
             ext_trigger        : in    std_logic; 
             master_clk         : in    std_logic; 
             reset              : in    std_logic; 
             reset_trig_counter : in    std_logic; 
             psi_clk            : in    std_logic; 
             psi_trigger        : in    std_logic; 
             psi_trig           : out   std_logic; 
             trig_num           : out   std_logic_vector (19 downto 0));
   end component;
   
   component M2_1_MXILINX_TOP_LEVEL
      port ( D0 : in    std_logic; 
             D1 : in    std_logic; 
             S0 : in    std_logic; 
             O  : out   std_logic);
   end component;
   
   component FTC_MXILINX_TOP_LEVEL
      port ( C   : in    std_logic; 
             CLR : in    std_logic; 
             T   : in    std_logic; 
             Q   : out   std_logic);
   end component;
   
   attribute CLKFX_MULTIPLY of XLXI_3254 : label is "16";
   attribute CLKFX_DIVIDE of XLXI_3254 : label is "27";
   attribute CLKIN_PERIOD of XLXI_3254 : label is "8.0";
   attribute IOBDELAY_TYPE of XLXI_3405 : label is "VARIABLE";
   attribute CLKIN_PERIOD of XLXI_3410 : label is "8.0";
   attribute CLKFX_MULTIPLY of XLXI_3410 : label is "8";
   attribute CLKFX_DIVIDE of XLXI_3410 : label is "5";
   attribute IOBDELAY_TYPE of XLXI_3420 : label is "VARIABLE";
   attribute IOBDELAY_TYPE of XLXI_3423 : label is "VARIABLE";
   attribute HU_SET of XLXI_3432 : label is "XLXI_3432_4";
   attribute HU_SET of XLXI_3497 : label is "XLXI_3497_7";
   attribute DIFF_TERM of XLXI_4501 : label is "TRUE";
   attribute DIFF_TERM of XLXI_4502 : label is "TRUE";
   attribute DIFF_TERM of XLXI_4504 : label is "TRUE";
   attribute DIFF_TERM of XLXI_4514 : label is "TRUE";
   attribute HU_SET of XLXI_4595 : label is "XLXI_4595_6";
   attribute CLKIN_PERIOD of XLXI_4615 : label is "74.0";
   attribute CLKFX_DIVIDE of XLXI_4615 : label is "4";
   attribute DCM_PERFORMANCE_MODE of XLXI_4615 : label is "MAX_RANGE";
   attribute IOBDELAY_TYPE of XLXI_4648 : label is "VARIABLE";
   attribute DIFF_TERM of XLXI_4670 : label is "TRUE";
   attribute HU_SET of XLXI_4677 : label is "XLXI_4677_5";
   attribute DIFF_TERM of XLXI_4715 : label is "TRUE";
   attribute HU_SET of XLXI_4773 : label is "XLXI_4773_8";
   attribute HU_SET of XLXI_4791 : label is "XLXI_4791_9";
   attribute DIFF_TERM of XLXI_4794 : label is "TRUE";
   attribute DIFF_TERM of XLXI_4795 : label is "TRUE";
begin
   CHIP0_READOUT : PSI_Chip_Readout_Blk
      port map (adc_burst_we=>adc_burst_we,
                adc_data_label(3 downto 0)=>adc_data_label(3 downto 0),
                adc_delayed_clk=>adc_delayed_clk,
                adc_delayed_data=>adc_delayed_data(0),
                adc_sample_we=>adc_sample_we,
                b_data_sel=>b_data_sel,
                MASTER_CLK=>MASTER_CLK,
                PSI_CLK90=>PSI_CLK90,
                psi_debug_sample(1 downto 0)=>psi_debug_sample(1 downto 0),
                PSI_LEVELS_MAP=>PSI_LEVELS_MAP0,
                psi_sample_sel=>psi_sample_sel0,
                psi_token_out=>psi_token_out0,
                reset=>reset,
                rx_addr(4 downto 0)=>rx_addr(4 downto 0),
                rx_data(63 downto 0)=>rx_data(63 downto 0),
                b_data(63 downto 0)=>b_data0(63 downto 0),
                b_data_we=>b_data_pre_we0);
   
   CHIP0_TMGR : chip_token_manager
      port map (cal_tag(15 downto 0)=>cal_tag(15 downto 0),
                cal_trig_sel=>cal_tag_trig_num_sel,
                clk=>MASTER_CLK,
                data_sel=>b_data_sel,
                first_in_token_chain=>XLXN_15817,
                pdin(63 downto 0)=>b_data0(63 downto 0),
                pdin_we=>b_data_we0,
                plaq_id(2 downto 0)=>plaq_id0(2 downto 0),
                reset=>psi_tkn_rst,
                token_in=>token(0),
                trig_num(19 downto 0)=>trigger_number(19 downto 0),
                ovf_err=>tx_data(0),
                token_out=>token(1),
                we_out=>we_out0,
                bus_dout(63 downto 0)=>b_data(63 downto 0));
   
   CHIP1_READOUT : PSI_Chip_Readout_Blk
      port map (adc_burst_we=>adc_burst_we,
                adc_data_label(3 downto 0)=>adc_data_label(3 downto 0),
                adc_delayed_clk=>adc_delayed_clk,
                adc_delayed_data=>adc_delayed_data(1),
                adc_sample_we=>adc_sample_we,
                b_data_sel=>b_data_sel,
                MASTER_CLK=>MASTER_CLK,
                PSI_CLK90=>PSI_CLK90,
                psi_debug_sample(1 downto 0)=>psi_debug_sample(1 downto 0),
                PSI_LEVELS_MAP=>PSI_LEVELS_MAP1,
                psi_sample_sel=>psi_sample_sel1,
                psi_token_out=>psi_token_out1,
                reset=>reset,
                rx_addr(4 downto 0)=>rx_addr(4 downto 0),
                rx_data(63 downto 0)=>rx_data(63 downto 0),
                b_data(63 downto 0)=>b_data1(63 downto 0),
                b_data_we=>b_data_pre_we1);
   
   CHIP1_TMGR : chip_token_manager
      port map (cal_tag(15 downto 0)=>cal_tag(15 downto 0),
                cal_trig_sel=>cal_tag_trig_num_sel,
                clk=>MASTER_CLK,
                data_sel=>b_data_sel,
                first_in_token_chain=>XLXN_15818,
                pdin(63 downto 0)=>b_data1(63 downto 0),
                pdin_we=>b_data_we1,
                plaq_id(2 downto 0)=>plaq_id1(2 downto 0),
                reset=>psi_tkn_rst,
                token_in=>token(1),
                trig_num(19 downto 0)=>trigger_number(19 downto 0),
                ovf_err=>tx_data(4),
                token_out=>token(0),
                we_out=>we_out1,
                bus_dout(63 downto 0)=>b_data(63 downto 0));
   
   GEC : gigabit_ethernet_controller
      port map (GMII_RXD(7 downto 0)=>GMII_RXD_0_sig(7 downto 0),
                GMII_RX_CLK=>MASTER_CLK,
                GMII_RX_DV=>GMII_RX_DV_0_sig,
                GMII_RX_ER=>GMII_RX_ER_0_sig,
                reset=>reset,
                user_addrs(7 downto 0)=>gec_user_addrs(7 downto 0),
                user_test_mode=>XLXN_460,
                user_trigger=>gec_user_trigger,
                user_tx_data_in(7 downto 0)=>gec_user_tx_data_in(7 downto 0),
                user_tx_size_in(10 downto 0)=>gec_user_tx_size_in(10 downto 0),
                crc_err=>gec_user_crc_err,
                GMII_TXD(7 downto 0)=>PHY_TXD_sig(7 downto 0),
                GMII_TX_EN=>PHY_TXEN_sig,
                GMII_TX_ER=>PHY_TXER_sig,
                GTX_CLK=>GTX_CLK_0_sig,
                user_busy=>gec_user_busy,
                user_rx_data_out(7 downto 0)=>gec_user_rx_data_out(7 downto 0),
                user_rx_size_out(10 downto 0)=>gec_user_rx_size_out(10 downto 0),
                user_rx_valid_out=>gec_user_rx_valid_out,
                user_tx_enable_out=>gec_user_tx_enable_out);
   
   XLXI_3254 : DCM_ADV
   -- synopsys translate_off
   generic map( CLKFX_MULTIPLY => 16,
            CLKFX_DIVIDE => 27,
            DLL_FREQUENCY_MODE => "LOW",
            DFS_FREQUENCY_MODE => "LOW",
            CLKIN_PERIOD => 8.0,
            CLKOUT_PHASE_SHIFT => "NONE")
   -- synopsys translate_on
      port map (CLKFB=>ADC_DCM_FB,
                CLKIN=>MASTER_CLK,
                DADDR(6 downto 0)=>rx_data(6 downto 0),
                DCLK=>MASTER_CLK,
                DEN=>ADC_CLOCK_MAP,
                DI(15 downto 0)=>rx_data(23 downto 8),
                DWE=>ADC_CLOCK_MAP,
                PSCLK=>XLXN_12188,
                PSEN=>XLXN_12188,
                PSINCDEC=>XLXN_12188,
                RST=>dcm_reset,
                CLKDV=>open,
                CLKFX=>XLXN_15825,
                CLKFX180=>open,
                CLK0=>XLXN_11574,
                CLK2X=>open,
                CLK2X180=>open,
                CLK90=>open,
                CLK180=>open,
                CLK270=>open,
                DO=>open,
                DRDY=>open,
                LOCKED=>open,
                PSDONE=>open);
   
   XLXI_3265 : BUFG
      port map (I=>XLXN_11574,
                O=>ADC_DCM_FB);
   
   XLXI_3301 : FDE
      port map (C=>MASTER_CLK,
                CE=>DCM_PSI_RESET_MAP,
                D=>rx_data(4),
                Q=>psi_reset);
   
   XLXI_3302 : FDE
      port map (C=>MASTER_CLK,
                CE=>DCM_PSI_RESET_MAP,
                D=>rx_data(0),
                Q=>dcm_reset);
   
   XLXI_3360 : INV
      port map (I=>reset_phy,
                O=>XLXN_12023);
   
   XLXI_3399 : BUFG
      port map (I=>XLXN_12172,
                O=>PSI_CLK0);
   
   XLXI_3402 : GND
      port map (G=>XLXN_12188);
   
   XLXI_3405 : IDELAY
   -- synopsys translate_off
   generic map( IOBDELAY_TYPE => "VARIABLE")
   -- synopsys translate_on
      port map (C=>MASTER_CLK,
                CE=>adc_data_del_ce,
                I=>ADC_65MSPS_CH0,
                INC=>rx_data(0),
                RST=>adc_data_del_rst,
                O=>adc_delayed_data(0));
   
   XLXI_3406 : IDELAYCTRL
      port map (REFCLK=>XLXN_15064,
                RST=>reset,
                RDY=>open);
   
   XLXI_3409 : AND2
      port map (I0=>rx_data(4),
                I1=>adc_data_del_ce,
                O=>adc_data_del_rst);
   
   XLXI_3410 : DCM_BASE
   -- synopsys translate_off
   generic map( CLKIN_PERIOD => 8.0,
            CLKFX_MULTIPLY => 8,
            CLKFX_DIVIDE => 5)
   -- synopsys translate_on
      port map (CLKFB=>XLXN_12229,
                CLKIN=>MASTER_CLK,
                RST=>reset,
                CLKDV=>open,
                CLKFX=>XLXN_12257,
                CLKFX180=>open,
                CLK0=>XLXN_12220,
                CLK2X=>open,
                CLK2X180=>open,
                CLK90=>open,
                CLK180=>open,
                CLK270=>open,
                LOCKED=>open);
   
   XLXI_3411 : BUFG
      port map (I=>XLXN_12220,
                O=>XLXN_12229);
   
   XLXI_3420 : IDELAY
   -- synopsys translate_off
   generic map( IOBDELAY_TYPE => "VARIABLE")
   -- synopsys translate_on
      port map (C=>MASTER_CLK,
                CE=>XLXN_12239,
                I=>ADC_FRAME_OUT,
                INC=>rx_data(0),
                RST=>XLXN_12242,
                O=>adc_delayed_frame);
   
   XLXI_3421 : AND2
      port map (I0=>rx_data(4),
                I1=>XLXN_12239,
                O=>XLXN_12242);
   
   XLXI_3423 : IDELAY
   -- synopsys translate_off
   generic map( IOBDELAY_TYPE => "VARIABLE")
   -- synopsys translate_on
      port map (C=>MASTER_CLK,
                CE=>XLXN_12249,
                I=>ADC_CLK_OUT,
                INC=>rx_data(0),
                RST=>XLXN_12252,
                O=>adc_delayed_clk);
   
   XLXI_3424 : AND2
      port map (I0=>rx_data(4),
                I1=>XLXN_12249,
                O=>XLXN_12252);
   
   XLXI_3427 : FDE
      port map (C=>MASTER_CLK,
                CE=>DCM_PSI_RESET_MAP,
                D=>rx_data(1),
                Q=>dcm_reset_psi);
   
   XLXI_3430 : OR3B1
      port map (I0=>reset_button,
                I1=>software_reset,
                I2=>initial_reset,
                O=>reset_start);
   
   XLXI_3432 : D4_16E_MXILINX_TOP_LEVEL
      port map (A0=>rx_addr(8),
                A1=>rx_addr(9),
                A2=>rx_addr(10),
                A3=>rx_addr(11),
                E=>XLXN_12617,
                D0=>MEM_BLK_MAP,
                D1=>ADC_CLOCK_MAP,
                D2=>DCM_PSI_RESET_MAP,
                D3=>PSI_PULSES_MAP,
                D4=>PSI_SEROUT_SEL_MAP,
                D5=>BURST_DATA_SEL_MAP,
                D6=>ADC_DELAY_MAP,
                D7=>GLOBAL_RESET_MAP,
                D8=>ADC_TESTMODE_MAP,
                D9=>PSI_LEVELS_MAP,
                D10=>PSI_SAMPLE_SEL_MAP,
                D11=>PSI_SAMPLE_DEBUG_MAP,
                D12=>PSI_CMD_FIFO_MAP,
                D13=>EN_TRIG_TOK_MAP,
                D14=>DISPLAY_MAP,
                D15=>PSI_CAL_TAG_MAP);
   
   XLXI_3469 : OR2
      port map (I0=>software_reset,
                I1=>initial_reset,
                O=>reset_phy);
   
   XLXI_3479 : FDE
      port map (C=>MASTER_CLK,
                CE=>ADC_TESTMODE_MAP,
                D=>rx_data(0),
                Q=>adc_testmode_sig);
   
   XLXI_3484 : ADC_frame_counter
      port map (ADC_clk=>adc_delayed_clk,
                ADC_frame=>adc_delayed_frame,
                rst_n=>reset_n,
                ADC_en=>adc_burst_we);
   
   XLXI_3497 : CB4RE_MXILINX_TOP_LEVEL
      port map (C=>adc_delayed_clk,
                CE=>adc_burst_we,
                R=>reset,
                CEO=>open,
                Q0=>adc_data_label(0),
                Q1=>adc_data_label(1),
                Q2=>adc_data_label(2),
                Q3=>adc_data_label(3),
                TC=>open);
   
   XLXI_3521 : AND2
      port map (I0=>reset_extension,
                I1=>clock_5mhz,
                O=>XLXN_12503);
   
   XLXI_3522 : OR2
      port map (I0=>XLXN_12503,
                I1=>MASTER_CLK,
                O=>XLXN_12498);
   
   XLXI_3523 : FDRE
      port map (C=>XLXN_12498,
                CE=>GLOBAL_RESET_MAP,
                D=>rx_data(0),
                R=>reset_extension,
                Q=>software_reset);
   
   XLXI_3535 : DATA_MANAGER
      port map (b_data(63 downto 0)=>b_data(63 downto 0),
                b_data_we=>b_data_we,
                b_end_packet=>b_end_packet,
                gec_user_busy=>gec_user_busy,
                gec_user_crc_err=>gec_user_crc_err,
                gec_user_rx_data_out(7 downto 0)=>gec_user_rx_data_out(7 downto 
            0),
                gec_user_rx_size_out(10 downto 0)=>gec_user_rx_size_out(10 
            downto 0),
                gec_user_rx_valid_out=>gec_user_rx_valid_out,
                gec_user_tx_enable_out=>gec_user_tx_enable_out,
                MASTER_CLK=>MASTER_CLK,
                reset=>reset,
                reset_n=>reset_n,
                tx_data(63 downto 0)=>tx_data(63 downto 0),
                b_enable=>b_enable,
                gec_user_trigger=>gec_user_trigger,
                gec_user_tx_data_in(7 downto 0)=>gec_user_tx_data_in(7 downto 0),
                gec_user_tx_size_in(10 downto 0)=>gec_user_tx_size_in(10 downto 
            0),
                ram_addr(63 downto 0)=>rx_addr(63 downto 0),
                ram_wren=>rx_wren,
                rx_data(63 downto 0)=>rx_data(63 downto 0));
   
   XLXI_4004 : DELAY16
      port map (CLOCK_INIT=>clock_5mhz,
                in_sig=>reset_start,
                RESET_INIT=>reset_extension);
   
   XLXI_4005 : OR2
      port map (I0=>reset_start,
                I1=>reset_extension,
                O=>reset);
   
   XLXI_4006 : RESET_INIT
      port map (CLOCK_INIT=>clock_5mhz,
                RESET_INIT=>initial_reset);
   
   XLXI_4007 : INV
      port map (I=>reset,
                O=>reset_n);
   
   XLXI_4037 : VCC
      port map (P=>XLXN_15817);
   
   XLXI_4090 : FDE
      port map (C=>MASTER_CLK,
                CE=>BURST_DATA_SEL_MAP,
                D=>rx_data(0),
                Q=>b_data_sel);
   
   XLXI_4115 : ADC_single_frame_counter
      port map (ADC_clk=>adc_delayed_clk,
                ADC_frame=>adc_delayed_frame,
                rst_n=>reset_n,
                ADC_en=>adc_sample_we);
   
   XLXI_4117 : FDE
      port map (C=>MASTER_CLK,
                CE=>PSI_SAMPLE_DEBUG_MAP,
                D=>rx_data(0),
                Q=>psi_debug_sample(0));
   
   XLXI_4124 : burst_traffic_controller
      port map (BURST_WE=>b_data_we,
                MASTER_CLK=>MASTER_CLK,
                RESET=>reset,
                BURST_END_PACKET=>b_end_packet);
   
   XLXI_4127 : FDE
      port map (C=>MASTER_CLK,
                CE=>PSI_SAMPLE_SEL_MAP,
                D=>rx_data(0),
                Q=>psi_sample_sel0);
   
   XLXI_4135 : IBUFG
      port map (I=>PRIMARY_CLK,
                O=>clock_66mhz);
   
   XLXI_4136 : IBUFG
      port map (I=>SECONDARY_CLK,
                O=>clock_5mhz);
   
   XLXI_4171 : IOBUF
      port map (I=>XLXN_12023,
                T=>XLXN_12023,
                O=>reset_button,
                IO=>BUSC_21DN_43S);
   
   XLXI_4177 : OBUF
      port map (I=>PHY_TXEN_sig,
                O=>BUSC_27DN_55S);
   
   XLXI_4178 : IBUF
      port map (I=>BUSC_27DP_54S,
                O=>GMII_RX_DV_0_sig);
   
   XLXI_4179 : OBUF
      port map (I=>GTX_CLK_0_sig,
                O=>BUSC_26DN_53S);
   
   XLXI_4181 : OBUF
      port map (I=>PHY_TXD_sig(3),
                O=>BUSC_24DP_48S);
   
   XLXI_4182 : OBUF
      port map (I=>PHY_TXD_sig(2),
                O=>BUSC_24DN_49S);
   
   XLXI_4183 : OBUF
      port map (I=>PHY_TXD_sig(1),
                O=>BUSC_25DP_50S);
   
   XLXI_4184 : OBUF
      port map (I=>PHY_TXD_sig(0),
                O=>BUSC_25DN_51S);
   
   XLXI_4213 : IBUF
      port map (I=>BUSC_20DP_40S,
                O=>GMII_RXD_0_sig(7));
   
   XLXI_4214 : IBUF
      port map (I=>BUSC_20DN_41S,
                O=>GMII_RXD_0_sig(6));
   
   XLXI_4216 : IBUF
      port map (I=>BUSC_19DP_38S,
                O=>GMII_RXD_0_sig(5));
   
   XLXI_4217 : IBUF
      port map (I=>BUSC_19DN_39S,
                O=>GMII_RXD_0_sig(4));
   
   XLXI_4218 : IBUF
      port map (I=>BUSC_18DP_36S,
                O=>GMII_RXD_0_sig(3));
   
   XLXI_4219 : IBUF
      port map (I=>BUSC_18DN_37S,
                O=>GMII_RXD_0_sig(2));
   
   XLXI_4220 : IBUF
      port map (I=>BUSC_17DP_34S,
                O=>GMII_RXD_0_sig(1));
   
   XLXI_4221 : IBUF
      port map (I=>BUSC_17DN_35S,
                O=>GMII_RXD_0_sig(0));
   
   XLXI_4246 : OBUF
      port map (I=>PHY_TXER_sig,
                O=>BUSC_16DN_33S);
   
   XLXI_4247 : OBUF
      port map (I=>PHY_TXD_sig(4),
                O=>BUSC_15DN_31S);
   
   XLXI_4248 : IBUF
      port map (I=>BUSC_16DP_32S,
                O=>GMII_RX_ER_0_sig);
   
   XLXI_4249 : OBUF
      port map (I=>PHY_TXD_sig(5),
                O=>BUSC_15DP_30S);
   
   XLXI_4250 : OBUF
      port map (I=>PHY_TXD_sig(6),
                O=>BUSC_14DN_29S);
   
   XLXI_4251 : OBUF
      port map (I=>PHY_TXD_sig(7),
                O=>BUSC_14DP_28S);
   
   XLXI_4253 : IBUFG
      port map (I=>BUSC_26DP_52S,
                O=>MASTER_CLK);
   
   XLXI_4263 : GND
      port map (G=>gec_user_addrs(4));
   
   XLXI_4264 : GND
      port map (G=>gec_user_addrs(5));
   
   XLXI_4265 : GND
      port map (G=>gec_user_addrs(6));
   
   XLXI_4266 : GND
      port map (G=>gec_user_addrs(7));
   
   XLXI_4294 : IBUF
      port map (I=>GENERAL_02DP_04S,
                O=>gec_user_addrs(1));
   
   XLXI_4295 : IBUF
      port map (I=>GENERAL_03DN_07S,
                O=>gec_user_addrs(2));
   
   XLXI_4296 : IBUF
      port map (I=>GENERAL_02DN_05S,
                O=>gec_user_addrs(0));
   
   XLXI_4297 : GND
      port map (G=>XLXN_460);
   
   XLXI_4359 : VERSION_BLK
      port map (version(7 downto 0)=>tx_data(63 downto 56));
   
   XLXI_4464 : AND2
      port map (I0=>rx_data(26),
                I1=>ADC_DELAY_MAP,
                O=>XLXN_12249);
   
   XLXI_4465 : AND2
      port map (I0=>rx_data(25),
                I1=>ADC_DELAY_MAP,
                O=>XLXN_12239);
   
   XLXI_4466 : AND2
      port map (I0=>rx_data(24),
                I1=>ADC_DELAY_MAP,
                O=>adc_data_del_ce);
   
   XLXI_4501 : IBUFDS
   -- synopsys translate_off
   generic map( DIFF_TERM => TRUE)
   -- synopsys translate_on
      port map (I=>BUSAHS_00DP_00S,
                IB=>BUSAHS_00DN_01S,
                O=>ADC_CLK_OUT);
   
   XLXI_4502 : IBUFDS
   -- synopsys translate_off
   generic map( DIFF_TERM => TRUE)
   -- synopsys translate_on
      port map (I=>BUSAHS_01DP_02S,
                IB=>BUSAHS_01DN_03S,
                O=>ADC_FRAME_OUT);
   
   XLXI_4503 : OBUF
      port map (I=>ADC_CLK_IN,
                O=>BUSAHS_02DN_05S);
   
   XLXI_4504 : IBUFDS
   -- synopsys translate_off
   generic map( DIFF_TERM => TRUE)
   -- synopsys translate_on
      port map (I=>BUSA_16DP_32S,
                IB=>BUSA_16DN_33S,
                O=>ADC_65MSPS_CH0);
   
   XLXI_4506 : OBUFDS
      port map (I=>psi_trigger,
                O=>BUSBB_01DP_02S,
                OB=>BUSBB_01DN_03S);
   
   XLXI_4509 : OBUF
      port map (I=>psi_reset,
                O=>BUSBB_02DP_04S);
   
   XLXI_4510 : OBUFDS
      port map (I=>psi_token_in,
                O=>BUSBB_00DP_00S,
                OB=>BUSBB_00DN_01S);
   
   XLXI_4511 : OBUFDS
      port map (I=>psi_data_out0,
                O=>BUSBB_03DP_06S,
                OB=>BUSBB_03DN_07S);
   
   XLXI_4513 : OBUFDS
      port map (I=>PSI_CLK90,
                O=>BUSBB_04DP_08S,
                OB=>BUSBB_04DN_09S);
   
   XLXI_4514 : IBUFDS
   -- synopsys translate_off
   generic map( DIFF_TERM => TRUE)
   -- synopsys translate_on
      port map (I=>BUSBB_05DP_10S,
                IB=>BUSBB_05DN_11S,
                O=>psi_token_out0);
   
   XLXI_4521 : OBUF
      port map (I=>adc_testmode_sig,
                O=>GENERAL_03DP_06S);
   
   XLXI_4529 : BUFG
      port map (I=>XLXN_12257,
                O=>XLXN_15064);
   
   XLXI_4530 : FDE
      port map (C=>MASTER_CLK,
                CE=>PSI_SAMPLE_DEBUG_MAP,
                D=>rx_data(4),
                Q=>psi_debug_sample(1));
   
   XLXI_4536 : psi_command_sender
      port map (data(31 downto 0)=>XLXN_15543(31 downto 0),
                fifo_empty=>psi_cmd_fifo_empty,
                fifo_full=>psi_cmd_fifo_full,
                psi_clk=>PSI_CLK0,
                reset=>reset,
                data_error=>tx_data(32),
                data_out=>psi_data_out,
                fifo_re=>psi_cmd_fifo_re,
                we_error=>tx_data(36));
   
   XLXI_4544 : BUFG
      port map (I=>XLXN_15111,
                O=>PSI_CLK90);
   
   XLXI_4556 : psi_cmd_fifo32
      port map (din(31 downto 0)=>rx_data(31 downto 0),
                rd_clk=>PSI_CLK0,
                rd_en=>psi_cmd_fifo_re,
                rst=>reset,
                wr_clk=>MASTER_CLK,
                wr_en=>PSI_CMD_FIFO_MAP,
                dout(31 downto 0)=>XLXN_15543(31 downto 0),
                empty=>psi_cmd_fifo_empty,
                full=>psi_cmd_fifo_full);
   
   XLXI_4557 : token_trigger_controller
      port map (ext_trigger=>psi_extdom_trig,
                inject_trig_gap(7 downto 0)=>rx_data(23 downto 16),
                is_ext_mode=>rx_data(48),
                master_clk=>MASTER_CLK,
                num_of_triggers(7 downto 0)=>rx_data(47 downto 40),
                param_we=>PSI_PULSES_MAP,
                psi_clk=>PSI_CLK90,
                rst=>trig_reset,
                sw_en_pulse=>sw_en_pulse,
                trig_repetition_per(15 downto 0)=>rx_data(15 downto 0),
                trig_token_gap(15 downto 0)=>rx_data(39 downto 24),
                use_cal_inject=>rx_data(56),
                error=>tx_data(40),
                token=>psi_token_in,
                trigger=>psi_trigger);
   
   XLXI_4559 : display_fifo
      port map (din(7 downto 0)=>rx_data(7 downto 0),
                rd_clk=>clock_5mhz,
                rd_en=>XLXN_15149,
                rst=>reset,
                wr_clk=>MASTER_CLK,
                wr_en=>DISPLAY_MAP,
                dout(0)=>display_ser_data,
                empty=>XLXN_15146,
                full=>open);
   
   XLXI_4560 : INV
      port map (I=>XLXN_15146,
                O=>XLXN_15149);
   
   XLXI_4561 : FD
      port map (C=>clock_5mhz,
                D=>XLXN_15146,
                Q=>display_load_bar);
   
   XLXI_4568 : OBUF
      port map (I=>display_ser_data,
                O=>INTERNAL_05DP_10S);
   
   XLXI_4569 : OBUF
      port map (I=>display_load_bar,
                O=>INTERNAL_04DN_09S);
   
   XLXI_4570 : OBUF
      port map (I=>XLXN_15151,
                O=>INTERNAL_05DN_11S);
   
   XLXI_4571 : INV
      port map (I=>clock_5mhz,
                O=>XLXN_15151);
   
   XLXI_4572 : AND2
      port map (I0=>rx_data(0),
                I1=>EN_TRIG_TOK_MAP,
                O=>sw_en_pulse);
   
   XLXI_4576 : OR2
      port map (I0=>reset,
                I1=>sw_trig_reset,
                O=>trig_reset);
   
   XLXI_4592 : FDRE
      port map (C=>MASTER_CLK,
                CE=>EN_TRIG_TOK_MAP,
                D=>rx_data(4),
                R=>reset,
                Q=>sw_trig_reset);
   
   XLXI_4595 : FD16RE_MXILINX_TOP_LEVEL
      port map (C=>MASTER_CLK,
                CE=>PSI_CAL_TAG_MAP,
                D(15 downto 0)=>rx_data(15 downto 0),
                R=>reset,
                Q(15 downto 0)=>cal_tag(15 downto 0));
   
   XLXI_4615 : DCM_BASE
   -- synopsys translate_off
   generic map( CLKIN_PERIOD => 74.0,
            CLKFX_MULTIPLY => 4,
            CLKFX_DIVIDE => 4,
            DCM_PERFORMANCE_MODE => "MAX_RANGE",
            CLKIN_DIVIDE_BY_2 => FALSE)
   -- synopsys translate_on
      port map (CLKFB=>PSI_CLK0,
                CLKIN=>XLXN_15824,
                RST=>dcm_reset_psi,
                CLKDV=>open,
                CLKFX=>open,
                CLKFX180=>open,
                CLK0=>XLXN_12172,
                CLK2X=>ADC_CLK_IN,
                CLK2X180=>open,
                CLK90=>XLXN_15111,
                CLK180=>open,
                CLK270=>open,
                LOCKED=>open);
   
   XLXI_4618 : GND
      port map (G=>open);
   
   XLXI_4619 : GND
      port map (G=>open);
   
   XLXI_4620 : GND
      port map (G=>gec_user_addrs(3));
   
   XLXI_4621 : VCC
      port map (P=>open);
   
   XLXI_4648 : IDELAY
   -- synopsys translate_off
   generic map( IOBDELAY_TYPE => "VARIABLE")
   -- synopsys translate_on
      port map (C=>MASTER_CLK,
                CE=>XLXN_15849,
                I=>ADC_65MSPS_CH1,
                INC=>rx_data(0),
                RST=>XLXN_15850,
                O=>adc_delayed_data(1));
   
   XLXI_4660 : PLAQ_ID_GEN
      port map (plaq_id0(2 downto 0)=>plaq_id0(2 downto 0),
                plaq_id1(2 downto 0)=>plaq_id1(2 downto 0));
   
   XLXI_4666 : OR2
      port map (I0=>we_out1,
                I1=>we_out0,
                O=>b_data_we);
   
   XLXI_4670 : IBUFDS
   -- synopsys translate_off
   generic map( DIFF_TERM => TRUE)
   -- synopsys translate_on
      port map (I=>BUSA_17DP_34S,
                IB=>BUSA_17DN_35S,
                O=>ADC_65MSPS_CH1);
   
   XLXI_4677 : D4_16E_MXILINX_TOP_LEVEL
      port map (A0=>rx_addr(8),
                A1=>rx_addr(9),
                A2=>rx_addr(10),
                A3=>rx_addr(11),
                E=>XLXN_15755,
                D0=>ADC_CLK_SEL_MAP,
                D1=>CHAN1_SPEC_DEL_MAP,
                D2=>RESET_TRIG_NUM_MAP,
                D3=>open,
                D4=>open,
                D5=>open,
                D6=>open,
                D7=>open,
                D8=>open,
                D9=>open,
                D10=>open,
                D11=>open,
                D12=>open,
                D13=>open,
                D14=>open,
                D15=>open);
   
   XLXI_4696 : AND2
      port map (I0=>rx_addr(12),
                I1=>rx_wren,
                O=>XLXN_15755);
   
   XLXI_4697 : AND2B1
      port map (I0=>rx_addr(12),
                I1=>rx_wren,
                O=>XLXN_12617);
   
   XLXI_4704 : FDE
      port map (C=>MASTER_CLK,
                CE=>PSI_SEROUT_SEL_MAP,
                D=>rx_data(0),
                Q=>psi_data_out_sel);
   
   XLXI_4710 : GND
      port map (G=>XLXN_15818);
   
   XLXI_4713 : AND2
      port map (I0=>psi_data_out_sel,
                I1=>psi_data_out,
                O=>psi_data_out1);
   
   XLXI_4714 : AND2B1
      port map (I0=>psi_data_out_sel,
                I1=>psi_data_out,
                O=>psi_data_out0);
   
   XLXI_4715 : IBUFDS
   -- synopsys translate_off
   generic map( DIFF_TERM => TRUE)
   -- synopsys translate_on
      port map (I=>BUSD_23DP_46S,
                IB=>BUSD_23DN_47S,
                O=>psi_token_out1);
   
   XLXI_4716 : OBUFDS
      port map (I=>PSI_CLK90,
                O=>BUSD_22DP_44S,
                OB=>BUSD_22DN_45S);
   
   XLXI_4717 : OBUFDS
      port map (I=>psi_data_out1,
                O=>BUSD_21DP_42S,
                OB=>BUSD_21DN_43S);
   
   XLXI_4718 : OBUFDS
      port map (I=>psi_token_in,
                O=>BUSD_19DP_38S,
                OB=>BUSD_19DN_39S);
   
   XLXI_4719 : OBUF
      port map (I=>psi_reset,
                O=>GENERAL_05DN_11S);
   
   XLXI_4720 : OBUFDS
      port map (I=>psi_trigger,
                O=>BUSD_20DP_40S,
                OB=>BUSD_20DN_41S);
   
   XLXI_4738 : OR2B1
      port map (I0=>psi_reset,
                I1=>reset,
                O=>psi_tkn_rst);
   
   XLXI_4744 : AND2
      port map (I0=>psi_data_out_sel,
                I1=>PSI_LEVELS_MAP,
                O=>PSI_LEVELS_MAP1);
   
   XLXI_4745 : AND2B1
      port map (I0=>psi_data_out_sel,
                I1=>PSI_LEVELS_MAP,
                O=>PSI_LEVELS_MAP0);
   
   XLXI_4746 : plaq_enable_blk
      port map (b_data_sel=>b_data_sel,
                debug_sel(1 downto 0)=>psi_debug_sample(1 downto 0),
                pre_we0=>b_data_pre_we0,
                pre_we1=>b_data_pre_we1,
                psi_data_out_sel=>psi_data_out_sel,
                we0=>b_data_we0,
                we1=>b_data_we1);
   
   XLXI_4753 : FDE
      port map (C=>MASTER_CLK,
                CE=>PSI_SAMPLE_SEL_MAP,
                D=>rx_data(4),
                Q=>psi_sample_sel1);
   
   XLXI_4771 : External_Trigger_Handler
      port map (ext_clk=>EXT_CLK,
                ext_trigger=>EXT_TRIGG,
                master_clk=>MASTER_CLK,
                psi_clk=>PSI_CLK90,
                psi_trigger=>psi_trigger,
                reset=>reset,
                reset_trig_counter=>reset_trig_counter,
                psi_trig=>psi_extdom_trig,
                trig_num(19 downto 0)=>trigger_number(19 downto 0));
   
   XLXI_4773 : M2_1_MXILINX_TOP_LEVEL
      port map (D0=>INT_HALF_CLK,
                D1=>EXT_CLK,
                S0=>adc_clk_sel,
                O=>XLXN_15824);
   
   XLXI_4776 : FDE
      port map (C=>MASTER_CLK,
                CE=>ADC_CLK_SEL_MAP,
                D=>rx_data(0),
                Q=>adc_clk_sel);
   
   XLXI_4781 : FDE
      port map (C=>MASTER_CLK,
                CE=>PSI_CAL_TAG_MAP,
                D=>rx_data(16),
                Q=>cal_tag_trig_num_sel);
   
   XLXI_4791 : FTC_MXILINX_TOP_LEVEL
      port map (C=>XLXN_15825,
                CLR=>XLXN_15845,
                T=>XLXN_15844,
                Q=>INT_HALF_CLK);
   
   XLXI_4792 : VCC
      port map (P=>XLXN_15844);
   
   XLXI_4793 : GND
      port map (G=>XLXN_15845);
   
   XLXI_4794 : IBUFDS
   -- synopsys translate_off
   generic map( DIFF_TERM => TRUE)
   -- synopsys translate_on
      port map (I=>BUSA_12DP_24S,
                IB=>BUSA_12DN_25S,
                O=>EXT_TRIGG);
   
   XLXI_4795 : IBUFDS
   -- synopsys translate_off
   generic map( DIFF_TERM => TRUE)
   -- synopsys translate_on
      port map (I=>BUSA_14DP_28S,
                IB=>BUSA_14DN_29S,
                O=>EXT_CLK);
   
   XLXI_4796 : OR2
      port map (I0=>adc_data_del_ce_ch1,
                I1=>adc_data_del_ce,
                O=>XLXN_15849);
   
   XLXI_4797 : OR2
      port map (I0=>adc_data_del_rst_ch1,
                I1=>adc_data_del_rst,
                O=>XLXN_15850);
   
   XLXI_4801 : AND2
      port map (I0=>rx_data(4),
                I1=>adc_data_del_ce_ch1,
                O=>adc_data_del_rst_ch1);
   
   XLXI_4802 : AND2
      port map (I0=>rx_data(24),
                I1=>CHAN1_SPEC_DEL_MAP,
                O=>adc_data_del_ce_ch1);
   
   XLXI_4834 : FDE
      port map (C=>MASTER_CLK,
                CE=>RESET_TRIG_NUM_MAP,
                D=>rx_data(0),
                Q=>reset_trig_counter);
   
end BEHAVIORAL;


