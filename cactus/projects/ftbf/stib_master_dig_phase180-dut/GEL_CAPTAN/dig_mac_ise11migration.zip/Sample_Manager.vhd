-------------------------------------------------------------------------------
--
-- Title       : Sample_Manager
-- Design      : PsiDecoder
-- Author      : Desktop Support
-- Company     : FNAL
--
-------------------------------------------------------------------------------
--
-- File        : c:\My_Designs\PsiDecoder\PsiDecoder\src\Sample_Manager.vhd
-- Generated   : Mon Feb 16 11:53:11 2009
-- From        : interface description file
-- By          : Itf2Vhdl ver. 1.20
--
-------------------------------------------------------------------------------
--
-- Description : 
--
-------------------------------------------------------------------------------

use PsiDecoderParameters.all;

--{{ Section below this comment is automatically maintained
--   and may be overwritten
--{entity {Sample_Manager} architecture {Sample_Manager}}

library IEEE;
use IEEE.STD_LOGIC_1164.all;


entity Sample_Manager is
	 port(
		 ADC_DATA_IN : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
		 ADC_WR_EN : in STD_LOGIC;
		 MASTER_CLOCK : in STD_LOGIC;
		 SAMPLE_SEL : in STD_LOGIC;	 
		 managed_data : out STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
		 wr_en : out STD_LOGIC
	     );
end Sample_Manager;

--}} End of automatically maintained section

architecture Sample_Manager of Sample_Manager is
	signal data_label : std_logic := '0'; 
begin
	process( MASTER_CLOCK )
	begin
		if rising_edge(MASTER_CLOCK) then	 
			
			wr_en <= '0';
	
			if ADC_WR_EN = '1' then
				data_label <= not data_label;
				if data_label = SAMPLE_SEL then
					managed_data <= ADC_DATA_IN;
					wr_en <= '1';
				end if ;
			end if;						
		end if;
	end process;
	
end Sample_Manager;
