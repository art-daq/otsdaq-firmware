VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "virtex4"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL adc_delayed_clk
        SIGNAL XLXN_12534
        SIGNAL XLXN_12535
        SIGNAL XLXN_12536
        SIGNAL XLXN_12537
        SIGNAL XLXN_12538
        SIGNAL XLXN_12539
        SIGNAL XLXN_12540
        SIGNAL XLXN_12541
        SIGNAL adc_raw_data(71:60)
        SIGNAL adc_raw_data(59:48)
        SIGNAL adc_raw_data(47:36)
        SIGNAL adc_raw_data(35:24)
        SIGNAL adc_raw_data(23:12)
        SIGNAL adc_delayed_data
        SIGNAL XLXN_14590
        SIGNAL XLXN_14591
        SIGNAL XLXN_14594
        SIGNAL XLXN_14595
        SIGNAL b_data_we1
        SIGNAL reset
        SIGNAL rx_addr(4:0)
        SIGNAL MASTER_CLK
        SIGNAL psi_sample_sel
        SIGNAL psi_sample_we
        SIGNAL psi_debug_sample(1:0)
        SIGNAL PSI_LEVELS_MAP
        SIGNAL PSI_CLK90
        SIGNAL psi_token_out
        SIGNAL b_data_sel
        SIGNAL b_data0(63:0)
        SIGNAL b_data_we0
        SIGNAL adc_data_label(3:0)
        SIGNAL adc_burst_data(63:0)
        SIGNAL XLXN_12570
        SIGNAL adc_fifo_readen
        SIGNAL adc_sample_fifo_re
        SIGNAL psi_sample(11:0)
        SIGNAL adc_raw_data(69:58)
        SIGNAL XLXN_14592
        SIGNAL rx_data(63:0)
        SIGNAL b_data_we
        SIGNAL b_data(63:0)
        SIGNAL adc_sample_we
        SIGNAL adc_burst_we
        SIGNAL b_data1(28:0)
        SIGNAL rx_data(19:10)
        SIGNAL rx_data(29:20)
        SIGNAL rx_data(39:30)
        SIGNAL rx_data(49:40)
        SIGNAL rx_data(59:50)
        SIGNAL rx_data(9:0)
        SIGNAL psi_sample(11:2)
        SIGNAL XLXN_15154
        SIGNAL b_data1(63:0)
        SIGNAL adc_raw_data(11:0)
        SIGNAL adc_raw_data(71:0)
        SIGNAL adc_raw_data(69:10)
        PORT Input adc_delayed_clk
        PORT Input adc_delayed_data
        PORT Input reset
        PORT Input rx_addr(4:0)
        PORT Input MASTER_CLK
        PORT Input psi_sample_sel
        PORT Input psi_debug_sample(1:0)
        PORT Input PSI_LEVELS_MAP
        PORT Input PSI_CLK90
        PORT Input psi_token_out
        PORT Input b_data_sel
        PORT Input adc_data_label(3:0)
        PORT Input rx_data(63:0)
        PORT Output b_data_we
        PORT Output b_data(63:0)
        PORT Input adc_sample_we
        PORT Input adc_burst_we
        BEGIN BLOCKDEF ADC_block_2
            TIMESTAMP 2008 11 6 23 11 12
            LINE N 64 -160 0 -160 
            RECTANGLE N 64 -192 320 128 
            LINE N 64 32 0 32 
            LINE N 64 96 0 96 
            LINE N 320 32 384 32 
            LINE N 320 96 384 96 
            RECTANGLE N 320 -76 384 -52 
            LINE N 320 -64 384 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF buf
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 224 -32 128 -32 
            LINE N 64 0 128 -32 
            LINE N 128 -32 64 -64 
            LINE N 64 -64 64 0 
        END BLOCKDEF
        BEGIN BLOCKDEF PsiDecoderBlock
            TIMESTAMP 2009 3 23 15 32 8
            LINE N 64 -864 0 -864 
            LINE N 64 -800 0 -800 
            LINE N 64 -736 0 -736 
            LINE N 64 -672 0 -672 
            LINE N 64 -608 0 -608 
            LINE N 64 -544 0 -544 
            RECTANGLE N 0 -492 64 -468 
            LINE N 64 -480 0 -480 
            RECTANGLE N 0 -428 64 -404 
            LINE N 64 -416 0 -416 
            RECTANGLE N 0 -364 64 -340 
            LINE N 64 -352 0 -352 
            RECTANGLE N 0 -300 64 -276 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            LINE N 512 -928 576 -928 
            RECTANGLE N 512 -44 576 -20 
            LINE N 512 -32 576 -32 
            RECTANGLE N 64 -960 512 60 
            RECTANGLE N 0 20 64 44 
            LINE N 64 32 0 32 
        END BLOCKDEF
        BEGIN BLOCKDEF psi_token_delay_blk
            TIMESTAMP 2009 4 21 20 22 37
            RECTANGLE N 64 -128 320 0 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            LINE N 320 -96 384 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF MUX64_2
            TIMESTAMP 2008 6 18 18 43 41
            RECTANGLE N 64 -192 320 0 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -172 384 -148 
            LINE N 320 -160 384 -160 
        END BLOCKDEF
        BEGIN BLOCKDEF m2_1
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 96 -64 96 -192 
            LINE N 256 -96 96 -64 
            LINE N 256 -160 256 -96 
            LINE N 96 -192 256 -160 
            LINE N 176 -32 96 -32 
            LINE N 176 -80 176 -32 
            LINE N 0 -32 96 -32 
            LINE N 320 -128 256 -128 
            LINE N 0 -96 96 -96 
            LINE N 0 -160 96 -160 
        END BLOCKDEF
        BEGIN BLOCKDEF adc_burst_data_splicer
            TIMESTAMP 2009 3 11 19 57 24
            RECTANGLE N 64 -128 320 0 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -108 384 -84 
            LINE N 320 -96 384 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF burst_test_fifo64
            TIMESTAMP 2008 11 7 21 27 55
            RECTANGLE N 64 -384 320 0 
            LINE N 64 -352 0 -352 
            LINE N 64 -288 0 -288 
            LINE N 64 -224 0 -224 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            LINE N 320 -352 384 -352 
            LINE N 320 -192 384 -192 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF inv
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 224 -32 160 -32 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            CIRCLE N 128 -48 160 -16 
        END BLOCKDEF
        BEGIN BLOCKDEF fd
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -320 320 -64 
            LINE N 0 -128 64 -128 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF adc_sample_fifo12
            TIMESTAMP 2009 3 11 20 14 40
            RECTANGLE N 64 -384 320 0 
            LINE N 64 -352 0 -352 
            LINE N 64 -288 0 -288 
            LINE N 64 -224 0 -224 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            LINE N 320 -352 384 -352 
            LINE N 320 -192 384 -192 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCK XLXI_3493 ADC_block_2
            PIN DCK adc_delayed_clk
            PIN D0_IN XLXN_12534
            PIN D1_IN XLXN_12535
            PIN D0 XLXN_12536
            PIN D1 XLXN_12537
            PIN DOUT(11:0) adc_raw_data(59:48)
        END BLOCK
        BEGIN BLOCK XLXI_3494 ADC_block_2
            PIN DCK adc_delayed_clk
            PIN D0_IN XLXN_12536
            PIN D1_IN XLXN_12537
            PIN D0 XLXN_12538
            PIN D1 XLXN_12539
            PIN DOUT(11:0) adc_raw_data(47:36)
        END BLOCK
        BEGIN BLOCK XLXI_3495 ADC_block_2
            PIN DCK adc_delayed_clk
            PIN D0_IN XLXN_12538
            PIN D1_IN XLXN_12539
            PIN D0 XLXN_12540
            PIN D1 XLXN_12541
            PIN DOUT(11:0) adc_raw_data(35:24)
        END BLOCK
        BEGIN BLOCK XLXI_3496 ADC_block_2
            PIN DCK adc_delayed_clk
            PIN D0_IN XLXN_12540
            PIN D1_IN XLXN_12541
            PIN D0 XLXN_14590
            PIN D1 XLXN_14591
            PIN DOUT(11:0) adc_raw_data(23:12)
        END BLOCK
        BEGIN BLOCK XLXI_86 buf
            PIN I adc_delayed_data
            PIN O XLXN_14595
        END BLOCK
        BEGIN BLOCK XLXI_85 buf
            PIN I adc_delayed_data
            PIN O XLXN_14594
        END BLOCK
        BEGIN BLOCK XLXI_3483 ADC_block_2
            PIN DCK adc_delayed_clk
            PIN D0_IN XLXN_14594
            PIN D1_IN XLXN_14595
            PIN D0 XLXN_12534
            PIN D1 XLXN_12535
            PIN DOUT(11:0) adc_raw_data(71:60)
        END BLOCK
        BEGIN BLOCK XLXI_3499 burst_test_fifo64
            PIN rd_clk MASTER_CLK
            PIN rd_en adc_fifo_readen
            PIN rst reset
            PIN wr_clk adc_delayed_clk
            PIN wr_en adc_burst_we
            PIN din(63:0) adc_burst_data(63:0)
            PIN empty XLXN_12570
            PIN full
            PIN dout(63:0) b_data0(63:0)
        END BLOCK
        BEGIN BLOCK XLXI_3503 inv
            PIN I XLXN_12570
            PIN O adc_fifo_readen
        END BLOCK
        BEGIN BLOCK XLXI_3504 fd
            PIN C MASTER_CLK
            PIN D adc_fifo_readen
            PIN Q b_data_we0
        END BLOCK
        BEGIN BLOCK XLXI_4112 inv
            PIN I XLXN_14592
            PIN O adc_sample_fifo_re
        END BLOCK
        BEGIN BLOCK XLXI_4113 fd
            PIN C MASTER_CLK
            PIN D adc_sample_fifo_re
            PIN Q psi_sample_we
        END BLOCK
        BEGIN BLOCK XLXI_4116 adc_sample_fifo12
            PIN rd_clk MASTER_CLK
            PIN rd_en adc_sample_fifo_re
            PIN rst reset
            PIN wr_clk adc_delayed_clk
            PIN wr_en adc_sample_we
            PIN din(11:0) adc_raw_data(69:58)
            PIN empty XLXN_14592
            PIN full
            PIN dout(11:0) psi_sample(11:0)
        END BLOCK
        BEGIN BLOCK XLXI_4093 PsiDecoderBlock
            PIN ADC_WR_EN psi_sample_we
            PIN MASTER_CLOCK MASTER_CLK
            PIN RESET reset
            PIN SAMPLE_SEL psi_sample_sel
            PIN TOKEN_OUT XLXN_15154
            PIN WR_EN_MEM PSI_LEVELS_MAP
            PIN ADC_DATA_IN(9:0) psi_sample(11:2)
            PIN CHIP_ID_WR(4:0) rx_addr(4:0)
            PIN LEVEL0(9:0) rx_data(19:10)
            PIN LEVEL1(9:0) rx_data(29:20)
            PIN LEVEL2(9:0) rx_data(39:30)
            PIN LEVEL3(9:0) rx_data(49:40)
            PIN LEVEL4(9:0) rx_data(59:50)
            PIN ULTRABLACK(9:0) rx_data(9:0)
            PIN DATA_OUT_WR b_data_we1
            PIN DATA_OUT(28:0) b_data1(28:0)
            PIN DEBUG_SEL(1:0) psi_debug_sample(1:0)
        END BLOCK
        BEGIN BLOCK XLXI_4617 psi_token_delay_blk
            PIN clk PSI_CLK90
            PIN token psi_token_out
            PIN token_delay XLXN_15154
        END BLOCK
        BEGIN BLOCK XLXI_4088 MUX64_2
            PIN sel b_data_sel
            PIN in0(63:0) b_data0(63:0)
            PIN in1(63:0) b_data1(63:0)
            PIN muxout(63:0) b_data(63:0)
        END BLOCK
        BEGIN BLOCK XLXI_4089 m2_1
            PIN D0 b_data_we0
            PIN D1 b_data_we1
            PIN S0 b_data_sel
            PIN O b_data_we
        END BLOCK
        BEGIN BLOCK XLXI_4119 ADC_block_2
            PIN DCK adc_delayed_clk
            PIN D0_IN XLXN_14590
            PIN D1_IN XLXN_14591
            PIN D0
            PIN D1
            PIN DOUT(11:0) adc_raw_data(11:0)
        END BLOCK
        BEGIN BLOCK XLXI_4097 adc_burst_data_splicer
            PIN adc_data(59:0) adc_raw_data(69:10)
            PIN data_label(3:0) adc_data_label(3:0)
            PIN dout(63:0) adc_burst_data(63:0)
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 7040 5440
        BEGIN BRANCH adc_delayed_clk
            WIRE 1696 4816 1872 4816
            WIRE 1872 4816 1984 4816
            WIRE 1872 4704 1872 4816
            WIRE 1872 4704 2432 4704
            WIRE 2432 4704 2432 4816
            WIRE 2432 4816 2528 4816
            WIRE 2432 4704 2976 4704
            WIRE 2976 4704 2976 4816
            WIRE 2976 4816 3040 4816
            WIRE 2976 4704 3488 4704
            WIRE 3488 4704 3488 4816
            WIRE 3488 4816 3536 4816
            WIRE 3488 4704 3984 4704
            WIRE 3984 4704 3984 4816
            WIRE 3984 4816 4032 4816
            WIRE 3984 4704 4480 4704
            WIRE 4480 4704 4480 4816
            WIRE 4480 4816 4528 4816
            BEGIN DISPLAY 1696 4816 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_3493 2528 4976 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_3494 3040 4976 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_3495 3536 4976 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_3496 4032 4976 R0
        END INSTANCE
        BEGIN BRANCH XLXN_12534
            WIRE 2368 5008 2528 5008
        END BRANCH
        BEGIN BRANCH XLXN_12535
            WIRE 2368 5072 2528 5072
        END BRANCH
        BEGIN BRANCH XLXN_12536
            WIRE 2912 5008 3040 5008
        END BRANCH
        BEGIN BRANCH XLXN_12537
            WIRE 2912 5072 3040 5072
        END BRANCH
        BEGIN BRANCH XLXN_12538
            WIRE 3424 5008 3536 5008
        END BRANCH
        BEGIN BRANCH XLXN_12539
            WIRE 3424 5072 3536 5072
        END BRANCH
        BEGIN BRANCH XLXN_12540
            WIRE 3920 5008 4032 5008
        END BRANCH
        BEGIN BRANCH XLXN_12541
            WIRE 3920 5072 4032 5072
        END BRANCH
        BEGIN BRANCH adc_raw_data(71:60)
            WIRE 2368 4912 2480 4912
            BEGIN DISPLAY 2480 4912 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_raw_data(59:48)
            WIRE 2912 4912 3008 4912
            BEGIN DISPLAY 3008 4912 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_raw_data(47:36)
            WIRE 3424 4912 3520 4912
            BEGIN DISPLAY 3520 4912 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_raw_data(35:24)
            WIRE 3920 4912 4016 4912
            BEGIN DISPLAY 4016 4912 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_raw_data(23:12)
            WIRE 4416 4912 4512 4912
            BEGIN DISPLAY 4512 4912 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_86 1504 5104 R0
        INSTANCE XLXI_85 1504 5040 R0
        BEGIN BRANCH adc_delayed_data
            WIRE 1408 5008 1440 5008
            WIRE 1440 5008 1504 5008
            WIRE 1440 5008 1440 5072
            WIRE 1440 5072 1504 5072
            BEGIN DISPLAY 1408 5008 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_3483 1984 4976 R0
        END INSTANCE
        BEGIN BRANCH XLXN_14590
            WIRE 4416 5008 4432 5008
            WIRE 4432 5008 4528 5008
        END BRANCH
        BEGIN BRANCH XLXN_14591
            WIRE 4416 5072 4432 5072
            WIRE 4432 5072 4528 5072
        END BRANCH
        BEGIN BRANCH XLXN_14594
            WIRE 1728 5008 1984 5008
        END BRANCH
        BEGIN BRANCH XLXN_14595
            WIRE 1728 5072 1984 5072
        END BRANCH
        BEGIN INSTANCE XLXI_3499 1728 4304 R0
        END INSTANCE
        BEGIN BRANCH adc_delayed_clk
            WIRE 1600 4144 1728 4144
            BEGIN DISPLAY 1600 4144 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 1568 4080 1728 4080
            BEGIN DISPLAY 1568 4080 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 1504 3952 1552 3952
            WIRE 1552 3952 1728 3952
            WIRE 1552 3856 1552 3952
            WIRE 1552 3856 2176 3856
            WIRE 2176 3856 2176 4224
            WIRE 2176 4224 2640 4224
            BEGIN DISPLAY 1504 3952 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_12570
            WIRE 2112 3952 2304 3952
        END BRANCH
        INSTANCE XLXI_3503 2304 3984 R0
        BEGIN BRANCH adc_fifo_readen
            WIRE 1664 3808 2592 3808
            WIRE 2592 3808 2592 3952
            WIRE 2592 3952 2592 4096
            WIRE 2592 4096 2640 4096
            WIRE 1664 3808 1664 4016
            WIRE 1664 4016 1728 4016
            WIRE 2528 3952 2592 3952
            BEGIN DISPLAY 2592 3952 ATTR Name
                ALIGNMENT SOFT-TVCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_we0
            WIRE 3024 4096 3072 4096
            BEGIN DISPLAY 3072 4096 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data0(63:0)
            WIRE 2112 4272 2320 4272
            BEGIN DISPLAY 2320 4272 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3504 2640 4352 R0
        BEGIN BRANCH adc_burst_data(63:0)
            WIRE 1584 4272 1728 4272
            BEGIN DISPLAY 1584 4272 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_delayed_clk
            WIRE 1520 3296 1648 3296
            BEGIN DISPLAY 1520 3296 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 1488 3232 1648 3232
            BEGIN DISPLAY 1488 3232 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 1424 3104 1472 3104
            WIRE 1472 3104 1648 3104
            WIRE 1472 3008 1472 3104
            WIRE 1472 3008 2096 3008
            WIRE 2096 3008 2096 3376
            WIRE 2096 3376 2560 3376
            BEGIN DISPLAY 1424 3104 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4112 2224 3136 R0
        BEGIN BRANCH adc_sample_fifo_re
            WIRE 1584 2960 2512 2960
            WIRE 2512 2960 2512 3104
            WIRE 2512 3104 2512 3248
            WIRE 2512 3248 2560 3248
            WIRE 1584 2960 1584 3168
            WIRE 1584 3168 1648 3168
            WIRE 2448 3104 2512 3104
            BEGIN DISPLAY 2512 3104 ATTR Name
                ALIGNMENT SOFT-TVCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_sample_we
            WIRE 2944 3248 2992 3248
            BEGIN DISPLAY 2992 3248 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_sample(11:0)
            WIRE 2032 3424 2240 3424
            BEGIN DISPLAY 2240 3424 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_4113 2560 3504 R0
        BEGIN BRANCH adc_raw_data(69:58)
            WIRE 1552 3424 1648 3424
            BEGIN DISPLAY 1552 3424 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4116 1648 3456 R0
        END INSTANCE
        BEGIN BRANCH XLXN_14592
            WIRE 2032 3104 2224 3104
        END BRANCH
        BEGIN BRANCH psi_token_out
            WIRE 848 256 992 256
        END BRANCH
        IOMARKER 848 256 psi_token_out R180 28
        BEGIN BRANCH MASTER_CLK
            WIRE 848 304 992 304
        END BRANCH
        IOMARKER 848 304 MASTER_CLK R180 28
        BEGIN BRANCH PSI_CLK90
            WIRE 848 352 992 352
        END BRANCH
        IOMARKER 848 352 PSI_CLK90 R180 28
        BEGIN BRANCH reset
            WIRE 848 400 992 400
        END BRANCH
        IOMARKER 848 400 reset R180 28
        BEGIN BRANCH rx_data(63:0)
            WIRE 848 448 992 448
        END BRANCH
        IOMARKER 848 448 rx_data(63:0) R180 28
        BEGIN BRANCH PSI_LEVELS_MAP
            WIRE 848 496 992 496
        END BRANCH
        IOMARKER 848 496 PSI_LEVELS_MAP R180 28
        BEGIN BRANCH psi_sample_sel
            WIRE 848 544 992 544
        END BRANCH
        IOMARKER 848 544 psi_sample_sel R180 28
        BEGIN BRANCH adc_delayed_clk
            WIRE 848 592 992 592
        END BRANCH
        IOMARKER 848 592 adc_delayed_clk R180 28
        BEGIN BRANCH adc_delayed_data
            WIRE 848 640 992 640
        END BRANCH
        IOMARKER 848 640 adc_delayed_data R180 28
        BEGIN BRANCH adc_data_label(3:0)
            WIRE 848 688 992 688
        END BRANCH
        IOMARKER 848 688 adc_data_label(3:0) R180 28
        BEGIN BRANCH b_data_we
            WIRE 6128 304 6272 304
        END BRANCH
        IOMARKER 6272 304 b_data_we R0 28
        BEGIN BRANCH b_data(63:0)
            WIRE 6128 352 6272 352
        END BRANCH
        IOMARKER 6272 352 b_data(63:0) R0 28
        BEGIN BRANCH psi_debug_sample(1:0)
            WIRE 848 736 992 736
        END BRANCH
        BEGIN BRANCH rx_addr(4:0)
            WIRE 848 784 992 784
        END BRANCH
        IOMARKER 848 736 psi_debug_sample(1:0) R180 28
        IOMARKER 848 784 rx_addr(4:0) R180 28
        BEGIN BRANCH adc_sample_we
            WIRE 1520 3360 1648 3360
            BEGIN DISPLAY 1520 3360 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_burst_we
            WIRE 1600 4208 1728 4208
            BEGIN DISPLAY 1600 4208 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data1(28:0)
            WIRE 3376 2224 3504 2224
            BEGIN DISPLAY 3504 2224 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_we1
            WIRE 3376 1328 3488 1328
            BEGIN DISPLAY 3488 1328 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 2640 1520 2800 1520
            BEGIN DISPLAY 2640 1520 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4093 2800 2256 R0
        END INSTANCE
        BEGIN BRANCH rx_addr(4:0)
            WIRE 2640 1840 2800 1840
            BEGIN DISPLAY 2640 1840 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(19:10)
            WIRE 2640 1904 2800 1904
            BEGIN DISPLAY 2640 1904 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(29:20)
            WIRE 2640 1968 2800 1968
            BEGIN DISPLAY 2640 1968 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(39:30)
            WIRE 2640 2032 2800 2032
            BEGIN DISPLAY 2640 2032 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(49:40)
            WIRE 2640 2096 2800 2096
            BEGIN DISPLAY 2640 2096 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(59:50)
            WIRE 2640 2160 2800 2160
            BEGIN DISPLAY 2640 2160 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_data(9:0)
            WIRE 2640 2224 2800 2224
            BEGIN DISPLAY 2640 2224 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MASTER_CLK
            WIRE 2640 1456 2800 1456
            BEGIN DISPLAY 2640 1456 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_sample_sel
            WIRE 2640 1584 2800 1584
            BEGIN DISPLAY 2640 1584 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_sample(11:2)
            WIRE 2640 1776 2800 1776
            BEGIN DISPLAY 2640 1776 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_sample_we
            WIRE 2640 1392 2800 1392
            BEGIN DISPLAY 2640 1392 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_debug_sample(1:0)
            WIRE 2640 2288 2800 2288
            BEGIN DISPLAY 2640 2288 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PSI_LEVELS_MAP
            WIRE 2640 1712 2800 1712
            BEGIN DISPLAY 2640 1712 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4617 1888 1744 R0
        END INSTANCE
        BEGIN BRANCH XLXN_15154
            WIRE 2272 1648 2800 1648
        END BRANCH
        BEGIN BRANCH PSI_CLK90
            WIRE 1728 1648 1888 1648
            BEGIN DISPLAY 1728 1648 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH psi_token_out
            WIRE 1728 1712 1888 1712
            BEGIN DISPLAY 1728 1712 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4088 5104 736 R0
        END INSTANCE
        INSTANCE XLXI_4089 5104 464 R0
        BEGIN BRANCH b_data_we
            WIRE 5424 336 5616 336
            BEGIN DISPLAY 5616 336 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data(63:0)
            WIRE 5488 576 5616 576
            BEGIN DISPLAY 5616 576 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_sel
            WIRE 4944 432 5104 432
            BEGIN DISPLAY 4944 432 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_sel
            WIRE 4944 576 5104 576
            BEGIN DISPLAY 4944 576 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data0(63:0)
            WIRE 4944 640 5104 640
            BEGIN DISPLAY 4944 640 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data1(63:0)
            WIRE 4944 704 5104 704
            BEGIN DISPLAY 4944 704 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_we1
            WIRE 4944 368 5104 368
            BEGIN DISPLAY 4944 368 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b_data_we0
            WIRE 4944 304 5104 304
            BEGIN DISPLAY 4944 304 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4119 4528 4976 R0
        END INSTANCE
        BEGIN BRANCH adc_raw_data(11:0)
            WIRE 4912 4912 5008 4912
            BEGIN DISPLAY 5008 4912 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_raw_data(71:0)
            WIRE 4608 4592 4720 4592
            WIRE 4720 4592 4832 4592
            BEGIN DISPLAY 4720 4592 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_4097 4560 4240 R0
        END INSTANCE
        BEGIN BRANCH adc_data_label(3:0)
            WIRE 4432 4208 4560 4208
            BEGIN DISPLAY 4432 4208 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_raw_data(69:10)
            WIRE 4432 4144 4560 4144
            BEGIN DISPLAY 4432 4144 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_burst_data(63:0)
            WIRE 4944 4144 5088 4144
            BEGIN DISPLAY 5088 4144 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH adc_sample_we
            WIRE 848 880 992 880
        END BRANCH
        BEGIN BRANCH adc_burst_we
            WIRE 848 928 992 928
        END BRANCH
        IOMARKER 848 880 adc_sample_we R180 28
        IOMARKER 848 928 adc_burst_we R180 28
        BEGIN BRANCH b_data_sel
            WIRE 848 832 992 832
        END BRANCH
        IOMARKER 848 832 b_data_sel R180 28
    END SHEET
END SCHEMATIC
