-------------------------------------------------------------------------------
--
-- Title       : No Title
-- Design      : PsiDecoder
-- Author      : Desktop Support
-- Company     : FNAL
--
-------------------------------------------------------------------------------
--
-- File        : c:\Documents and Settings\rrivera\Desktop\CAPTAN FIRMWARE\PsiDecoder\PsiDecoder\compile\PsiDecoderBlock_v1_0.vhd
-- Generated   : Mon Apr 27 10:20:09 2009
-- From        : c:/Documents and Settings/rrivera/Desktop/CAPTAN FIRMWARE/PsiDecoder/PsiDecoder/src/PsiDecoderBlock_v1_0.bde
-- By          : Bde2Vhdl ver. 2.6
--
-------------------------------------------------------------------------------
--
-- Description : 
--
-------------------------------------------------------------------------------
-- Design unit header --
library IEEE;
use IEEE.std_logic_1164.all;
use PsiDecoderParameters.all;

entity PsiDecoderBlock is
  port(
       ADC_WR_EN : in STD_LOGIC;
       MASTER_CLOCK : in STD_LOGIC;
       RESET : in STD_LOGIC;
       SAMPLE_SEL : in STD_LOGIC;
       TOKEN_OUT : in STD_LOGIC;
       WR_EN_MEM : in STD_LOGIC;
       ADC_DATA_IN : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       CHIP_ID_WR : in STD_LOGIC_VECTOR(chip_id_bits_P-1 downto 0);
       DEBUG_SEL : in STD_LOGIC_VECTOR(1 downto 0);
       LEVEL0 : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       LEVEL1 : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       LEVEL2 : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       LEVEL3 : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       LEVEL4 : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       ULTRABLACK : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       DATA_OUT_WR : out STD_LOGIC;
       DATA_OUT : out STD_LOGIC_VECTOR(pulse_height_bits_P+chip_id_bits_P+13 downto 0)
  );
end PsiDecoderBlock;

architecture PsiDecoderBlock of PsiDecoderBlock is

---- Component declarations -----

component Comparator
  port (
       MASTER_CLOCK : in STD_LOGIC;
       at_chip_zero : in STD_LOGIC;
       level0_mem : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       level1_mem : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       level2_mem : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       level3_mem : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       level4_mem : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       managed_data : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       ublack_mem : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       wr_en : in STD_LOGIC;
       clk_en : out STD_LOGIC;
       next_chip : out STD_LOGIC;
       raw_data : out STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       translated_levels : out STD_LOGIC_VECTOR(2 downto 0)
  );
end component;
component Levels_Memory
  port (
       CHIP_ID_WR : in STD_LOGIC_VECTOR(chip_id_bits_P-1 downto 0);
       LEVEL0 : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       LEVEL1 : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       LEVEL2 : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       LEVEL3 : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       LEVEL4 : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       MASTER_CLOCK : in STD_LOGIC;
       RESET : in STD_LOGIC;
       ULTRABLACK : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       WR_EN_MEM : in STD_LOGIC;
       chip_id_rd : in STD_LOGIC_VECTOR(chip_id_bits_P-1 downto 0);
       level0_mem : out STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       level1_mem : out STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       level2_mem : out STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       level3_mem : out STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       level4_mem : out STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       ublack_mem : out STD_LOGIC_VECTOR(adc_bits_P-1 downto 0)
  );
end component;
component Sample_Manager
  port (
       ADC_DATA_IN : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       ADC_WR_EN : in STD_LOGIC;
       MASTER_CLOCK : in STD_LOGIC;
       SAMPLE_SEL : in STD_LOGIC;
       managed_data : out STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       wr_en : out STD_LOGIC
  );
end component;
component State_Machine
  port (
       MASTER_CLOCK : in STD_LOGIC;
       RESET : in STD_LOGIC;
       TOKEN_OUT : in STD_LOGIC;
       clk_en : in STD_LOGIC;
       next_chip : in STD_LOGIC;
       raw_data : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       translated_levels : in STD_LOGIC_VECTOR(2 downto 0);
       DATA_OUT : out STD_LOGIC_VECTOR(pulse_height_bits_P+chip_id_bits_P+13-1 downto 0);
       DATA_OUT_WR : out STD_LOGIC;
       at_chip_zero : out STD_LOGIC;
       chip_id_rd : out STD_LOGIC_VECTOR(chip_id_bits_P-1 downto 0);
       debug_curr_state : out STD_LOGIC_VECTOR(8 downto 0)
  );
end component;
component data_out_mux
  port (
       DEBUG_SAMPLE : in STD_LOGIC_VECTOR(1 downto 0);
       MASTER_CLK : in STD_LOGIC;
       debug_sm_data : in STD_LOGIC_VECTOR(8 downto 0);
       hit_data : in STD_LOGIC_VECTOR(pulse_height_bits_P+chip_id_bits_P+13-1 downto 0);
       hit_data_we : in STD_LOGIC;
       managed_data : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       reset : in STD_LOGIC;
       ublack_mem : in STD_LOGIC_VECTOR(adc_bits_P-1 downto 0);
       wr_en : in STD_LOGIC;
       DATA_OUT : out STD_LOGIC_VECTOR(pulse_height_bits_P+chip_id_bits_P+13 downto 0);
       DATA_OUT_WR : out STD_LOGIC
  );
end component;

---- Signal declarations used on the diagram ----

signal at_chip_zero : STD_LOGIC;
signal clk_en : STD_LOGIC;
signal hit_data_we : STD_LOGIC;
signal next_chip : STD_LOGIC;
signal wr_en : STD_LOGIC;
signal chip_id_rd : STD_LOGIC_VECTOR (chip_id_bits_P-1 downto 0);
signal debug_curr_state : STD_LOGIC_VECTOR (8 downto 0);
signal hit_data : STD_LOGIC_VECTOR (pulse_height_bits_P+chip_id_bits_P+13-1 downto 0);
signal level0_mem : STD_LOGIC_VECTOR (adc_bits_P-1 downto 0);
signal level1_mem : STD_LOGIC_VECTOR (adc_bits_P-1 downto 0);
signal level2_mem : STD_LOGIC_VECTOR (adc_bits_P-1 downto 0);
signal level3_mem : STD_LOGIC_VECTOR (adc_bits_P-1 downto 0);
signal level4_mem : STD_LOGIC_VECTOR (adc_bits_P-1 downto 0);
signal managed_data : STD_LOGIC_VECTOR (adc_bits_P-1 downto 0);
signal raw_data : STD_LOGIC_VECTOR (adc_bits_P-1 downto 0);
signal translated_levels : STD_LOGIC_VECTOR (2 downto 0);
signal ublack_mem : STD_LOGIC_VECTOR (adc_bits_P-1 downto 0);

begin

----  Component instantiations  ----

U1 : Levels_Memory
  port map(
       CHIP_ID_WR => CHIP_ID_WR( chip_id_bits_P-1 downto 0 ),
       LEVEL0 => LEVEL0( adc_bits_P-1 downto 0 ),
       LEVEL1 => LEVEL1( adc_bits_P-1 downto 0 ),
       LEVEL2 => LEVEL2( adc_bits_P-1 downto 0 ),
       LEVEL3 => LEVEL3( adc_bits_P-1 downto 0 ),
       LEVEL4 => LEVEL4( adc_bits_P-1 downto 0 ),
       MASTER_CLOCK => MASTER_CLOCK,
       RESET => RESET,
       ULTRABLACK => ULTRABLACK( adc_bits_P-1 downto 0 ),
       WR_EN_MEM => WR_EN_MEM,
       chip_id_rd => chip_id_rd( chip_id_bits_P-1 downto 0 ),
       level0_mem => level0_mem( adc_bits_P-1 downto 0 ),
       level1_mem => level1_mem( adc_bits_P-1 downto 0 ),
       level2_mem => level2_mem( adc_bits_P-1 downto 0 ),
       level3_mem => level3_mem( adc_bits_P-1 downto 0 ),
       level4_mem => level4_mem( adc_bits_P-1 downto 0 ),
       ublack_mem => ublack_mem( adc_bits_P-1 downto 0 )
  );

U2 : Comparator
  port map(
       MASTER_CLOCK => MASTER_CLOCK,
       at_chip_zero => at_chip_zero,
       clk_en => clk_en,
       level0_mem => level0_mem( adc_bits_P-1 downto 0 ),
       level1_mem => level1_mem( adc_bits_P-1 downto 0 ),
       level2_mem => level2_mem( adc_bits_P-1 downto 0 ),
       level3_mem => level3_mem( adc_bits_P-1 downto 0 ),
       level4_mem => level4_mem( adc_bits_P-1 downto 0 ),
       managed_data => managed_data( adc_bits_P-1 downto 0 ),
       next_chip => next_chip,
       raw_data => raw_data( adc_bits_P-1 downto 0 ),
       translated_levels => translated_levels,
       ublack_mem => ublack_mem( adc_bits_P-1 downto 0 ),
       wr_en => wr_en
  );

U3 : Sample_Manager
  port map(
       ADC_DATA_IN => ADC_DATA_IN( adc_bits_P-1 downto 0 ),
       ADC_WR_EN => ADC_WR_EN,
       MASTER_CLOCK => MASTER_CLOCK,
       SAMPLE_SEL => SAMPLE_SEL,
       managed_data => managed_data( adc_bits_P-1 downto 0 ),
       wr_en => wr_en
  );

U4 : State_Machine
  port map(
       DATA_OUT => hit_data( pulse_height_bits_P+chip_id_bits_P+13-1 downto 0 ),
       DATA_OUT_WR => hit_data_we,
       MASTER_CLOCK => MASTER_CLOCK,
       RESET => RESET,
       TOKEN_OUT => TOKEN_OUT,
       at_chip_zero => at_chip_zero,
       chip_id_rd => chip_id_rd( chip_id_bits_P-1 downto 0 ),
       clk_en => clk_en,
       debug_curr_state => debug_curr_state,
       next_chip => next_chip,
       raw_data => raw_data( adc_bits_P-1 downto 0 ),
       translated_levels => translated_levels
  );

U5 : data_out_mux
  port map(
       DATA_OUT => DATA_OUT( pulse_height_bits_P+chip_id_bits_P+13 downto 0 ),
       DATA_OUT_WR => DATA_OUT_WR,
       DEBUG_SAMPLE => DEBUG_SEL,
       MASTER_CLK => MASTER_CLOCK,
       debug_sm_data => debug_curr_state,
       hit_data => hit_data( pulse_height_bits_P+chip_id_bits_P+13-1 downto 0 ),
       hit_data_we => hit_data_we,
       managed_data => managed_data( adc_bits_P-1 downto 0 ),
       reset => RESET,
       ublack_mem => ublack_mem( adc_bits_P-1 downto 0 ),
       wr_en => wr_en
  );


end PsiDecoderBlock;
