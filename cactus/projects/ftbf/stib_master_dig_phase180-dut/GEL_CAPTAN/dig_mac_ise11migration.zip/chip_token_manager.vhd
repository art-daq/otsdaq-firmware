	--=============================================================================
	-- Project: Chip Sync
	-- Copyright: 
	-- Author: Ryan Rivera 
	-- Revision:  
	-- Last revised: 
	-- Workfile: 
	-- Archive: 
	-------------------------------------------------------------------------------
	-- Description:	Chip Sync for FPix2.1 serial out synchronization
	-- 
	-- 
	-------------------------------------------------------------------------------
	
	-------------------------------------------------------------------------------
	-- Revision History:
	--
	-- 
	-- 
	--=============================================================================
	
	library IEEE;
	use IEEE.STD_LOGIC_1164.ALL;
	use IEEE.STD_LOGIC_ARITH.ALL;
	use IEEE.STD_LOGIC_UNSIGNED.ALL;
	
	entity chip_token_manager is
		port (
		
		reset : in std_logic;  -- reset synchronous with clk
		clk : in std_logic;
		token_in : in std_logic;  
		first_in_token_chain : in std_logic;
		
		data_sel : in std_logic;  -- 1 indicates pixel data, 0 is raw ADC
		plaq_id : in std_logic_vector(2 downto 0); -- appended to data when in pixel mode
		cal_trig_sel : in std_logic;  -- 0 puts trig_num into 51:32, 1 puts cal_tag		
		cal_tag : in std_logic_vector(15 downto 0); -- appended to data when in pixel mode and cal_tag mode
		trig_num : in std_logic_vector(19 downto 0); -- appended to data when in pixel mode and trig_num mode
		pdin : in std_logic_vector(63 downto 0);  			   
		pdin_we : in std_logic;			  
		
		
		ovf_err : out std_logic; 
		token_out : out std_logic; 	
		bus_dout : inout std_logic_vector(63 downto 0);  -- 63:48 is calTag. 31:29 is plaqId when in pixel mode
		we_out : out std_logic
			);
	end chip_token_manager;			  
	
	-- token manager passes token when has no data and places output lines at high impedence
	-- when there is data, having token gives right to take over bus lines.
	architecture chip_token_manager_arch of chip_token_manager is					
		signal have_data: std_logic; 
		signal latch_d : std_logic_vector(63 downto 0); 
		
		signal token_delay : std_logic;		
		signal first_token : std_logic;	 
		signal need_first_token : std_logic;  
		signal ovf_err_sig : std_logic;
		
	begin						   
		
		token_out <= token_delay when first_in_token_chain = '0' else first_token;
		ovf_err <= ovf_err_sig;
		
		process(clk)
		begin
			if rising_edge(clk) then  
				
				token_delay <= token_in; -- delay token in by one clock edge
				
				if reset = '1' then		   
					ovf_err_sig <= '0';
					have_data <= '0';
					bus_dout <= "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ";
					we_out <= '0';	  
					
					first_token <= '0';
					need_first_token <= '1';				
					
				else		
					
						-- TOKEN GENERATION
					if first_in_token_chain = '1' then  -- gen 1 clk pulse token to pass
						if need_first_token = '1' then
							first_token <= '1';	  
							need_first_token <= '0';
						elsif token_in = '1' then
							first_token <= '1';
						elsif first_token = '1' then
							first_token <= '0';
						end if;
					end if;
					
						-- OUTPUT LATCHED INPUT WITH TOKEN	
					if token_in = '1' and have_data = '1' and ovf_err_sig = '0' then -- token manager has bus	 
					
						if data_sel = '1' then										
							bus_dout(63 downto 52) <= (others => '0');
							if cal_trig_sel = '0' then
								bus_dout(51 downto 32) <= trig_num;
							else
								bus_dout(51 downto 48) <= (others => '0');
								bus_dout(47 downto 32) <= cal_tag;							
							end if;
							bus_dout(31 downto 29) <= plaq_id;
							bus_dout(28 downto 0) <= latch_d(28 downto 0); 
						else
							bus_dout <= latch_d;
						end if;
						
						we_out <= '1';	   
						have_data <= '0';
					else
						bus_dout <= "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ";
						we_out <= '0';
					end if;
					
						-- LATCH NEW INPUT
					if pdin_we = '1' then  -- valid input data
						if have_data = '1' and token_in = '0' then
							ovf_err_sig <= '1';
						else
							latch_d <= pdin;
							have_data <= '1';
						end if;
					end if;
					
				end if;
				
			end if;		
		end process;
		
		
	end chip_token_manager_arch;	