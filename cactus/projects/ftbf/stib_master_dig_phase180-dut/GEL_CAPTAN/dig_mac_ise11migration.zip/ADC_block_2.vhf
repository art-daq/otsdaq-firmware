--------------------------------------------------------------------------------
-- Copyright (c) 1995-2008 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 10.1
--  \   \         Application : sch2vhdl
--  /   /         Filename : ADC_block_2.vhf
-- /___/   /\     Timestamp : 05/30/2009 03:20:32
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: C:\Xilinx\10.1\ISE\bin\nt\unwrapped\sch2vhdl.exe -intstyle ise -family virtex4 -flat -suppress -w E:/CMS_TB/GEL_CAPTAN/ADC_block_2.sch ADC_block_2.vhf
--Design Name: ADC_block_2
--Device: virtex4
--Purpose:
--    This vhdl netlist is translated from an ECS schematic. It can be 
--    synthesis and simulted, but it should not be modified. 
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity ADC_block_2 is
   port ( DCK   : in    std_logic; 
          D0_IN : in    std_logic; 
          D1_IN : in    std_logic; 
          DOUT  : out   std_logic_vector (11 downto 0); 
          D0    : out   std_logic; 
          D1    : out   std_logic);
end ADC_block_2;

architecture BEHAVIORAL of ADC_block_2 is
   attribute INIT       : string ;
   attribute BOX_TYPE   : string ;
   signal DOUT_DUMMY : std_logic_vector (11 downto 0);
   component FD
      -- synopsys translate_off
      generic( INIT : bit :=  '0');
      -- synopsys translate_on
      port ( C : in    std_logic; 
             D : in    std_logic; 
             Q : out   std_logic);
   end component;
   attribute INIT of FD : component is "0";
   attribute BOX_TYPE of FD : component is "BLACK_BOX";
   
   component FD_1
      -- synopsys translate_off
      generic( INIT : bit :=  '0');
      -- synopsys translate_on
      port ( C : in    std_logic; 
             D : in    std_logic; 
             Q : out   std_logic);
   end component;
   attribute INIT of FD_1 : component is "0";
   attribute BOX_TYPE of FD_1 : component is "BLACK_BOX";
   
   component BUF
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute BOX_TYPE of BUF : component is "BLACK_BOX";
   
begin
   DOUT(11 downto 0) <= DOUT_DUMMY(11 downto 0);
   XLXI_28 : FD
      port map (C=>DCK,
                D=>D0_IN,
                Q=>DOUT_DUMMY(10));
   
   XLXI_30 : FD
      port map (C=>DCK,
                D=>DOUT_DUMMY(10),
                Q=>DOUT_DUMMY(8));
   
   XLXI_32 : FD
      port map (C=>DCK,
                D=>DOUT_DUMMY(8),
                Q=>DOUT_DUMMY(6));
   
   XLXI_34 : FD
      port map (C=>DCK,
                D=>DOUT_DUMMY(6),
                Q=>DOUT_DUMMY(4));
   
   XLXI_36 : FD
      port map (C=>DCK,
                D=>DOUT_DUMMY(4),
                Q=>DOUT_DUMMY(2));
   
   XLXI_38 : FD
      port map (C=>DCK,
                D=>DOUT_DUMMY(2),
                Q=>DOUT_DUMMY(0));
   
   XLXI_55 : FD_1
      port map (C=>DCK,
                D=>D1_IN,
                Q=>DOUT_DUMMY(11));
   
   XLXI_56 : FD_1
      port map (C=>DCK,
                D=>DOUT_DUMMY(11),
                Q=>DOUT_DUMMY(9));
   
   XLXI_59 : FD_1
      port map (C=>DCK,
                D=>DOUT_DUMMY(9),
                Q=>DOUT_DUMMY(7));
   
   XLXI_60 : FD_1
      port map (C=>DCK,
                D=>DOUT_DUMMY(7),
                Q=>DOUT_DUMMY(5));
   
   XLXI_61 : FD_1
      port map (C=>DCK,
                D=>DOUT_DUMMY(5),
                Q=>DOUT_DUMMY(3));
   
   XLXI_62 : FD_1
      port map (C=>DCK,
                D=>DOUT_DUMMY(3),
                Q=>DOUT_DUMMY(1));
   
   XLXI_254 : BUF
      port map (I=>DOUT_DUMMY(1),
                O=>D1);
   
   XLXI_255 : BUF
      port map (I=>DOUT_DUMMY(0),
                O=>D0);
   
end BEHAVIORAL;


