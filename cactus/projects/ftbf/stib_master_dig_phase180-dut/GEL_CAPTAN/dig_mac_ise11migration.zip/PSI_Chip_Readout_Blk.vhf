--------------------------------------------------------------------------------
-- Copyright (c) 1995-2008 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 10.1
--  \   \         Application : sch2vhdl
--  /   /         Filename : PSI_Chip_Readout_Blk.vhf
-- /___/   /\     Timestamp : 05/30/2009 03:20:33
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: C:\Xilinx\10.1\ISE\bin\nt\unwrapped\sch2vhdl.exe -intstyle ise -family virtex4 -flat -suppress -w E:/CMS_TB/GEL_CAPTAN/PSI_Chip_Readout_Blk.sch PSI_Chip_Readout_Blk.vhf
--Design Name: PSI_Chip_Readout_Blk
--Device: virtex4
--Purpose:
--    This vhdl netlist is translated from an ECS schematic. It can be 
--    synthesis and simulted, but it should not be modified. 
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity M2_1_MXILINX_PSI_Chip_Readout_Blk is
   port ( D0 : in    std_logic; 
          D1 : in    std_logic; 
          S0 : in    std_logic; 
          O  : out   std_logic);
end M2_1_MXILINX_PSI_Chip_Readout_Blk;

architecture BEHAVIORAL of M2_1_MXILINX_PSI_Chip_Readout_Blk is
   attribute BOX_TYPE   : string ;
   signal M0 : std_logic;
   signal M1 : std_logic;
   component AND2B1
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND2B1 : component is "BLACK_BOX";
   
   component OR2
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of OR2 : component is "BLACK_BOX";
   
   component AND2
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND2 : component is "BLACK_BOX";
   
begin
   I_36_7 : AND2B1
      port map (I0=>S0,
                I1=>D0,
                O=>M0);
   
   I_36_8 : OR2
      port map (I0=>M1,
                I1=>M0,
                O=>O);
   
   I_36_9 : AND2
      port map (I0=>D1,
                I1=>S0,
                O=>M1);
   
end BEHAVIORAL;



library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity PSI_Chip_Readout_Blk is
   port ( adc_burst_we     : in    std_logic; 
          adc_data_label   : in    std_logic_vector (3 downto 0); 
          adc_delayed_clk  : in    std_logic; 
          adc_delayed_data : in    std_logic; 
          adc_sample_we    : in    std_logic; 
          b_data_sel       : in    std_logic; 
          MASTER_CLK       : in    std_logic; 
          PSI_CLK90        : in    std_logic; 
          psi_debug_sample : in    std_logic_vector (1 downto 0); 
          PSI_LEVELS_MAP   : in    std_logic; 
          psi_sample_sel   : in    std_logic; 
          psi_token_out    : in    std_logic; 
          reset            : in    std_logic; 
          rx_addr          : in    std_logic_vector (4 downto 0); 
          rx_data          : in    std_logic_vector (63 downto 0); 
          b_data           : out   std_logic_vector (63 downto 0); 
          b_data_we        : out   std_logic);
end PSI_Chip_Readout_Blk;

architecture BEHAVIORAL of PSI_Chip_Readout_Blk is
   attribute BOX_TYPE   : string ;
   attribute INIT       : string ;
   attribute HU_SET     : string ;
   signal adc_burst_data     : std_logic_vector (63 downto 0);
   signal adc_fifo_readen    : std_logic;
   signal adc_raw_data       : std_logic_vector (71 downto 0);
   signal adc_sample_fifo_re : std_logic;
   signal b_data_we0         : std_logic;
   signal b_data_we1         : std_logic;
   signal b_data0            : std_logic_vector (63 downto 0);
   signal b_data1            : std_logic_vector (63 downto 0);
   signal psi_sample         : std_logic_vector (11 downto 0);
   signal psi_sample_we      : std_logic;
   signal XLXN_12534         : std_logic;
   signal XLXN_12535         : std_logic;
   signal XLXN_12536         : std_logic;
   signal XLXN_12537         : std_logic;
   signal XLXN_12538         : std_logic;
   signal XLXN_12539         : std_logic;
   signal XLXN_12540         : std_logic;
   signal XLXN_12541         : std_logic;
   signal XLXN_12570         : std_logic;
   signal XLXN_14590         : std_logic;
   signal XLXN_14591         : std_logic;
   signal XLXN_14592         : std_logic;
   signal XLXN_14594         : std_logic;
   signal XLXN_14595         : std_logic;
   signal XLXN_15154         : std_logic;
   component BUF
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute BOX_TYPE of BUF : component is "BLACK_BOX";
   
   component ADC_block_2
      port ( DCK   : in    std_logic; 
             D0_IN : in    std_logic; 
             D1_IN : in    std_logic; 
             D0    : out   std_logic; 
             D1    : out   std_logic; 
             DOUT  : out   std_logic_vector (11 downto 0));
   end component;
   
   component burst_test_fifo64
      port ( rd_clk : in    std_logic; 
             rd_en  : in    std_logic; 
             rst    : in    std_logic; 
             wr_clk : in    std_logic; 
             wr_en  : in    std_logic; 
             din    : in    std_logic_vector (63 downto 0); 
             empty  : out   std_logic; 
             full   : out   std_logic; 
             dout   : out   std_logic_vector (63 downto 0));
   end component;
   
   component INV
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute BOX_TYPE of INV : component is "BLACK_BOX";
   
   component FD
      -- synopsys translate_off
      generic( INIT : bit :=  '0');
      -- synopsys translate_on
      port ( C : in    std_logic; 
             D : in    std_logic; 
             Q : out   std_logic);
   end component;
   attribute INIT of FD : component is "0";
   attribute BOX_TYPE of FD : component is "BLACK_BOX";
   
   component MUX64_2
      port ( sel    : in    std_logic; 
             in0    : in    std_logic_vector (63 downto 0); 
             in1    : in    std_logic_vector (63 downto 0); 
             muxout : out   std_logic_vector (63 downto 0));
   end component;
   
   component M2_1_MXILINX_PSI_Chip_Readout_Blk
      port ( D0 : in    std_logic; 
             D1 : in    std_logic; 
             S0 : in    std_logic; 
             O  : out   std_logic);
   end component;
   
   component PsiDecoderBlock
      port ( ADC_WR_EN    : in    std_logic; 
             MASTER_CLOCK : in    std_logic; 
             RESET        : in    std_logic; 
             SAMPLE_SEL   : in    std_logic; 
             TOKEN_OUT    : in    std_logic; 
             WR_EN_MEM    : in    std_logic; 
             ADC_DATA_IN  : in    std_logic_vector (9 downto 0); 
             CHIP_ID_WR   : in    std_logic_vector (4 downto 0); 
             LEVEL0       : in    std_logic_vector (9 downto 0); 
             LEVEL1       : in    std_logic_vector (9 downto 0); 
             LEVEL2       : in    std_logic_vector (9 downto 0); 
             LEVEL3       : in    std_logic_vector (9 downto 0); 
             LEVEL4       : in    std_logic_vector (9 downto 0); 
             ULTRABLACK   : in    std_logic_vector (9 downto 0); 
             DATA_OUT_WR  : out   std_logic; 
             DATA_OUT     : out   std_logic_vector (28 downto 0); 
             DEBUG_SEL    : in    std_logic_vector (1 downto 0));
   end component;
   
   component adc_burst_data_splicer
      port ( adc_data   : in    std_logic_vector (59 downto 0); 
             data_label : in    std_logic_vector (3 downto 0); 
             dout       : out   std_logic_vector (63 downto 0));
   end component;
   
   component adc_sample_fifo12
      port ( rd_clk : in    std_logic; 
             rd_en  : in    std_logic; 
             rst    : in    std_logic; 
             wr_clk : in    std_logic; 
             wr_en  : in    std_logic; 
             din    : in    std_logic_vector (11 downto 0); 
             empty  : out   std_logic; 
             full   : out   std_logic; 
             dout   : out   std_logic_vector (11 downto 0));
   end component;
   
   component psi_token_delay_blk
      port ( clk         : in    std_logic; 
             token       : in    std_logic; 
             token_delay : out   std_logic);
   end component;
   
   attribute HU_SET of XLXI_4089 : label is "XLXI_4089_0";
begin
   XLXI_85 : BUF
      port map (I=>adc_delayed_data,
                O=>XLXN_14594);
   
   XLXI_86 : BUF
      port map (I=>adc_delayed_data,
                O=>XLXN_14595);
   
   XLXI_3483 : ADC_block_2
      port map (DCK=>adc_delayed_clk,
                D0_IN=>XLXN_14594,
                D1_IN=>XLXN_14595,
                DOUT(11 downto 0)=>adc_raw_data(71 downto 60),
                D0=>XLXN_12534,
                D1=>XLXN_12535);
   
   XLXI_3493 : ADC_block_2
      port map (DCK=>adc_delayed_clk,
                D0_IN=>XLXN_12534,
                D1_IN=>XLXN_12535,
                DOUT(11 downto 0)=>adc_raw_data(59 downto 48),
                D0=>XLXN_12536,
                D1=>XLXN_12537);
   
   XLXI_3494 : ADC_block_2
      port map (DCK=>adc_delayed_clk,
                D0_IN=>XLXN_12536,
                D1_IN=>XLXN_12537,
                DOUT(11 downto 0)=>adc_raw_data(47 downto 36),
                D0=>XLXN_12538,
                D1=>XLXN_12539);
   
   XLXI_3495 : ADC_block_2
      port map (DCK=>adc_delayed_clk,
                D0_IN=>XLXN_12538,
                D1_IN=>XLXN_12539,
                DOUT(11 downto 0)=>adc_raw_data(35 downto 24),
                D0=>XLXN_12540,
                D1=>XLXN_12541);
   
   XLXI_3496 : ADC_block_2
      port map (DCK=>adc_delayed_clk,
                D0_IN=>XLXN_12540,
                D1_IN=>XLXN_12541,
                DOUT(11 downto 0)=>adc_raw_data(23 downto 12),
                D0=>XLXN_14590,
                D1=>XLXN_14591);
   
   XLXI_3499 : burst_test_fifo64
      port map (din(63 downto 0)=>adc_burst_data(63 downto 0),
                rd_clk=>MASTER_CLK,
                rd_en=>adc_fifo_readen,
                rst=>reset,
                wr_clk=>adc_delayed_clk,
                wr_en=>adc_burst_we,
                dout(63 downto 0)=>b_data0(63 downto 0),
                empty=>XLXN_12570,
                full=>open);
   
   XLXI_3503 : INV
      port map (I=>XLXN_12570,
                O=>adc_fifo_readen);
   
   XLXI_3504 : FD
      port map (C=>MASTER_CLK,
                D=>adc_fifo_readen,
                Q=>b_data_we0);
   
   XLXI_4088 : MUX64_2
      port map (in0(63 downto 0)=>b_data0(63 downto 0),
                in1(63 downto 0)=>b_data1(63 downto 0),
                sel=>b_data_sel,
                muxout(63 downto 0)=>b_data(63 downto 0));
   
   XLXI_4089 : M2_1_MXILINX_PSI_Chip_Readout_Blk
      port map (D0=>b_data_we0,
                D1=>b_data_we1,
                S0=>b_data_sel,
                O=>b_data_we);
   
   XLXI_4093 : PsiDecoderBlock
      port map (ADC_DATA_IN(9 downto 0)=>psi_sample(11 downto 2),
                ADC_WR_EN=>psi_sample_we,
                CHIP_ID_WR(4 downto 0)=>rx_addr(4 downto 0),
                DEBUG_SEL(1 downto 0)=>psi_debug_sample(1 downto 0),
                LEVEL0(9 downto 0)=>rx_data(19 downto 10),
                LEVEL1(9 downto 0)=>rx_data(29 downto 20),
                LEVEL2(9 downto 0)=>rx_data(39 downto 30),
                LEVEL3(9 downto 0)=>rx_data(49 downto 40),
                LEVEL4(9 downto 0)=>rx_data(59 downto 50),
                MASTER_CLOCK=>MASTER_CLK,
                RESET=>reset,
                SAMPLE_SEL=>psi_sample_sel,
                TOKEN_OUT=>XLXN_15154,
                ULTRABLACK(9 downto 0)=>rx_data(9 downto 0),
                WR_EN_MEM=>PSI_LEVELS_MAP,
                DATA_OUT(28 downto 0)=>b_data1(28 downto 0),
                DATA_OUT_WR=>b_data_we1);
   
   XLXI_4097 : adc_burst_data_splicer
      port map (adc_data(59 downto 0)=>adc_raw_data(69 downto 10),
                data_label(3 downto 0)=>adc_data_label(3 downto 0),
                dout(63 downto 0)=>adc_burst_data(63 downto 0));
   
   XLXI_4112 : INV
      port map (I=>XLXN_14592,
                O=>adc_sample_fifo_re);
   
   XLXI_4113 : FD
      port map (C=>MASTER_CLK,
                D=>adc_sample_fifo_re,
                Q=>psi_sample_we);
   
   XLXI_4116 : adc_sample_fifo12
      port map (din(11 downto 0)=>adc_raw_data(69 downto 58),
                rd_clk=>MASTER_CLK,
                rd_en=>adc_sample_fifo_re,
                rst=>reset,
                wr_clk=>adc_delayed_clk,
                wr_en=>adc_sample_we,
                dout(11 downto 0)=>psi_sample(11 downto 0),
                empty=>XLXN_14592,
                full=>open);
   
   XLXI_4119 : ADC_block_2
      port map (DCK=>adc_delayed_clk,
                D0_IN=>XLXN_14590,
                D1_IN=>XLXN_14591,
                DOUT(11 downto 0)=>adc_raw_data(11 downto 0),
                D0=>open,
                D1=>open);
   
   XLXI_4617 : psi_token_delay_blk
      port map (clk=>PSI_CLK90,
                token=>psi_token_out,
                token_delay=>XLXN_15154);
   
end BEHAVIORAL;


