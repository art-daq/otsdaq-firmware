library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

entity ADC_block is
    Port ( adc_frame : in  STD_LOGIC;
           adc_clk : in  STD_LOGIC;
           adc_data : in  STD_LOGIC;
           data_out : out  STD_LOGIC_VECTOR (63 downto 0);
           system_clk : in  STD_LOGIC;
           data_we : out  STD_LOGIC;
           reset_n : in  STD_LOGIC);
end ADC_block;

architecture Behavioral of ADC_block is
	signal data_lo_sig : STD_LOGIC_VECTOR (29 downto 0);
	signal data_hi_sig : STD_LOGIC_VECTOR (29 downto 0);
	signal data_taking_mode : STD_LOGIC;
	signal count_lo : integer range 31 downto 0;	
	signal count_hi : integer range 31 downto 0;	  
	
	signal old_frame : std_logic;	  
	signal data_ready : std_logic;	    
--	signal old_data_ready : std_logic;
	signal data_to_handle : std_logic;  
	signal old_data_to_handle : std_logic;  
	signal data_we_sig : std_logic;	  
	
	signal data_out_sig :  STD_LOGIC_VECTOR (63 downto 0);		
	signal identifier : STD_LOGIC_VECTOR (3 downto 0);		
begin
	
	reorder: process(data_out_sig,identifier)
	begin
		for i in 4 to 63
		loop
			data_out(i) <= data_out_sig(63-i); 
		end loop; 			
		data_out(3 downto 0) <= identifier;
	end process;
					
	deser: process(adc_clk, reset_n)
	begin						
		if reset_n = '0' then
			data_lo_sig <= (others => '0');   
			data_hi_sig <= (others => '0');   
			data_out_sig <= (others => '0');
			data_taking_mode <= '0';
			count_lo <= 0;	 
			count_hi <= 0;	 
			old_frame <= adc_frame;		 
			data_ready <= '0';	  
			identifier <= (others => '0');
		else
			if rising_edge(adc_clk) then   
				old_frame <= adc_frame;
				if data_taking_mode = '0' then	  
					if old_frame = '0' and adc_frame = '1' then	   --take 5 words
						data_taking_mode <= '1';
						data_lo_sig(0) <= adc_data; 
						count_lo <= 1;
					end if;
				elsif count_lo < 30 then
					data_lo_sig(29 downto 1) <= data_lo_sig(28 downto 0); 
					data_lo_sig(0) <= adc_data;  
					count_lo <= count_lo + 1;	
				elsif old_frame = '0' and adc_frame = '1' then	   --stay in data taking mode
					data_lo_sig <= (others => '0');
					data_lo_sig(0) <= adc_data;    
					
					count_lo <= 1; 
				else
					data_taking_mode <= '0';
				end if;	
			end if;			
			
			if falling_edge(adc_clk) and data_taking_mode = '1' then	  
				if count_hi < 29 then
					data_hi_sig(29 downto 1) <= data_hi_sig(28 downto 0); 
					data_hi_sig(0) <= adc_data;    		
					count_hi <= count_hi + 1;		
				else
							   
					for i in 1 to 29
					loop
						data_out_sig(i*2) <= data_hi_sig(i-1); 
					end loop;
					for i in 0 to 29
					loop
						data_out_sig(i*2+1) <= data_lo_sig(i); 
					end loop;
					data_out_sig(0) <= adc_data;	
					
					identifier <= identifier + 1;
					data_ready <= '1';
					count_hi <= 0;		 
					data_hi_sig <= (others => '0');
				end if;			  	  
				
				if data_to_handle = '1' and data_ready = '1' then
					data_ready <= '0';
				end if;
			end if;
		end if;	   	
	end process;   
	
	output: process(system_clk,reset_n)		   
	begin							  		  
		if reset_n = '0' then 
			data_to_handle <= '0';	
			data_we_sig <= '0';	  
			data_we <= '0';	   
			--old_data_ready <= '0';
		elsif rising_edge(system_clk) then 	  
			
			--old_data_ready <= data_ready;  
			old_data_to_handle <= data_to_handle;
			data_we <= data_we_sig;		
			
			if data_to_handle = '0' and data_ready = '1' then 
				data_to_handle <= '1'; 
			elsif data_to_handle = '1' and data_ready = '0' then
				data_to_handle <= '0'; 
			end if;			
			
			if old_data_to_handle = '0' and data_to_handle = '1' then
				data_we_sig <= '1';		
			end if;	
			
			if data_we_sig = '1' then
				data_we_sig <= '0';
			end if;				  		   

		end if;		
	end process;

end Behavioral;