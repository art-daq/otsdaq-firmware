// PROMGEN: Xilinx Prom Generator K.31
// Copyright (c) 1995-2008 Xilinx, Inc.  All rights reserved.

DATE      05/28/09-17:11
SOURCE    C:\Documents and Settings\rrivera\Desktop\CMS_TB\GEL_CAPTAN\//prom.mcs
DEVICE    XCF32P
SIGNATURE 0x313992DD
