-------------------------------------------------------------------------------
--
-- Title       : params_package
-- Design      : CAPTAN
-- Author      : aprosser
-- Company     : CD_CEPA_ESE
--
-------------------------------------------------------------------------------
--
-- File        : params_package.vhd
-- Generated   : Mon Jun  9 15:12:08 2008
-- From        : interface description file
-- By          : Itf2Vhdl ver. 1.20
--
-------------------------------------------------------------------------------
--
-- Description : 
--
-------------------------------------------------------------------------------

--{{ Section below this comment is automatically maintained
--   and may be overwritten
--{entity {params_package} architecture {params_package}}
	 
	
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.STD_LOGIC_ARITH.all;
use IEEE.STD_LOGIC_UNSIGNED.all;
package params_package is	
 
-- Constants 

-- 5 bit constants
	constant v_5_0: std_logic_vector := "00000";
	constant v_5_1: std_logic_vector := "00001";
	constant v_5_22: std_logic_vector := "10110"; 
-- for CRC Loop counting from GEC
		
-- 8 bit constants		
	constant v_8_0: std_logic_vector := "00000000";
	constant v_8_1: std_logic_vector := "00000001";
	
-- 11 bit constants
	constant v_11_0: std_logic_vector := "00000000000";
	constant v_11_1: std_logic_vector := "00000000001";	
	
-- 16 bit constants
	constant v_16_0: std_logic_vector := "0000000000000000";
	constant v_16_1: std_logic_vector := "0000000000000001";
	
end params_package; 

package	body params_package is
	
-- Functions and procedures
end params_package;
