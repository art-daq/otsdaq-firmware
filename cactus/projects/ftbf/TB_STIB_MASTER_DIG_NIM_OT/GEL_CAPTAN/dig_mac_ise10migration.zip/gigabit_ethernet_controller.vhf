--------------------------------------------------------------------------------
-- Copyright (c) 1995-2007 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 9.2.03i
--  \   \         Application : sch2vhdl
--  /   /         Filename : gigabit_ethernet_controller.vhf
-- /___/   /\     Timestamp : 06/11/2008 14:49:56
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: C:\Xilinx_9_2\bin\nt\sch2vhdl.exe -intstyle ise -family virtex4 -flat -suppress -w "C:/Documents and Settings/rrivera/Desktop/CAPTAN FIRMWARE/dig_mac_GEL-CAPTAN-J1_0/dig_mac_4GEL/gigabit_ethernet_controller.sch" gigabit_ethernet_controller.vhf
--Design Name: gigabit_ethernet_controller
--Device: virtex4
--Purpose:
--    This vhdl netlist is translated from an ECS schematic. It can be 
--    synthesis and simulted, but it should not be modified. 
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity gigabit_ethernet_controller is
   port ( GMII_RXD           : in    std_logic_vector (7 downto 0); 
          GMII_RX_CLK        : in    std_logic; 
          GMII_RX_DV         : in    std_logic; 
          GMII_RX_ER         : in    std_logic; 
          reset_n            : in    std_logic; 
          user_addrs         : in    std_logic_vector (7 downto 0); 
          user_test_mode     : in    std_logic; 
          user_trigger       : in    std_logic; 
          user_tx_data_in    : in    std_logic_vector (7 downto 0); 
          user_tx_size_in    : in    std_logic_vector (10 downto 0); 
          crc_err            : out   std_logic; 
          GMII_TXD           : out   std_logic_vector (7 downto 0); 
          GMII_TX_EN         : out   std_logic; 
          GMII_TX_ER         : out   std_logic; 
          GTX_CLK            : out   std_logic; 
          user_busy          : out   std_logic; 
          user_rx_data_out   : out   std_logic_vector (7 downto 0); 
          user_rx_size_out   : out   std_logic_vector (10 downto 0); 
          user_rx_valid_out  : out   std_logic; 
          user_tx_enable_out : out   std_logic);
end gigabit_ethernet_controller;

architecture BEHAVIORAL of gigabit_ethernet_controller is
   attribute BOX_TYPE   : string ;
   signal crc_chk_en         : std_logic;
   signal crc_chk_err        : std_logic;
   signal crc_gen_en         : std_logic;
   signal crc_gen_init       : std_logic;
   signal crc_gen_rd         : std_logic;
   signal crc_init           : std_logic;
   signal crc_out            : std_logic_vector (7 downto 0);
   signal reset              : std_logic;
   signal txd_sig            : std_logic_vector (7 downto 0);
   component CRC_chk
      port ( Reset      : in    std_logic; 
             Clk        : in    std_logic; 
             CRC_init   : in    std_logic; 
             CRC_en     : in    std_logic; 
             CRC_chk_en : in    std_logic; 
             CRC_data   : in    std_logic_vector (7 downto 0); 
             CRC_err    : out   std_logic);
   end component;
   
   component CRC_gen
      port ( Reset      : in    std_logic; 
             Clk        : in    std_logic; 
             Init       : in    std_logic; 
             Data_en    : in    std_logic; 
             CRC_rd     : in    std_logic; 
             Frame_data : in    std_logic_vector (7 downto 0); 
             CRC_end    : out   std_logic; 
             CRC_out    : out   std_logic_vector (7 downto 0));
   end component;
   
   component CRC_splice
      port ( rd      : in    std_logic; 
             data    : in    std_logic_vector (7 downto 0); 
             crc     : in    std_logic_vector (7 downto 0); 
             dataout : out   std_logic_vector (7 downto 0));
   end component;
   
   component DIG_GEC
      port ( GMII_RX_CLK        : in    std_logic; 
             GMII_RX_DV         : in    std_logic; 
             GMII_RX_ER         : in    std_logic; 
             reset              : in    std_logic; 
             test_mode          : in    std_logic; 
             trigger            : in    std_logic; 
             GMII_RXD           : in    std_logic_vector (7 downto 0); 
             user_addrs         : in    std_logic_vector (7 downto 0); 
             user_tx_data_in    : in    std_logic_vector (7 downto 0); 
             user_tx_size_in    : in    std_logic_vector (10 downto 0); 
             GMII_GTX_CLK       : out   std_logic; 
             GMII_TX_EN         : out   std_logic; 
             GMII_TX_ER         : out   std_logic; 
             busy               : out   std_logic; 
             crc_chk_en         : out   std_logic; 
             crc_chk_err        : out   std_logic; 
             crc_chk_init       : out   std_logic; 
             crc_gen_en         : out   std_logic; 
             crc_gen_init       : out   std_logic; 
             crc_gen_rd         : out   std_logic; 
             en_tx_data         : out   std_logic; 
             is_arp_packet      : out   std_logic; 
             is_udp_packet      : out   std_logic; 
             udp_data_valid_out : out   std_logic; 
             GMII_TXD           : out   std_logic_vector (7 downto 0); 
             test_out           : out   std_logic_vector (7 downto 0); 
             udp_data_count     : out   std_logic_vector (10 downto 0); 
             user_rx_data_out   : out   std_logic_vector (7 downto 0));
   end component;
   
   component INV
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute BOX_TYPE of INV : component is "BLACK_BOX";
   
begin
   XLXI_226 : CRC_chk
      port map (Clk=>GMII_RX_CLK,
                CRC_chk_en=>crc_chk_err,
                CRC_data(7 downto 0)=>GMII_RXD(7 downto 0),
                CRC_en=>crc_chk_en,
                CRC_init=>crc_init,
                Reset=>reset,
                CRC_err=>crc_err);
   
   XLXI_238 : CRC_gen
      port map (Clk=>GMII_RX_CLK,
                CRC_rd=>crc_gen_rd,
                Data_en=>crc_gen_en,
                Frame_data(7 downto 0)=>txd_sig(7 downto 0),
                Init=>crc_gen_init,
                Reset=>reset,
                CRC_end=>open,
                CRC_out(7 downto 0)=>crc_out(7 downto 0));
   
   XLXI_248 : CRC_splice
      port map (crc(7 downto 0)=>crc_out(7 downto 0),
                data(7 downto 0)=>txd_sig(7 downto 0),
                rd=>crc_gen_rd,
                dataout(7 downto 0)=>GMII_TXD(7 downto 0));
   
   XLXI_249 : DIG_GEC
      port map (GMII_RXD(7 downto 0)=>GMII_RXD(7 downto 0),
                GMII_RX_CLK=>GMII_RX_CLK,
                GMII_RX_DV=>GMII_RX_DV,
                GMII_RX_ER=>GMII_RX_ER,
                reset=>reset,
                test_mode=>user_test_mode,
                trigger=>user_trigger,
                user_addrs(7 downto 0)=>user_addrs(7 downto 0),
                user_tx_data_in(7 downto 0)=>user_tx_data_in(7 downto 0),
                user_tx_size_in(10 downto 0)=>user_tx_size_in(10 downto 0),
                busy=>user_busy,
                crc_chk_en=>crc_chk_en,
                crc_chk_err=>crc_chk_err,
                crc_chk_init=>crc_init,
                crc_gen_en=>crc_gen_en,
                crc_gen_init=>crc_gen_init,
                crc_gen_rd=>crc_gen_rd,
                en_tx_data=>user_tx_enable_out,
                GMII_GTX_CLK=>GTX_CLK,
                GMII_TXD(7 downto 0)=>txd_sig(7 downto 0),
                GMII_TX_EN=>GMII_TX_EN,
                GMII_TX_ER=>GMII_TX_ER,
                is_arp_packet=>open,
                is_udp_packet=>open,
                test_out=>open,
                udp_data_count(10 downto 0)=>user_rx_size_out(10 downto 0),
                udp_data_valid_out=>user_rx_valid_out,
                user_rx_data_out(7 downto 0)=>user_rx_data_out(7 downto 0));
   
   XLXI_250 : INV
      port map (I=>reset_n,
                O=>reset);
   
end BEHAVIORAL;


