-- Author: Ryan Rivera, FNAL

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

entity user_addrs_mux is
	port (
		user_addrs : in std_logic_vector(7 downto 0);	  
		user_length : in std_logic_vector(10 downto 0);
		test_mode : in std_logic;				
		
		udp_tx_length : out std_logic_vector(10 downto 0);
		
		addrs_out :	out std_logic_vector(7 downto 0)
	) ;
end;


architecture user_addrs_mux_arch of user_addrs_mux is
begin				  
	
	
	process(test_mode,user_addrs,user_length)
	begin
		if test_mode = '1' then
			addrs_out <= x"03";		  
			udp_tx_length <=  "000" & x"05";	 -- "000" & x"05"; -- "101" & x"C0";	 -- range: 0 to x5C0 (1472) 
		else
			addrs_out <= user_addrs;  
			udp_tx_length <= user_length;
		end if;				   
	end process;
end user_addrs_mux_arch;				