setMode -bs
setMode -bs
setCable -port auto
Identify 
identifyMPM 
assignFile -p 1 -file "C:/Documents and Settings/rrivera/Desktop/CAPTAN FIRMWARE/dig_mac_GEL-CAPTAN-J1_1/dig_mac_4GEL/top_level.bit"
Program -p 1 -defaultVersion 0 
setMode -bs
deleteDevice -position 1
setMode -ss
setMode -sm
setMode -hw140
setMode -spi
setMode -acecf
setMode -acempm
setMode -pff
setMode -bs
