--------------------------------------------------------------------------------
-- Copyright (c) 1995-2007 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 9.2.03i
--  \   \         Application : sch2vhdl
--  /   /         Filename : TOP_LEVEL.vhf
-- /___/   /\     Timestamp : 06/12/2008 08:45:39
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: C:\Xilinx_9_2\bin\nt\sch2vhdl.exe -intstyle ise -family virtex4 -flat -suppress -w "C:/Documents and Settings/rrivera/Desktop/CAPTAN FIRMWARE/dig_mac_GEL-CAPTAN-J1_1/dig_mac_4GEL/TOP_LEVEL.sch" TOP_LEVEL.vhf
--Design Name: TOP_LEVEL
--Device: virtex4
--Purpose:
--    This vhdl netlist is translated from an ECS schematic. It can be 
--    synthesis and simulted, but it should not be modified. 
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity OBUF8_MXILINX_TOP_LEVEL is
   port ( I : in    std_logic_vector (7 downto 0); 
          O : out   std_logic_vector (7 downto 0));
end OBUF8_MXILINX_TOP_LEVEL;

architecture BEHAVIORAL of OBUF8_MXILINX_TOP_LEVEL is
   attribute IOSTANDARD  : string ;
   attribute CAPACITANCE : string ;
   attribute SLEW        : string ;
   attribute DRIVE       : string ;
   attribute BOX_TYPE    : string ;
   component OBUF
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute IOSTANDARD of OBUF : component is "DEFAULT";
   attribute CAPACITANCE of OBUF : component is "DONT_CARE";
   attribute SLEW of OBUF : component is "SLOW";
   attribute DRIVE of OBUF : component is "12";
   attribute BOX_TYPE of OBUF : component is "BLACK_BOX";
   
begin
   I_36_30 : OBUF
      port map (I=>I(0),
                O=>O(0));
   
   I_36_31 : OBUF
      port map (I=>I(1),
                O=>O(1));
   
   I_36_32 : OBUF
      port map (I=>I(2),
                O=>O(2));
   
   I_36_33 : OBUF
      port map (I=>I(3),
                O=>O(3));
   
   I_36_34 : OBUF
      port map (I=>I(7),
                O=>O(7));
   
   I_36_35 : OBUF
      port map (I=>I(6),
                O=>O(6));
   
   I_36_36 : OBUF
      port map (I=>I(5),
                O=>O(5));
   
   I_36_37 : OBUF
      port map (I=>I(4),
                O=>O(4));
   
end BEHAVIORAL;



library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity IBUF8_MXILINX_TOP_LEVEL is
   port ( I : in    std_logic_vector (7 downto 0); 
          O : out   std_logic_vector (7 downto 0));
end IBUF8_MXILINX_TOP_LEVEL;

architecture BEHAVIORAL of IBUF8_MXILINX_TOP_LEVEL is
   attribute IOSTANDARD  : string ;
   attribute CAPACITANCE : string ;
   attribute BOX_TYPE    : string ;
   component IBUF
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute IOSTANDARD of IBUF : component is "DEFAULT";
   attribute CAPACITANCE of IBUF : component is "DONT_CARE";
   attribute BOX_TYPE of IBUF : component is "BLACK_BOX";
   
begin
   I_36_30 : IBUF
      port map (I=>I(4),
                O=>O(4));
   
   I_36_31 : IBUF
      port map (I=>I(5),
                O=>O(5));
   
   I_36_32 : IBUF
      port map (I=>I(6),
                O=>O(6));
   
   I_36_33 : IBUF
      port map (I=>I(7),
                O=>O(7));
   
   I_36_34 : IBUF
      port map (I=>I(3),
                O=>O(3));
   
   I_36_35 : IBUF
      port map (I=>I(2),
                O=>O(2));
   
   I_36_36 : IBUF
      port map (I=>I(1),
                O=>O(1));
   
   I_36_37 : IBUF
      port map (I=>I(0),
                O=>O(0));
   
end BEHAVIORAL;



library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity TOP_LEVEL is
   port ( GMII_RXD_0    : in    std_logic_vector (7 downto 0); 
          GMII_RX_CLK_0 : in    std_logic; 
          GMII_RX_DV_0  : in    std_logic; 
          GMII_RX_ER_0  : in    std_logic; 
          PHY_RESET     : in    std_logic; 
          debug_port0   : out   std_logic; 
          debug_port1   : out   std_logic; 
          GTX_CLK_0     : out   std_logic; 
          PHY_TXD       : out   std_logic_vector (7 downto 0); 
          PHY_TXEN      : out   std_logic; 
          PHY_TXER      : out   std_logic);
end TOP_LEVEL;

architecture BEHAVIORAL of TOP_LEVEL is
   attribute IOSTANDARD  : string ;
   attribute CAPACITANCE : string ;
   attribute BOX_TYPE    : string ;
   attribute HU_SET      : string ;
   attribute SLEW        : string ;
   attribute DRIVE       : string ;
   signal crc_err_flag                         : std_logic;
   signal data_fifo_empty                      : std_logic;
   signal data_fifo_full                       : std_logic;
   signal data_fifo_rden                       : std_logic;
   signal data_fifo_rden_en                    : std_logic;
   signal data_fifo_read_enable                : std_logic;
   signal data_fifo_wren                       : std_logic;
   signal data_fifo_wrerr                      : std_logic;
   signal data_fifo_wr_data                    : std_logic_vector (7 downto 0);
   signal final_byte_data_wren                 : std_logic;
   signal gec_rx_ctl_mux_sel                   : std_logic;
   signal gec_rx_ctl_stat_out                  : std_logic_vector (7 downto 0);
   signal gec_user_addrs                       : std_logic_vector (7 downto 0);
   signal gec_user_busy                        : std_logic;
   signal gec_user_crc_err                     : std_logic;
   signal gec_user_rx_data_out                 : std_logic_vector (7 downto 0);
   signal gec_user_rx_size_out                 : std_logic_vector (10 downto 0);
   signal gec_user_rx_valid_out                : std_logic;
   signal gec_user_trigger                     : std_logic;
   signal gec_user_tx_data_in                  : std_logic_vector (7 downto 0);
   signal gec_user_tx_enable_out               : std_logic;
   signal gec_user_tx_size_in                  : std_logic_vector (10 downto 0);
   signal GMII_RXD_0_sig                       : std_logic_vector (7 downto 0);
   signal GMII_RX_CLK_0_sig                    : std_logic;
   signal GMII_RX_DV_0_sig                     : std_logic;
   signal GMII_RX_ER_0_sig                     : std_logic;
   signal GTX_CLK_0_sig                        : std_logic;
   signal info_fifo_empty                      : std_logic;
   signal info_fifo_rden                       : std_logic;
   signal info_fifo_rd_data                    : std_logic_vector (15 downto 0);
   signal info_fifo_wren                       : std_logic;
   signal info_fifo_wr_data                    : std_logic_vector (15 downto 0);
   signal PHY_TXD_sig                          : std_logic_vector (7 downto 0);
   signal PHY_TXEN_sig                         : std_logic;
   signal PHY_TXER_sig                         : std_logic;
   signal reset                                : std_logic;
   signal reset_n                              : std_logic;
   signal rx_size_err_flag                     : std_logic;
   signal XLXN_342                             : std_logic;
   signal XLXN_442                             : std_logic;
   signal XLXN_443                             : std_logic;
   signal XLXN_460                             : std_logic;
   signal XLXN_462                             : std_logic;
   signal XLXI_2418_data_fifo_rderr_openSignal : std_logic;
   signal XLXI_2418_info_fifo_rderr_openSignal : std_logic;
   component IBUF
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute IOSTANDARD of IBUF : component is "DEFAULT";
   attribute CAPACITANCE of IBUF : component is "DONT_CARE";
   attribute BOX_TYPE of IBUF : component is "BLACK_BOX";
   
   component IBUF8_MXILINX_TOP_LEVEL
      port ( I : in    std_logic_vector (7 downto 0); 
             O : out   std_logic_vector (7 downto 0));
   end component;
   
   component OBUF
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute IOSTANDARD of OBUF : component is "DEFAULT";
   attribute CAPACITANCE of OBUF : component is "DONT_CARE";
   attribute SLEW of OBUF : component is "SLOW";
   attribute DRIVE of OBUF : component is "12";
   attribute BOX_TYPE of OBUF : component is "BLACK_BOX";
   
   component OBUF8_MXILINX_TOP_LEVEL
      port ( I : in    std_logic_vector (7 downto 0); 
             O : out   std_logic_vector (7 downto 0));
   end component;
   
   component IBUFG
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute IOSTANDARD of IBUFG : component is "DEFAULT";
   attribute CAPACITANCE of IBUFG : component is "DONT_CARE";
   attribute BOX_TYPE of IBUFG : component is "BLACK_BOX";
   
   component gigabit_ethernet_controller
      port ( user_tx_data_in    : in    std_logic_vector (7 downto 0); 
             user_tx_size_in    : in    std_logic_vector (10 downto 0); 
             user_addrs         : in    std_logic_vector (7 downto 0); 
             GMII_RXD           : in    std_logic_vector (7 downto 0); 
             GMII_RX_DV         : in    std_logic; 
             GMII_RX_ER         : in    std_logic; 
             GMII_RX_CLK        : in    std_logic; 
             user_test_mode     : in    std_logic; 
             user_trigger       : in    std_logic; 
             reset_n            : in    std_logic; 
             user_rx_size_out   : out   std_logic_vector (10 downto 0); 
             GMII_TX_EN         : out   std_logic; 
             GMII_TX_ER         : out   std_logic; 
             GTX_CLK            : out   std_logic; 
             user_busy          : out   std_logic; 
             user_rx_valid_out  : out   std_logic; 
             user_tx_enable_out : out   std_logic; 
             user_rx_data_out   : out   std_logic_vector (7 downto 0); 
             GMII_TXD           : out   std_logic_vector (7 downto 0); 
             crc_err            : out   std_logic);
   end component;
   
   component GEC_RX_CTL_0
      port ( block_en              : in    std_logic; 
             clock                 : in    std_logic; 
             data_fifo_full        : in    std_logic; 
             data_fifo_wrerr       : in    std_logic; 
             gec_user_crc_err      : in    std_logic; 
             gec_user_rx_valid_out : in    std_logic; 
             reset_n               : in    std_logic; 
             gec_user_rx_size_out  : in    std_logic_vector (10 downto 0); 
             crc_err_flag          : out   std_logic; 
             data_fifo_wren        : out   std_logic; 
             gec_rx_ctl_mux_sel    : out   std_logic; 
             info_fifo_wren        : out   std_logic; 
             rx_size_err_flag      : out   std_logic; 
             gec_rx_ctl_stat_out   : out   std_logic_vector (7 downto 0); 
             info_fifo_wr_data     : out   std_logic_vector (15 downto 0));
   end component;
   
   component GEC_TX_CTL_0
      port ( gec_user_busy          : in    std_logic; 
             gec_user_tx_enable_out : in    std_logic; 
             data_fifo_empty        : in    std_logic; 
             data_fifo_rderr        : in    std_logic; 
             info_fifo_rd_data      : in    std_logic_vector (15 downto 0); 
             info_fifo_empty        : in    std_logic; 
             info_fifo_rderr        : in    std_logic; 
             clk                    : in    std_logic; 
             reset_n                : in    std_logic; 
             block_en               : in    std_logic; 
             gec_user_trigger       : out   std_logic; 
             gec_user_tx_size_in    : out   std_logic_vector (10 downto 0); 
             info_fifo_rden         : out   std_logic; 
             data_fifo_rden_en      : out   std_logic; 
             data_fifo_rden         : out   std_logic);
   end component;
   
   component VCC
      port ( P : out   std_logic);
   end component;
   attribute BOX_TYPE of VCC : component is "BLACK_BOX";
   
   component GEC_RX_DATA_MUX
      port ( in0    : in    std_logic_vector (7 downto 0); 
             in1    : in    std_logic_vector (7 downto 0); 
             muxout : out   std_logic_vector (7 downto 0); 
             sel    : in    std_logic);
   end component;
   
   component OR2
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of OR2 : component is "BLACK_BOX";
   
   component AND2
      port ( I0 : in    std_logic; 
             I1 : in    std_logic; 
             O  : out   std_logic);
   end component;
   attribute BOX_TYPE of AND2 : component is "BLACK_BOX";
   
   component GND
      port ( G : out   std_logic);
   end component;
   attribute BOX_TYPE of GND : component is "BLACK_BOX";
   
   component DATA_FIFO_0
      port ( clk   : in    std_logic; 
             srst  : in    std_logic; 
             rd_en : in    std_logic; 
             wr_en : in    std_logic; 
             empty : out   std_logic; 
             full  : out   std_logic; 
             dout  : out   std_logic_vector (7 downto 0); 
             din   : in    std_logic_vector (7 downto 0));
   end component;
   
   component INFO_FIFO_0
      port ( wr_en : in    std_logic; 
             clk   : in    std_logic; 
             srst  : in    std_logic; 
             din   : in    std_logic_vector (15 downto 0); 
             rd_en : in    std_logic; 
             dout  : out   std_logic_vector (15 downto 0); 
             empty : out   std_logic; 
             full  : out   std_logic);
   end component;
   
   component INV
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute BOX_TYPE of INV : component is "BLACK_BOX";
   
   attribute HU_SET of XLXI_180 : label is "XLXI_180_0";
   attribute HU_SET of XLXI_195 : label is "XLXI_195_1";
begin
   XLXI_178 : IBUF
      port map (I=>GMII_RX_DV_0,
                O=>GMII_RX_DV_0_sig);
   
   XLXI_179 : IBUF
      port map (I=>GMII_RX_ER_0,
                O=>GMII_RX_ER_0_sig);
   
   XLXI_180 : IBUF8_MXILINX_TOP_LEVEL
      port map (I(7 downto 0)=>GMII_RXD_0(7 downto 0),
                O(7 downto 0)=>GMII_RXD_0_sig(7 downto 0));
   
   XLXI_192 : OBUF
      port map (I=>GTX_CLK_0_sig,
                O=>GTX_CLK_0);
   
   XLXI_193 : OBUF
      port map (I=>PHY_TXER_sig,
                O=>PHY_TXER);
   
   XLXI_194 : OBUF
      port map (I=>PHY_TXEN_sig,
                O=>PHY_TXEN);
   
   XLXI_195 : OBUF8_MXILINX_TOP_LEVEL
      port map (I(7 downto 0)=>PHY_TXD_sig(7 downto 0),
                O(7 downto 0)=>PHY_TXD(7 downto 0));
   
   XLXI_237 : IBUFG
      port map (I=>GMII_RX_CLK_0,
                O=>GMII_RX_CLK_0_sig);
   
   XLXI_274 : gigabit_ethernet_controller
      port map (GMII_RXD(7 downto 0)=>GMII_RXD_0_sig(7 downto 0),
                GMII_RX_CLK=>GMII_RX_CLK_0_sig,
                GMII_RX_DV=>GMII_RX_DV_0_sig,
                GMII_RX_ER=>GMII_RX_ER_0_sig,
                reset_n=>reset_n,
                user_addrs(7 downto 0)=>gec_user_addrs(7 downto 0),
                user_test_mode=>XLXN_460,
                user_trigger=>gec_user_trigger,
                user_tx_data_in(7 downto 0)=>gec_user_tx_data_in(7 downto 0),
                user_tx_size_in(10 downto 0)=>gec_user_tx_size_in(10 downto 0),
                crc_err=>gec_user_crc_err,
                GMII_TXD(7 downto 0)=>PHY_TXD_sig(7 downto 0),
                GMII_TX_EN=>PHY_TXEN_sig,
                GMII_TX_ER=>PHY_TXER_sig,
                GTX_CLK=>GTX_CLK_0_sig,
                user_busy=>gec_user_busy,
                user_rx_data_out(7 downto 0)=>gec_user_rx_data_out(7 downto 0),
                user_rx_size_out(10 downto 0)=>gec_user_rx_size_out(10 downto 0),
                user_rx_valid_out=>gec_user_rx_valid_out,
                user_tx_enable_out=>gec_user_tx_enable_out);
   
   XLXI_2417 : GEC_RX_CTL_0
      port map (block_en=>XLXN_342,
                clock=>GMII_RX_CLK_0_sig,
                data_fifo_full=>data_fifo_full,
                data_fifo_wrerr=>data_fifo_wrerr,
                gec_user_crc_err=>gec_user_crc_err,
                gec_user_rx_size_out(10 downto 0)=>gec_user_rx_size_out(10 
            downto 0),
                gec_user_rx_valid_out=>gec_user_rx_valid_out,
                reset_n=>reset_n,
                crc_err_flag=>crc_err_flag,
                data_fifo_wren=>final_byte_data_wren,
                gec_rx_ctl_mux_sel=>gec_rx_ctl_mux_sel,
                gec_rx_ctl_stat_out(7 downto 0)=>gec_rx_ctl_stat_out(7 downto 0),
                info_fifo_wren=>info_fifo_wren,
                info_fifo_wr_data(15 downto 0)=>info_fifo_wr_data(15 downto 0),
                rx_size_err_flag=>rx_size_err_flag);
   
   XLXI_2418 : GEC_TX_CTL_0
      port map (block_en=>XLXN_443,
                clk=>GMII_RX_CLK_0_sig,
                data_fifo_empty=>data_fifo_empty,
                data_fifo_rderr=>XLXI_2418_data_fifo_rderr_openSignal,
                gec_user_busy=>gec_user_busy,
                gec_user_tx_enable_out=>gec_user_tx_enable_out,
                info_fifo_empty=>info_fifo_empty,
                info_fifo_rderr=>XLXI_2418_info_fifo_rderr_openSignal,
                info_fifo_rd_data(15 downto 0)=>info_fifo_rd_data(15 downto 0),
                reset_n=>reset_n,
                data_fifo_rden=>data_fifo_rden,
                data_fifo_rden_en=>data_fifo_rden_en,
                gec_user_trigger=>gec_user_trigger,
                gec_user_tx_size_in(10 downto 0)=>gec_user_tx_size_in(10 downto 
            0),
                info_fifo_rden=>info_fifo_rden);
   
   XLXI_2422 : VCC
      port map (P=>XLXN_342);
   
   XLXI_2425 : GEC_RX_DATA_MUX
      port map (in0(7 downto 0)=>gec_user_rx_data_out(7 downto 0),
                in1(7 downto 0)=>gec_rx_ctl_stat_out(7 downto 0),
                sel=>gec_rx_ctl_mux_sel,
                muxout(7 downto 0)=>data_fifo_wr_data(7 downto 0));
   
   XLXI_2437 : OR2
      port map (I0=>data_fifo_rden,
                I1=>gec_user_tx_enable_out,
                O=>XLXN_442);
   
   XLXI_2438 : AND2
      port map (I0=>data_fifo_rden_en,
                I1=>XLXN_442,
                O=>data_fifo_read_enable);
   
   XLXI_2448 : VCC
      port map (P=>gec_user_addrs(1));
   
   XLXI_2449 : GND
      port map (G=>gec_user_addrs(2));
   
   XLXI_2450 : VCC
      port map (P=>gec_user_addrs(0));
   
   XLXI_2454 : GND
      port map (G=>gec_user_addrs(3));
   
   XLXI_2455 : GND
      port map (G=>gec_user_addrs(4));
   
   XLXI_2456 : GND
      port map (G=>gec_user_addrs(5));
   
   XLXI_2457 : GND
      port map (G=>gec_user_addrs(6));
   
   XLXI_2458 : GND
      port map (G=>gec_user_addrs(7));
   
   XLXI_2471 : DATA_FIFO_0
      port map (clk=>GMII_RX_CLK_0_sig,
                din(7 downto 0)=>data_fifo_wr_data(7 downto 0),
                rd_en=>data_fifo_read_enable,
                srst=>reset,
                wr_en=>data_fifo_wren,
                dout(7 downto 0)=>gec_user_tx_data_in(7 downto 0),
                empty=>data_fifo_empty,
                full=>open);
   
   XLXI_2473 : INFO_FIFO_0
      port map (clk=>GMII_RX_CLK_0_sig,
                din(15 downto 0)=>info_fifo_wr_data(15 downto 0),
                rd_en=>info_fifo_rden,
                srst=>reset,
                wr_en=>info_fifo_wren,
                dout(15 downto 0)=>info_fifo_rd_data(15 downto 0),
                empty=>info_fifo_empty,
                full=>open);
   
   XLXI_2477 : OBUF
      port map (I=>crc_err_flag,
                O=>debug_port0);
   
   XLXI_2478 : OBUF
      port map (I=>XLXN_462,
                O=>debug_port1);
   
   XLXI_2480 : VCC
      port map (P=>XLXN_443);
   
   XLXI_2482 : IBUF
      port map (I=>PHY_RESET,
                O=>reset_n);
   
   XLXI_2483 : OR2
      port map (I0=>final_byte_data_wren,
                I1=>gec_user_rx_valid_out,
                O=>data_fifo_wren);
   
   XLXI_2484 : INV
      port map (I=>reset_n,
                O=>reset);
   
   XLXI_2485 : GND
      port map (G=>XLXN_460);
   
   XLXI_2486 : VCC
      port map (P=>XLXN_462);
   
end BEHAVIORAL;


