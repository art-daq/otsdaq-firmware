VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "virtex4"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL reset_n
        SIGNAL GMII_RX_CLK_0_sig
        SIGNAL GMII_RX_DV_0_sig
        SIGNAL GMII_RX_ER_0_sig
        SIGNAL GMII_RXD_0_sig(7:0)
        SIGNAL GTX_CLK_0_sig
        SIGNAL PHY_TXER_sig
        SIGNAL PHY_TXEN_sig
        SIGNAL PHY_TXD_sig(7:0)
        SIGNAL gec_user_tx_data_in(7:0)
        SIGNAL gec_user_addrs(7:0)
        SIGNAL GMII_RX_CLK_0
        SIGNAL GMII_RX_DV_0
        SIGNAL GMII_RX_ER_0
        SIGNAL GMII_RXD_0(7:0)
        SIGNAL PHY_TXER
        SIGNAL PHY_TXEN
        SIGNAL GTX_CLK_0
        SIGNAL PHY_TXD(7:0)
        SIGNAL gec_user_crc_err
        SIGNAL gec_user_rx_data_out(7:0)
        SIGNAL gec_user_rx_valid_out
        SIGNAL gec_user_rx_size_out(10:0)
        SIGNAL gec_user_busy
        SIGNAL gec_user_tx_enable_out
        SIGNAL gec_user_trigger
        SIGNAL gec_user_tx_size_in(10:0)
        SIGNAL gec_user_addrs(0)
        SIGNAL gec_user_addrs(1)
        SIGNAL gec_user_addrs(2)
        SIGNAL gec_user_addrs(3)
        SIGNAL gec_user_addrs(4)
        SIGNAL gec_user_addrs(5)
        SIGNAL gec_user_addrs(6)
        SIGNAL gec_user_addrs(7)
        SIGNAL data_fifo_wr_data(7:0)
        SIGNAL gec_rx_ctl_stat_out(7:0)
        SIGNAL info_fifo_wr_data(15:0)
        SIGNAL gec_rx_ctl_mux_sel
        SIGNAL rx_size_err_flag
        SIGNAL data_fifo_wren
        SIGNAL info_fifo_wren
        SIGNAL crc_err_flag
        SIGNAL data_fifo_full
        SIGNAL data_fifo_wrerr
        SIGNAL XLXN_342
        SIGNAL data_fifo_empty
        SIGNAL info_fifo_rd_data(15:0)
        SIGNAL info_fifo_empty
        SIGNAL info_fifo_rden
        SIGNAL data_fifo_rden
        SIGNAL data_fifo_rden_en
        SIGNAL XLXN_442
        SIGNAL data_fifo_read_enable
        SIGNAL debug_port1
        SIGNAL debug_port0
        SIGNAL PHY_RESET
        SIGNAL XLXN_443
        SIGNAL final_byte_data_wren
        SIGNAL reset
        SIGNAL XLXN_460
        SIGNAL XLXN_462
        PORT Input GMII_RX_CLK_0
        PORT Input GMII_RX_DV_0
        PORT Input GMII_RX_ER_0
        PORT Input GMII_RXD_0(7:0)
        PORT Output PHY_TXER
        PORT Output PHY_TXEN
        PORT Output GTX_CLK_0
        PORT Output PHY_TXD(7:0)
        PORT Output debug_port1
        PORT Output debug_port0
        PORT Input PHY_RESET
        BEGIN BLOCKDEF ibuf
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF ibufg
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF obuf
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 0 -32 64 -32 
            LINE N 224 -32 128 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF ibuf8
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 128 -44 224 -20 
            LINE N 224 -32 128 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF obuf8
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            RECTANGLE N 0 -44 64 -20 
            RECTANGLE N 128 -44 224 -20 
        END BLOCKDEF
        BEGIN BLOCKDEF gigabit_ethernet_controller
            TIMESTAMP 2007 12 5 22 21 42
            LINE N 64 208 0 208 
            RECTANGLE N 0 260 64 284 
            LINE N 64 272 0 272 
            LINE N 656 208 720 208 
            BEGIN LINE N 116 -220 600 -220 
                LINESTYLE Dash
            END LINE
            RECTANGLE N 64 -704 656 648 
            LINE N 64 -160 0 -160 
            BEGIN LINE N 112 -108 596 -108 
                LINESTYLE Dash
            END LINE
            LINE N 64 -544 0 -544 
            LINE N 64 -480 0 -480 
            LINE N 64 -416 0 -416 
            LINE N 656 -544 720 -544 
            LINE N 656 -480 720 -480 
            LINE N 656 -416 720 -416 
            RECTANGLE N 656 -620 720 -596 
            LINE N 656 -608 720 -608 
            RECTANGLE N 0 -620 64 -596 
            LINE N 64 -608 0 -608 
            LINE N 64 144 0 144 
            LINE N 656 144 720 144 
            RECTANGLE N 0 468 64 492 
            LINE N 64 480 0 480 
            RECTANGLE N 0 532 64 556 
            LINE N 64 544 0 544 
            RECTANGLE N 656 468 720 492 
            LINE N 656 480 720 480 
            RECTANGLE N 656 532 720 556 
            LINE N 656 544 720 544 
            LINE N 656 416 720 416 
            LINE N 656 352 720 352 
        END BLOCKDEF
        BEGIN BLOCKDEF gnd
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -64 64 -96 
            LINE N 76 -48 52 -48 
            LINE N 68 -32 60 -32 
            LINE N 88 -64 40 -64 
            LINE N 64 -64 64 -80 
            LINE N 64 -128 64 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF vcc
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -32 64 -64 
            LINE N 64 0 64 -32 
            LINE N 96 -64 32 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF GEC_RX_CTL_0
            TIMESTAMP 2008 6 11 15 42 18
            RECTANGLE N 64 -512 704 240 
            LINE N 64 -480 0 -480 
            LINE N 64 -416 0 -416 
            RECTANGLE N 0 -364 64 -340 
            LINE N 64 -352 0 -352 
            LINE N 64 -192 0 -192 
            LINE N 64 -128 0 -128 
            LINE N 704 -480 768 -480 
            LINE N 704 -352 768 -352 
            RECTANGLE N 704 -300 768 -276 
            LINE N 704 -288 768 -288 
            LINE N 704 -112 768 -112 
            LINE N 704 -48 768 -48 
            LINE N 64 144 0 144 
            LINE N 64 208 0 208 
            LINE N 64 80 0 80 
            RECTANGLE N 704 132 768 156 
            LINE N 704 144 768 144 
            LINE N 704 208 768 208 
        END BLOCKDEF
        BEGIN BLOCKDEF GEC_TX_CTL_0
            TIMESTAMP 2008 6 10 16 35 20
            RECTANGLE N 64 -640 672 136 
            LINE N 64 -608 0 -608 
            LINE N 64 -544 0 -544 
            LINE N 64 -368 0 -368 
            LINE N 64 -432 0 -432 
            RECTANGLE N 0 -268 64 -244 
            LINE N 64 -256 0 -256 
            LINE N 64 -192 0 -192 
            LINE N 64 -128 0 -128 
            LINE N 64 112 0 112 
            LINE N 64 48 0 48 
            LINE N 64 -16 0 -16 
            LINE N 672 -608 736 -608 
            RECTANGLE N 672 -556 736 -532 
            LINE N 672 -544 736 -544 
            LINE N 672 -336 736 -336 
            LINE N 672 -80 736 -80 
            LINE N 672 -144 736 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF GEC_RX_DATA_MUX
            TIMESTAMP 2008 6 10 16 29 1
            LINE N 64 -200 64 -12 
            LINE N 64 -208 64 -196 
            LINE N 64 -208 320 -156 
            LINE N 320 -156 320 -56 
            RECTANGLE N 0 -156 64 -132 
            LINE N 64 -144 0 -144 
            RECTANGLE N 0 -92 64 -68 
            LINE N 64 -80 0 -80 
            RECTANGLE N 320 -124 384 -100 
            LINE N 320 -112 384 -112 
            LINE N 320 -56 64 -12 
            LINE N 176 24 176 -32 
            LINE N 96 32 176 32 
            LINE N 176 32 176 24 
        END BLOCKDEF
        BEGIN BLOCKDEF or2
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 28 -224 204 -48 112 -48 192 -96 
            ARC N -40 -152 72 -40 48 -48 48 -144 
            LINE N 112 -144 48 -144 
            ARC N 28 -144 204 32 192 -96 112 -144 
            LINE N 112 -48 48 -48 
        END BLOCKDEF
        BEGIN BLOCKDEF and2
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 144 -48 64 -48 
            LINE N 64 -144 144 -144 
            LINE N 64 -48 64 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF DATA_FIFO_0
            TIMESTAMP 2008 6 10 19 14 22
            RECTANGLE N 64 -320 320 68 
            LINE N 64 48 0 48 
            LINE N 64 -16 0 -16 
            LINE N 64 -80 0 -80 
            LINE N 64 -144 0 -144 
            LINE N 304 -96 368 -96 
            LINE N 304 32 368 32 
            RECTANGLE N 320 -300 384 -276 
            LINE N 320 -288 384 -288 
            RECTANGLE N 0 -300 64 -276 
            LINE N 64 -288 0 -288 
        END BLOCKDEF
        BEGIN BLOCKDEF INFO_FIFO_0
            TIMESTAMP 2008 6 10 19 16 26
            RECTANGLE N 64 -320 320 68 
            LINE N 64 -96 0 -96 
            LINE N 64 48 0 48 
            LINE N 64 0 0 0 
            RECTANGLE N 0 -300 64 -276 
            LINE N 64 -288 0 -288 
            LINE N 64 -48 0 -48 
            RECTANGLE N 320 -300 384 -276 
            LINE N 320 -288 384 -288 
            LINE N 320 -128 384 -128 
            LINE N 320 0 384 0 
        END BLOCKDEF
        BEGIN BLOCKDEF inv
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 224 -32 160 -32 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            CIRCLE N 128 -48 160 -16 
        END BLOCKDEF
        BEGIN BLOCK XLXI_274 gigabit_ethernet_controller
            PIN user_tx_data_in(7:0) gec_user_tx_data_in(7:0)
            PIN user_tx_size_in(10:0) gec_user_tx_size_in(10:0)
            PIN user_addrs(7:0) gec_user_addrs(7:0)
            PIN GMII_RXD(7:0) GMII_RXD_0_sig(7:0)
            PIN GMII_RX_DV GMII_RX_DV_0_sig
            PIN GMII_RX_ER GMII_RX_ER_0_sig
            PIN GMII_RX_CLK GMII_RX_CLK_0_sig
            PIN user_test_mode XLXN_460
            PIN user_trigger gec_user_trigger
            PIN reset_n reset_n
            PIN user_rx_size_out(10:0) gec_user_rx_size_out(10:0)
            PIN GMII_TX_EN PHY_TXEN_sig
            PIN GMII_TX_ER PHY_TXER_sig
            PIN GTX_CLK GTX_CLK_0_sig
            PIN user_busy gec_user_busy
            PIN user_rx_valid_out gec_user_rx_valid_out
            PIN user_tx_enable_out gec_user_tx_enable_out
            PIN user_rx_data_out(7:0) gec_user_rx_data_out(7:0)
            PIN GMII_TXD(7:0) PHY_TXD_sig(7:0)
            PIN crc_err gec_user_crc_err
        END BLOCK
        BEGIN BLOCK XLXI_178 ibuf
            PIN I GMII_RX_DV_0
            PIN O GMII_RX_DV_0_sig
        END BLOCK
        BEGIN BLOCK XLXI_179 ibuf
            PIN I GMII_RX_ER_0
            PIN O GMII_RX_ER_0_sig
        END BLOCK
        BEGIN BLOCK XLXI_180 ibuf8
            PIN I(7:0) GMII_RXD_0(7:0)
            PIN O(7:0) GMII_RXD_0_sig(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_237 ibufg
            PIN I GMII_RX_CLK_0
            PIN O GMII_RX_CLK_0_sig
        END BLOCK
        BEGIN BLOCK XLXI_192 obuf
            PIN I GTX_CLK_0_sig
            PIN O GTX_CLK_0
        END BLOCK
        BEGIN BLOCK XLXI_193 obuf
            PIN I PHY_TXER_sig
            PIN O PHY_TXER
        END BLOCK
        BEGIN BLOCK XLXI_194 obuf
            PIN I PHY_TXEN_sig
            PIN O PHY_TXEN
        END BLOCK
        BEGIN BLOCK XLXI_195 obuf8
            PIN I(7:0) PHY_TXD_sig(7:0)
            PIN O(7:0) PHY_TXD(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_2450 vcc
            PIN P gec_user_addrs(0)
        END BLOCK
        BEGIN BLOCK XLXI_2448 vcc
            PIN P gec_user_addrs(1)
        END BLOCK
        BEGIN BLOCK XLXI_2449 gnd
            PIN G gec_user_addrs(2)
        END BLOCK
        BEGIN BLOCK XLXI_2454 gnd
            PIN G gec_user_addrs(3)
        END BLOCK
        BEGIN BLOCK XLXI_2455 gnd
            PIN G gec_user_addrs(4)
        END BLOCK
        BEGIN BLOCK XLXI_2456 gnd
            PIN G gec_user_addrs(5)
        END BLOCK
        BEGIN BLOCK XLXI_2457 gnd
            PIN G gec_user_addrs(6)
        END BLOCK
        BEGIN BLOCK XLXI_2458 gnd
            PIN G gec_user_addrs(7)
        END BLOCK
        BEGIN BLOCK XLXI_2425 GEC_RX_DATA_MUX
            PIN in0(7:0) gec_user_rx_data_out(7:0)
            PIN in1(7:0) gec_rx_ctl_stat_out(7:0)
            PIN muxout(7:0) data_fifo_wr_data(7:0)
            PIN sel gec_rx_ctl_mux_sel
        END BLOCK
        BEGIN BLOCK XLXI_2422 vcc
            PIN P XLXN_342
        END BLOCK
        BEGIN BLOCK XLXI_2417 GEC_RX_CTL_0
            PIN block_en XLXN_342
            PIN clock GMII_RX_CLK_0_sig
            PIN data_fifo_full data_fifo_full
            PIN data_fifo_wrerr data_fifo_wrerr
            PIN gec_user_crc_err gec_user_crc_err
            PIN gec_user_rx_valid_out gec_user_rx_valid_out
            PIN reset_n reset_n
            PIN gec_user_rx_size_out(10:0) gec_user_rx_size_out(10:0)
            PIN crc_err_flag crc_err_flag
            PIN data_fifo_wren final_byte_data_wren
            PIN gec_rx_ctl_mux_sel gec_rx_ctl_mux_sel
            PIN info_fifo_wren info_fifo_wren
            PIN rx_size_err_flag rx_size_err_flag
            PIN gec_rx_ctl_stat_out(7:0) gec_rx_ctl_stat_out(7:0)
            PIN info_fifo_wr_data(15:0) info_fifo_wr_data(15:0)
        END BLOCK
        BEGIN BLOCK XLXI_2418 GEC_TX_CTL_0
            PIN gec_user_busy gec_user_busy
            PIN gec_user_tx_enable_out gec_user_tx_enable_out
            PIN data_fifo_empty data_fifo_empty
            PIN data_fifo_rderr
            PIN info_fifo_rd_data(15:0) info_fifo_rd_data(15:0)
            PIN info_fifo_empty info_fifo_empty
            PIN info_fifo_rderr
            PIN clk GMII_RX_CLK_0_sig
            PIN reset_n reset_n
            PIN block_en XLXN_443
            PIN gec_user_trigger gec_user_trigger
            PIN gec_user_tx_size_in(10:0) gec_user_tx_size_in(10:0)
            PIN info_fifo_rden info_fifo_rden
            PIN data_fifo_rden_en data_fifo_rden_en
            PIN data_fifo_rden data_fifo_rden
        END BLOCK
        BEGIN BLOCK XLXI_2437 or2
            PIN I0 data_fifo_rden
            PIN I1 gec_user_tx_enable_out
            PIN O XLXN_442
        END BLOCK
        BEGIN BLOCK XLXI_2438 and2
            PIN I0 data_fifo_rden_en
            PIN I1 XLXN_442
            PIN O data_fifo_read_enable
        END BLOCK
        BEGIN BLOCK XLXI_2473 INFO_FIFO_0
            PIN wr_en info_fifo_wren
            PIN clk GMII_RX_CLK_0_sig
            PIN srst reset
            PIN din(15:0) info_fifo_wr_data(15:0)
            PIN rd_en info_fifo_rden
            PIN dout(15:0) info_fifo_rd_data(15:0)
            PIN empty info_fifo_empty
            PIN full
        END BLOCK
        BEGIN BLOCK XLXI_2471 DATA_FIFO_0
            PIN clk GMII_RX_CLK_0_sig
            PIN srst reset
            PIN rd_en data_fifo_read_enable
            PIN wr_en data_fifo_wren
            PIN empty data_fifo_empty
            PIN full
            PIN dout(7:0) gec_user_tx_data_in(7:0)
            PIN din(7:0) data_fifo_wr_data(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_2477 obuf
            PIN I crc_err_flag
            PIN O debug_port0
        END BLOCK
        BEGIN BLOCK XLXI_2478 obuf
            PIN I XLXN_462
            PIN O debug_port1
        END BLOCK
        BEGIN BLOCK XLXI_2480 vcc
            PIN P XLXN_443
        END BLOCK
        BEGIN BLOCK XLXI_2482 ibuf
            PIN I PHY_RESET
            PIN O reset_n
        END BLOCK
        BEGIN BLOCK XLXI_2483 or2
            PIN I0 final_byte_data_wren
            PIN I1 gec_user_rx_valid_out
            PIN O data_fifo_wren
        END BLOCK
        BEGIN BLOCK XLXI_2484 inv
            PIN I reset_n
            PIN O reset
        END BLOCK
        BEGIN BLOCK XLXI_2485 gnd
            PIN G XLXN_460
        END BLOCK
        BEGIN BLOCK XLXI_2486 vcc
            PIN P XLXN_462
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 7040 5440
        BEGIN BRANCH GTX_CLK_0_sig
            WIRE 3728 2576 4112 2576
            BEGIN DISPLAY 4112 2576 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXEN_sig
            WIRE 3728 2448 4112 2448
            BEGIN DISPLAY 4112 2448 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXD_sig(7:0)
            WIRE 3728 2384 4112 2384
            BEGIN DISPLAY 4112 2384 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXER_sig
            WIRE 3728 2512 4112 2512
            BEGIN DISPLAY 4112 2512 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RX_DV_0_sig
            WIRE 2576 2448 3008 2448
            BEGIN DISPLAY 2576 2448 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RX_ER_0_sig
            WIRE 2576 2512 3008 2512
            BEGIN DISPLAY 2576 2512 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RX_CLK_0_sig
            WIRE 2576 2576 3008 2576
            BEGIN DISPLAY 2576 2576 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RXD_0_sig(7:0)
            WIRE 2576 2384 3008 2384
            BEGIN DISPLAY 2576 2384 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_274 3008 2992 R0
        END INSTANCE
        BEGIN BRANCH reset_n
            WIRE 2576 2832 3008 2832
            BEGIN DISPLAY 2576 2832 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_trigger
            WIRE 2576 3200 3008 3200
            BEGIN DISPLAY 2576 3200 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_tx_data_in(7:0)
            WIRE 2592 3536 3008 3536
            BEGIN DISPLAY 2592 3536 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_tx_size_in(10:0)
            WIRE 2592 3472 3008 3472
            BEGIN DISPLAY 2592 3472 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_addrs(7:0)
            WIRE 2576 3264 3008 3264
            BEGIN DISPLAY 2576 3264 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RX_CLK_0
            WIRE 944 240 1104 240
        END BRANCH
        BEGIN BRANCH GMII_RX_DV_0
            WIRE 944 304 1104 304
        END BRANCH
        BEGIN BRANCH GMII_RX_ER_0
            WIRE 944 368 1104 368
        END BRANCH
        INSTANCE XLXI_178 1104 336 R0
        INSTANCE XLXI_179 1104 400 R0
        BEGIN BRANCH GMII_RXD_0(7:0)
            WIRE 944 512 1104 512
        END BRANCH
        INSTANCE XLXI_180 1104 544 R0
        BEGIN BRANCH GMII_RX_CLK_0_sig
            WIRE 1328 240 1632 240
            BEGIN DISPLAY 1632 240 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RX_DV_0_sig
            WIRE 1328 304 1632 304
            BEGIN DISPLAY 1632 304 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RX_ER_0_sig
            WIRE 1328 368 1632 368
            BEGIN DISPLAY 1632 368 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RXD_0_sig(7:0)
            WIRE 1328 512 1632 512
            BEGIN DISPLAY 1632 512 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_237 1104 272 R0
        IOMARKER 944 304 GMII_RX_DV_0 R180 28
        IOMARKER 944 368 GMII_RX_ER_0 R180 28
        IOMARKER 944 240 GMII_RX_CLK_0 R180 28
        IOMARKER 944 512 GMII_RXD_0(7:0) R180 28
        BEGIN BRANCH PHY_TXER
            WIRE 6096 1248 6288 1248
        END BRANCH
        BEGIN BRANCH PHY_TXEN
            WIRE 6096 1312 6288 1312
        END BRANCH
        BEGIN BRANCH GTX_CLK_0
            WIRE 6096 1184 6288 1184
        END BRANCH
        INSTANCE XLXI_192 5872 1216 R0
        INSTANCE XLXI_193 5872 1280 R0
        INSTANCE XLXI_194 5872 1344 R0
        BEGIN BRANCH PHY_TXD(7:0)
            WIRE 6096 1456 6288 1456
        END BRANCH
        INSTANCE XLXI_195 5872 1488 R0
        BEGIN BRANCH GTX_CLK_0_sig
            WIRE 5568 1184 5872 1184
            BEGIN DISPLAY 5568 1184 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXER_sig
            WIRE 5568 1248 5872 1248
            BEGIN DISPLAY 5568 1248 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXEN_sig
            WIRE 5568 1312 5872 1312
            BEGIN DISPLAY 5568 1312 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PHY_TXD_sig(7:0)
            WIRE 5568 1456 5872 1456
            BEGIN DISPLAY 5568 1456 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        IOMARKER 6288 1248 PHY_TXER R0 28
        IOMARKER 6288 1312 PHY_TXEN R0 28
        IOMARKER 6288 1184 GTX_CLK_0 R0 28
        IOMARKER 6288 1456 PHY_TXD(7:0) R0 28
        BEGIN DISPLAY 6032 300 TEXT "Designed by Ryan Rivera"
            FONT 48 "Arial"
        END DISPLAY
        BEGIN DISPLAY 6128 372 TEXT rrivera@fnal.gov
            FONT 48 "Arial"
        END DISPLAY
        RECTANGLE N 5852 124 6768 556 
        RECTANGLE N 5868 148 6752 536 
        BEGIN BRANCH gec_user_rx_valid_out
            WIRE 3728 3408 3968 3408
            BEGIN DISPLAY 3968 3408 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_crc_err
            WIRE 3728 3344 3968 3344
            BEGIN DISPLAY 3968 3344 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_tx_enable_out
            WIRE 3728 3200 3968 3200
            BEGIN DISPLAY 3968 3200 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_busy
            WIRE 3728 3136 3968 3136
            BEGIN DISPLAY 3968 3136 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_rx_size_out(10:0)
            WIRE 3728 3472 3968 3472
            BEGIN DISPLAY 3968 3472 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_rx_data_out(7:0)
            WIRE 3728 3536 3968 3536
            BEGIN DISPLAY 3968 3536 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_addrs(0)
            WIRE 1248 3008 1840 3008
            BEGIN DISPLAY 1840 3008 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_2450 1248 3072 R270
        BEGIN BRANCH gec_user_addrs(1)
            WIRE 1248 3104 1840 3104
            BEGIN DISPLAY 1840 3104 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_2448 1248 3168 R270
        BEGIN BRANCH gec_user_addrs(2)
            WIRE 1248 3200 1840 3200
            BEGIN DISPLAY 1840 3200 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_2449 1120 3136 R90
        BEGIN BRANCH gec_user_addrs(3)
            WIRE 1248 3296 1840 3296
            BEGIN DISPLAY 1840 3296 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_2454 1120 3232 R90
        BEGIN BRANCH gec_user_addrs(4)
            WIRE 1248 3392 1840 3392
            BEGIN DISPLAY 1840 3392 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_2455 1120 3328 R90
        BEGIN BRANCH gec_user_addrs(5)
            WIRE 1248 3488 1840 3488
            BEGIN DISPLAY 1840 3488 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_2456 1120 3424 R90
        BEGIN BRANCH gec_user_addrs(6)
            WIRE 1248 3584 1840 3584
            BEGIN DISPLAY 1840 3584 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_2457 1120 3520 R90
        BEGIN BRANCH gec_user_addrs(7)
            WIRE 1248 3680 1840 3680
            BEGIN DISPLAY 1840 3680 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_2458 1120 3616 R90
        BEGIN BRANCH debug_port1
            WIRE 6032 2720 6224 2720
        END BRANCH
        BEGIN BRANCH debug_port0
            WIRE 6032 2656 6224 2656
        END BRANCH
        INSTANCE XLXI_2477 5808 2688 R0
        IOMARKER 6224 2720 debug_port1 R0 28
        IOMARKER 6224 2656 debug_port0 R0 28
        BEGIN BRANCH crc_err_flag
            WIRE 5552 2656 5808 2656
            BEGIN DISPLAY 5552 2656 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_2478 5808 2752 R0
        BEGIN BRANCH PHY_RESET
            WIRE 944 752 1104 752
        END BRANCH
        BEGIN BRANCH reset_n
            WIRE 1328 752 1632 752
            BEGIN DISPLAY 1632 752 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        IOMARKER 944 752 PHY_RESET R180 28
        INSTANCE XLXI_2482 1104 784 R0
        INSTANCE XLXI_2484 1616 1008 R0
        BEGIN BRANCH reset_n
            WIRE 1408 976 1616 976
            BEGIN DISPLAY 1408 976 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 1840 976 2112 976
            BEGIN DISPLAY 2112 976 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_460
            WIRE 2752 3136 3008 3136
        END BRANCH
        INSTANCE XLXI_2485 2624 3072 R90
        BEGIN BRANCH rx_size_err_flag
            WIRE 5232 2720 5488 2720
            BEGIN DISPLAY 5232 2720 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_462
            WIRE 5680 2720 5808 2720
        END BRANCH
        INSTANCE XLXI_2486 5680 2784 R270
    END SHEET
    BEGIN SHEET 2 7040 5440
        BEGIN INSTANCE XLXI_2425 5008 1632 R0
        END INSTANCE
        INSTANCE XLXI_2422 3200 1552 R270
        BEGIN INSTANCE XLXI_2417 3440 1408 R0
        END INSTANCE
        BEGIN BRANCH data_fifo_wr_data(7:0)
            WIRE 5392 1520 5632 1520
            BEGIN DISPLAY 5632 1520 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_rx_data_out(7:0)
            WIRE 4768 1488 5008 1488
            BEGIN DISPLAY 4768 1488 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_rx_ctl_stat_out(7:0)
            WIRE 4208 1552 5008 1552
        END BRANCH
        BEGIN BRANCH info_fifo_wr_data(15:0)
            WIRE 4208 1120 4448 1120
            BEGIN DISPLAY 4448 1120 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_rx_ctl_mux_sel
            WIRE 4208 1616 4576 1616
            WIRE 4576 1616 4784 1616
            WIRE 4784 1616 4784 1664
            WIRE 4784 1664 5104 1664
            BEGIN DISPLAY 4576 1616 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH rx_size_err_flag
            WIRE 4208 1360 4448 1360
            BEGIN DISPLAY 4448 1360 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH info_fifo_wren
            WIRE 4208 1056 4448 1056
            BEGIN DISPLAY 4448 1056 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH crc_err_flag
            WIRE 4208 1296 4448 1296
            BEGIN DISPLAY 4448 1296 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset_n
            WIRE 3200 1552 3440 1552
            BEGIN DISPLAY 3200 1552 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_rx_size_out(10:0)
            WIRE 3200 1056 3440 1056
            BEGIN DISPLAY 3200 1056 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_rx_valid_out
            WIRE 3200 992 3440 992
            BEGIN DISPLAY 3200 992 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_crc_err
            WIRE 3200 928 3440 928
            BEGIN DISPLAY 3200 928 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH data_fifo_full
            WIRE 3200 1280 3440 1280
            BEGIN DISPLAY 3200 1280 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH data_fifo_wrerr
            WIRE 3200 1216 3440 1216
            BEGIN DISPLAY 3200 1216 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RX_CLK_0_sig
            WIRE 3200 1616 3440 1616
            BEGIN DISPLAY 3200 1616 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_342
            WIRE 3200 1488 3440 1488
        END BRANCH
        BEGIN INSTANCE XLXI_2418 1920 3872 R0
        END INSTANCE
        BEGIN BRANCH gec_user_busy
            WIRE 1680 3264 1920 3264
            BEGIN DISPLAY 1680 3264 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_tx_enable_out
            WIRE 1680 3328 1920 3328
            BEGIN DISPLAY 1680 3328 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH data_fifo_empty
            WIRE 1680 3504 1920 3504
            BEGIN DISPLAY 1680 3504 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH info_fifo_rd_data(15:0)
            WIRE 1680 3616 1920 3616
            BEGIN DISPLAY 1680 3616 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH info_fifo_empty
            WIRE 1680 3680 1920 3680
            BEGIN DISPLAY 1680 3680 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset_n
            WIRE 1680 3920 1920 3920
            BEGIN DISPLAY 1680 3920 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH GMII_RX_CLK_0_sig
            WIRE 1680 3984 1920 3984
            BEGIN DISPLAY 1680 3984 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_trigger
            WIRE 2656 3264 2896 3264
            BEGIN DISPLAY 2896 3264 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_tx_size_in(10:0)
            WIRE 2656 3328 2896 3328
            BEGIN DISPLAY 2896 3328 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH info_fifo_rden
            WIRE 2656 3536 2896 3536
            BEGIN DISPLAY 2896 3536 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH data_fifo_rden
            WIRE 2656 3728 3312 3728
        END BRANCH
        INSTANCE XLXI_2437 3312 3792 R0
        BEGIN BRANCH data_fifo_rden_en
            WIRE 2656 3792 3648 3792
        END BRANCH
        INSTANCE XLXI_2438 3648 3856 R0
        BEGIN BRANCH XLXN_442
            WIRE 3568 3696 3584 3696
            WIRE 3584 3696 3584 3728
            WIRE 3584 3728 3648 3728
        END BRANCH
        BEGIN BRANCH gec_user_tx_enable_out
            WIRE 3120 3664 3312 3664
            BEGIN DISPLAY 3120 3664 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH data_fifo_read_enable
            WIRE 3904 3760 4208 3760
            BEGIN DISPLAY 4208 3760 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_2473 2496 2560 R0
        END INSTANCE
        BEGIN BRANCH GMII_RX_CLK_0_sig
            WIRE 2256 2608 2496 2608
            BEGIN DISPLAY 2256 2608 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 2256 2560 2496 2560
            BEGIN DISPLAY 2256 2560 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH info_fifo_wr_data(15:0)
            WIRE 2256 2272 2496 2272
            BEGIN DISPLAY 2256 2272 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH info_fifo_rd_data(15:0)
            WIRE 2880 2272 3056 2272
            BEGIN DISPLAY 3056 2272 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH info_fifo_wren
            WIRE 2256 2464 2496 2464
            BEGIN DISPLAY 2256 2464 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH info_fifo_rden
            WIRE 2256 2512 2496 2512
            BEGIN DISPLAY 2256 2512 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_2471 4352 2544 R0
        END INSTANCE
        BEGIN BRANCH GMII_RX_CLK_0_sig
            WIRE 4112 2592 4352 2592
            BEGIN DISPLAY 4112 2592 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH reset
            WIRE 4112 2528 4352 2528
            BEGIN DISPLAY 4112 2528 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH data_fifo_wr_data(7:0)
            WIRE 4096 2256 4352 2256
            BEGIN DISPLAY 4096 2256 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH data_fifo_wren
            WIRE 4112 2400 4352 2400
            BEGIN DISPLAY 4112 2400 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH data_fifo_read_enable
            WIRE 4112 2464 4352 2464
            BEGIN DISPLAY 4112 2464 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_tx_data_in(7:0)
            WIRE 4736 2256 5088 2256
            BEGIN DISPLAY 5088 2256 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_2480 1680 3920 R270
        BEGIN BRANCH XLXN_443
            WIRE 1680 3856 1920 3856
        END BRANCH
        BEGIN BRANCH info_fifo_empty
            WIRE 2880 2432 3056 2432
            BEGIN DISPLAY 3056 2432 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH data_fifo_empty
            WIRE 4720 2448 5024 2448
            BEGIN DISPLAY 5024 2448 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH gec_user_rx_valid_out
            WIRE 4208 1824 4448 1824
            BEGIN DISPLAY 4208 1824 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_2483 4448 1952 R0
        BEGIN BRANCH data_fifo_wren
            WIRE 4704 1856 4944 1856
            BEGIN DISPLAY 4944 1856 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH final_byte_data_wren
            WIRE 4208 928 4368 928
            BEGIN DISPLAY 4368 928 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH final_byte_data_wren
            WIRE 4208 1888 4448 1888
            BEGIN DISPLAY 4208 1888 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
    END SHEET
END SCHEMATIC
