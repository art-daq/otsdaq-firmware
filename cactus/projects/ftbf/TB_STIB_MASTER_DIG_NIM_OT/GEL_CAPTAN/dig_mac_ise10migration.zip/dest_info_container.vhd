-- Author: Ryan Rivera, FNAL

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

-- this block latches the mac, ip, and port for the destination
	-- field of UDP packets. Info is valid after first UDP packet 
	-- is received addressed to this board.
entity dest_info_container is
	port (
	
		reset 			: in std_logic;	
		latch_sig 		: in std_logic;	
		
		my_addrs 		: in std_logic_vector(7 downto 0);	
		compare_ip		: in std_logic_vector(7 downto 0);	
	
		mac_from_udp 	: in std_logic_vector(47 downto 0);  
		ip_from_udp 	: in std_logic_vector(31 downto 0);   
		port_from_udp 	: in std_logic_vector(15 downto 0);
		
		dest_mac 		: out std_logic_vector(47 downto 0);  
		dest_ip 		: out std_logic_vector(31 downto 0);   
		dest_port 		: out std_logic_vector(15 downto 0) 
	) ;
end;


architecture dest_info_container_arch of dest_info_container is
begin				  
	
	process(latch_sig,reset)
	begin					   
		if reset = '1' then
			dest_mac	<= 	(others => '0');
			dest_ip  	<=	(others => '0');
			dest_port	<=	(others => '0');
		elsif rising_edge(latch_sig) and compare_ip = my_addrs then
			dest_mac	<= 	mac_from_udp; 
			dest_ip  	<=	ip_from_udp; 
			dest_port	<=	port_from_udp;
		end if;				   
	end process;	   
	
end dest_info_container_arch;